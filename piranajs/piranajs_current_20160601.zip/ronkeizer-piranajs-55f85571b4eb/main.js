var app_e = require('app');  // Module to control application life.
var BrowserWindow = require('browser-window');  // Module to create native browser window.

// Report crashes to our server.
require('crash-reporter').start();

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the javascript object is GCed.
var mainWindow = null;

// Quit when all windows are closed.
app_e.on('window-all-closed', function() {
  if (process.platform != 'darwin') {
    app_e.quit();
  }
});

// Libraries
var express = require('express'),
    fs = require('fs'),
    path = require('path'),
    http = require('http'),
    https = require('https'),
    debug = require('debug')('nodejs'),
    mkdirp = require('mkdirp'),
    child_process = require('child_process'),
    connect = require('connect'),
    multipart = require('connect-multiparty'), // file uploads
    multipartMiddleware = multipart(),  // file uploads
    flow = require('./flow/flow-node.js')('tmp'), // file uploads
    debug = require('debug')('nodejs'),
    args = require('minimist')(process.argv.slice(2)),
    _ = require('underscore'),
    argv = require('minimist')(process.argv.slice(2)),
    util = require('util'),
    // pty = require('pty.js'),
    // terminal = require('./term.js'),
    mv = require('mv'),
    os = require('os'),
    argv = require('optimist').argv,
    crypto = require('crypto'); // for reading license keys

var sockets = {};
// get home folder for the user running PiranaJS (best a dedicated linux user) and create a tmp folder there
var home = process.env['HOME'];
debug("Home folder: " + home);
// var tmp = home + '/.piranajs_tmp';
var tmp = __dirname + '/public/tmp';
var tmp_local = __dirname + '/tmp';
var R_folder = tmp + '/R';
mkdirp.sync(tmp);
fs.chmodSync(tmp, 0777); // tmp folder for execution of apirana scripts
clean_folder(tmp);
mkdirp.sync(tmp_local);
fs.chmodSync(tmp_local, 0777); // tmp folder for uploads
clean_folder(tmp_local);
var pw = {};

// TTY
var stream;
if (process.argv[2] === '--dump') {
    stream = fs.createWriteStream(__dirname + '/dump.log');
}
var buff = [];
// term;

// var term = pty.fork('sh', [], {
//     name: require('fs').existsSync('/usr/share/terminfo/x/xterm-256color') ? 'xterm-256color' : 'xterm',
//     cols: 80,
//     rows: 24,
//     cwd: process.env.HOME
// });

// Clean up temporary files
setInterval(function() {
    debug("Cleaning tmp folder\n");
    clean_folder(tmp);
}, 1 * 60 * 1000);

// Setup, read ini file
process.env.TMPDIR = 'tmp';
var ini = require('./piranajs.json');
var apirana = ini.commands.apirana;
console.log(ini);

var platform = os.platform();

// License file reader
function read_license_file(key, ini, callback, socket) {
    function decrypt(key, data) {
        try {
            var decipher = crypto.createDecipher('aes-256-cbc', key);
            var decrypted = decipher.update(data, 'hex', 'utf-8');
            decrypted += decipher.final('utf-8');
            return decrypted;
        }
        catch (err) {

        };
    }
    fs.readFile(ini.license.file, function(e, out) {
        var license_info = { "license_valid_code": 0 };
        if (out !== undefined) {
            var decrypted = decrypt(key, out.toString());
            if (decrypted !== undefined) {
                var license_info = JSON.parse(decrypted);
                var d = license_info.license_valid;
                var license_valid = 0;
                if (d == "indefinite") {
                    license_valid = 1;
                } else {
                    var today = new Date();
                    var d_str = d.substring(0,4) + "-" + d.substring(4, 6) + "-" + d.substring(6,8);
                    var lic_dat = new Date(d_str);
                    if (lic_dat >= today) {
                        license_valid = 1;
                        // console.log("License valid (until "+d_str+").");
                    } else {
                        license_valid = 0;
                        // console.log("License not valid (license until "+d_str+")! Running PiranaJS in trial mode.");
                    }
                }
                license_info.license_valid_code = license_valid;
            }
        } else {
            license_info.license_valid_code = 0;
        }
        callback(license_info, socket);
    });
}
var key = "mavericks";
var license_info = {};
var print_license_info = function(license_info) {
    console.log(license_info);
    if (license_info.license_type === undefined) {
        console.log("Warning: license file not found or read error.\n")
    } else {
        if (license_info.license_valid_code === 0) {
            console.log("Warning: license not valid (valid until "+license_info.license_valid+").\n");
        }
    }
}
read_license_file(key, ini, print_license_info);

// Custom libraries
var ggplot = require('./lib/ggplot');

// Middleware
var cookieParser = express.cookieParser('secret')
var sessionStore = new connect.middleware.session.MemoryStore();
var cwd = require('path').dirname(require.main.filename);
var app = express();
if (ini.general.trust_proxy) {
    app.enable('trust proxy');
}
// var SocketIOFileUploadServer = require('socketio-file-upload');
var port = ini.general.port_http;
if (ini.general.https == true) {
    port = ini.general.port_https;
}
app.configure(function() {
    app.set('port', process.env.PORT || port);
    // app.use(SocketIOFileUploadServer.router);
    app.use(express.logger('dev'));
    app.use(express.favicon());
    app.use(express.errorHandler());
    app.use(express.json());
    app.use(express.urlencoded());
    app.use(express.methodOverride());
    app.use(express.cookieParser());
    app.use(express.session({
        secret: 'secret',
        store: sessionStore,
        cookie: {
            maxAge: 30 * 1000
        }
    }));
    app.use(app.router);
    // app.use(terminal.middleware());
    app.use(express.static(__dirname + '/public/'));
    app.get('/', function(req, res, next) {
        if (req.session !== undefined && req.session.user_id !== undefined) {
            debug("Really logged in now!");
            res.redirect('/index.html', {
                user_id: req.session.user_id
            });
        } else {
            res.redirect('/index.html');
        }
    });
    app.get('/logout', function(req, res, next) {
        req.session.destroy();
        res.redirect("/");
    });
    app.get('/download/:file', function(req, res) {
        var file = tmp + "/" + req.params.file;
        debug(file);
        res.download(file);
    });
    app.get('/parse_login', function(req, res, next) {
        req.session.user_id = req.param('name');
        // req.session.pass = req.param('password');  // no need to store pass in server-side cookie
        debug("Logged in " + req.session.user_id);
        //	res.redirect("/");
    });
});

// Handle uploads through Flow.js
app.post('/upload/:user_id/:folder', multipartMiddleware, function(req, res) {
    flow.post(req, function(status, filename, original_filename, identifier, numberOfChunks) {
        console.log('POST', status, original_filename, identifier, numberOfChunks);
        res.send(200);
        var tmp_full = tmp_local + '/' + filename
        if (status === 'done') {
            var stream = fs.createWriteStream(tmp_full);
            flow.write(identifier, stream);
            stream.on('close', function() { // clean up
		for (i = 1; i <= numberOfChunks; i++) {
                    fs.unlink(tmp_local + '/flow-'+identifier+'.'+i);
		}
		var move_to = req.params.folder.replace(/\!/g, '/');
		move_file_on_server(tmp_full, move_to, filename, undefined, { "user_id" : req.params.user_id }, '', true);
            });
        }
    })
});

// Handle status checks on chunks through Flow.js
app.get('/upload', function(req, res) {
    flow.get(req, function(status, filename, original_filename, identifier) {
        console.log('GET', status);
        res.send(status == 'found' ? 200 : 404);
    });
});
app.get('/download/:identifier', function(req, res) {
    flow.write(req.params.identifier, res);
});

// Define and start server
var server_http = http.createServer(app).listen(ini.general.port_http, function() {
    debug("Unsecure Express server listening on port " + ini.general.port_http);
});
if (ini.general.use_https === true) {
    var sslOptions = {
        key: fs.readFileSync(ini.ssl.key),
        cert: fs.readFileSync(ini.ssl.cert)
    };
    server_https = https.createServer(sslOptions, app).listen(ini.general.port_https, function() {
        debug("Secure Express server listening on port " + ini.general.port_https);
    });
    var server = server_https;
} else {
    var server = server_http;
}

// start server and socket
var io = require('socket.io').listen(server),
SessionSockets = require('session.socket.io'),
sessionSockets = new SessionSockets(io, sessionStore, cookieParser);
// io.set('log level', 1); // avoid long debug output

// Main I/O with client-side
sessionSockets.on('connection', function(err, socket, session) {
    socket.emit('session', session);

    // TTY
    if (ini.general.allow_tty) {
        term.on('data', function(data) {
            if (stream) stream.write('OUT: ' + data + '\n-\n');
            return !socket ? buff.push(data) : socket.emit('data', data);
        });
        socket.on('data', function(data) {
            if (stream) stream.write('IN: ' + data + '\n-\n');
            term.write(data);
        });
        socket.on('disconnect', function() {
            socket = null;
        });
        while (buff.length) {
            socket.emit('data', buff.shift());
        }
    };

    // Send some settings and checks to client
    fs.exists(ini.commands.zedrem, function(exists) {
        if (exists) {
            socket.emit('zed_exists');
        }
    });
    socket.emit('links', ini.links);
    if (ini.general.allow_tty) {
        socket.emit('allow_tty');
    } // current implementation is insecure! Do not use for production.

    //debug(cmd + " " + input.user_id);
    ip = socket.handshake.address.address;
    io.of('/user').on('connection', function(socket) {
        ss(socket).on('profile-image', function(stream, data) {
            var filename = path.basename(data.name);
            stream.pipe(fs.createWriteStream(filename));
        });
    });

    // Main socket handling
    socket.on('message', function(input) {
        var cmd = input.cmd;
        var cmdline = input.cmdline;
        var folder = input.folder;
        var file = input.file;
        var socketid = sockets[input.user_id];
        var user_id = input.user_id;
   });
	// socket.on('message', {
        //     io.sockets.emit('message_all', {
        //         'cmd': "message_all",
        //         text: input.text,
        //         user_id: input.user_id,
        //         to_user: input.to_user
        //     });
        // });

	socket.on('cmd', function(input) {
      var spl = input.cmdline.split(' ');
      var executable = spl.shift();
      input.cmdline = executable + ' ' + spl.join(' ');
      // console.log("Executing command: " + input.cmdline);
      cmd_stream(socket, input, executable, session);
  });

	socket.on('download_folder', function(input) { // download complete folder
            var spl = input.folder.split(/\//);
            var last_part = spl.pop();
            var first_part = spl.join('/');
            input.filename = "download_" + last_part + ".zip";
            input.cmdline = "zip -r " + tmp + "/" + input.filename + " " + last_part + " > ~/tmp/zip.out";
            input.run_in_folder = first_part;
            cmd_exec(socket, input, session);
        });

	socket.on('create_run_record', function(input) {
            var today = new Date();
            var d = today.getFullYear().toString()+(today.getMonth()+1).toString()+today.getDate().toString();
            input.filename = "pirana_runrec_"+d+".csv";
            input.run_in_folder = input.folder;
            input.cmdline = "apirana -run_record -user="+session.user_id+" -f=csv -o="+input.filename+" -dir="+input.folder+" -v=0";
            cmd_exec(socket, input, session);
        });

	socket.on('get_license_status', function(input) {
            var return_license_info = function(license_info) {
                socket.emit('get_license_status', {
                    'license_info': license_info
                });
            }
            read_license_file(key, ini, return_license_info, socket);
            // socket.emit(cmd, {
            //     'cmd': cmd,
            //     'license_valid': license_info.license_valid_code,
            //     'license_info': license_info
            // })
        });

	socket.on('get_folder_info', function(input) {
            //	    console.log(folder+input.subfolder+"/command.txt");
            fs.exists(input.folder + input.subfolder + "/command.txt", function(exists) {
                var tmp = Object.create(input);
                tmp.cmdline = "cat " + input.folder + tmp.subfolder + "/command.txt";
                tmp.type = "psn_cmd";
                cmd_exec(socket, tmp, session);
                // get NMTRAN error messages as well
                fs.exists(input.folder + input.subfolder + "/NM_run1/nmtran_error.txt", function(exists) {
                    var tmp2 = Object.create(input);
                    tmp2.cmdline = "cat " + input.folder + tmp2.subfolder + "/NM_run1/nmtran_error.txt";
                    tmp2.type = "nmtran_error";
                    cmd_exec(socket, tmp2, session);
                });
            });
        });

	socket.on('create_vrr', function(input) {
            input.cmdline = apirana + ' -user='+session.user_id+' -vrr -v=0 -dir=' + input.folder;
            cmd_exec(socket, input, session);
        });

        socket.on('run_r_script', function(input) { //if (cmd.match(/run_r_script/g)) {
            input.cmdline = apirana + ' -dir=' + input.folder + ' -run_script=' + input.base_dir + '/' + file + ' ' + input.mod;
            run_r_script(socket, input, session);
        });

	socket.on('copy_script', function(input) {
//        if (cmd.match(/copy_script/g)) {
            var target_folder; // copy to project folder
            if (input.folder_type.match("project")) {
                target_folder = input.folder + "/pirana_scripts";
            }
            if (input.folder_type.match("user")) {
                target_folder = home + "/.pirana/scripts";
            }
            fs.exists(target_folder, function(exists) {
                if (exists) {
                    move_file_on_server(input.script, target_folder, input.new_script, socket, session, 'copy_script', false);
                } else {
                    var cmdline = "mkdir " + target_folder;
                    var socketid = sockets[session.user_id];
                    var run_in_folder = tmp;
                    console.log("sudo -u " + session.user_id + " -s " + cmdline);
                    var child = child_process.exec("sudo -u " + session.user_id + " -s " + cmdline, {
                        cwd: run_in_folder
                    }, function(error, stdout, stderr) {
                        move_file_on_server(input.script, target_folder, input.new_script, socket, session, 'copy_script', false);
                    });
                }
            });
        });

	socket.on('refresh_projects', function(input) {
            input.home = input.home.replace(/ /, "{s}");
            input.cmdline = apirana + ' --projects --v=0 --f=json --user=' + session.user_id + ' -home=' + input.home;
            cmd_exec(socket, input, session);
        });

	socket.on('diff', function(input) {
            input.cmdline = apirana + " --diff -dir='" + input.folder + "' -v=0 -f=html " + input.file_new + " " + input.file_old;
            cmd_exec(socket, input, session);
        });

	socket.on('project_active', function(input) {
      input.home = input.home.replace(/ /, "{s}");
      if ((input.project === undefined) || (input.project == "")) {
          input.cmdline = apirana + ' -project_active -v=0 -home=' + input.home;
      } else {
          input.project = input.project.replace(/\s/, "{s}");
          input.cmdline = apirana + ' -project_active=' + input.project + ' -v=0 -home=' + input.home;
      }
      if (session !== undefined) {
          input.cmdline += ' --user=' + session.user_id;
          cmd_exec(socket, input, session);
      }
  });

	socket.on('get_psn_nm_versions', function(input) {
            input.cmdline = apirana + ' --psn_nm_versions --v=0 --f=json --user=' + session.user_id;
            input.folder = tmp + "/";
            cmd_exec(socket, input, session);
        });

	socket.on('kill_process', function(input) {
            console.log(JSON.stringify(input));
            input.cmdline = 'kill -s KILL ' + input.pid;
            input.folder = tmp + "/";
            cmd_exec(socket, input, session);
        });

	socket.on('qdel', function(input) {
            console.log(JSON.stringify(input));
            input.cmdline = 'qdel ' + input.pid;
            input.folder = tmp + "/";
            cmd_exec(socket, input, session);
        });

	socket.on('psn_log', function(input) {
            input.cmdline = apirana + ' --psn_history --v=0 --f=json -user=' + session.user_id;
            input.folder = tmp + "/";
            cmd_exec(socket, input, session);
        });

	socket.on('psn_log_add', function(input) {
            input.psn_cmd = input.psn_cmd.replace(/ /g, "{s}");
            input.cmdline = apirana + ' --psn_history_add="' + input.psn_cmd + '" --v=0 --user=' + session.user_id;
            input.folder = tmp + "/";
            cmd_exec(socket, input, session);
        });

	socket.on('psn_log_clear', function(input) {
            input.cmdline = apirana + ' --psn_history_clear --v=0 --f=json --user=' + session.user_id;
            input.folder = tmp + "/";
            cmd_exec(socket, input, session);
        });

	socket.on('duplicate', function(input) {
            debug("Executing command: " + cmdline);
            input.cmdline = apirana + " -dir=" + input.folder.replace(/ /g, "{s}") + " -duplicate=" + input.new_mod + " -description=" + input.description.replace(/ /g, "{s}");
            if (input.ue) {
                input.cmdline += ' -ue'
            }
            if (input.un) {
                input.cmdline += ' -un'
            }
            input.cmdline += ' -force ' + input.model;
            cmd_exec(socket, input, session);
        });

	socket.on('project_remove', function(input) {
            input.home = input.home.replace(/ /g, "{s}");
            input.cmdline = apirana + " -project_remove='" + input.project + "' -v=0 -user=" + session.user_id + ' -home=' + input.home;
            debug('Remove project: ' + input.cmdline + '\n');
            cmd_exec(socket, input, session);
        });

	socket.on('project_add', function(input) {
            input.home = input.home.replace(/ /g, "{s}");
            input.cmdline = apirana + ' -project_add=' + input.project + ' -v=0 -dir=' + input.folder + ' -user=' + session.user_id + ' -home=' + input.home;
            cmd_exec(socket, input, session);
        });

	socket.on('rm', function(input) {
            var cmdline = "rm -rf ";
            for (i = 0; i < input.files.length; i++) {
                var run = input.files[i];
                if (run.match("^\/")) {
                    var dir = run.replace(/^\//, "");
                    if (dir !== "" && dir !== "." && dir !== "..") {
                        cmdline += input.folder + "/" + dir + " ";
                    }
                } else {
                    cmdline += input.folder + "/" + run + ".mod ";
                    if (input.del_all) {
                        if (run.length > 1 && run !== "*") {
                            cmdline += input.folder + "/" + run + ".*";
                        }
                    }
                    if (input.del_tab) {
                        // need to add
                    }
                }
            }
            debug("Executing command: " + cmdline);
            input.cmdline = cmdline;
            if (i < input.files.length - 1) {
                input.cmd = "dummy"; // don't give signal to refresh pirana yet
            }
            cmd_exec(socket, input, session);
        });

	socket.on('new_folder', function(input) {
            cmdline = "mkdir " + input.folder + "/" + input.new_folder;
            debug("Executing command: " + cmdline);
            input.cmdline = cmdline;
            cmd_exec(socket, input, session);
        });

	socket.on('open_file_in_spreadsheet', function(input) {
            // basically same as open in editor, parsing is done client-side since csv/tab is smaller than json
            child = child_process.exec('cat ' + input.folder + '/' + input.file, function(error, stdout, stderr) {
                socket.emit(input.cmd, {
                    'cmd': input.cmd,
                    'file': input.file,
                    'output': stdout,
                    'mode': input.mode
                });
            });
            child.on('error', function(err) {
                socket.emit('cmd', {
                    'cmd': 'cmd',
                    'file': input.file,
                    'output': "An error occurred while reading the files this folder.\n"
                });
            });
        });

	socket.on('get_notes', function(input) {
            fs.exists(input.folder+"/pirana.md", function(e) {
                if (e) {
                    read_file (input.folder + "/pirana.md", socket, session, cmd, input);
                } else {
                    move_file_on_server(__dirname + '/templates/pirana.md', input.folder, 'pirana.md', socket, session, 'created_new_note', false);
                }
            });
        });

	socket.on('file_delete', function(input) {
            input.folder = tmp + '/';
            // for (i in input.files) {
            //     input.files[i] = folder + '/' + input.files[i];
            // }
            var files = input.files.join(' ');
            input.cmdline = 'rm ' + files;
            input.run_in_folder = input.folder;
            cmd_exec(socket, input, session);
        });

	socket.on('file_download', function(input) {
           if(input.files.length == 1) {
             move_file_on_server(input.folder + '/' + input.filename, tmp, input.filename, socket, session, 'file_download', false);
           } else {
             input.filename = "download_" + input.files[0] + "_etc.zip";
             input.cmdline = "zip -r " + tmp + "/" + input.filename + " " + input.files.join(" ") + " > ~/tmp/zip.out";
             input.run_in_folder = input.folder;
             cmd_exec(socket, input, session);
           }
        });

	socket.on('code_editor', function(input) {
      console.log(input);
      var full_file = input.folder + '/' + input.file;
      if (input.folder === undefined) {
          full_file = input.file;
      }
      read_file (full_file, socket, session, input.cmd, input);
  });

	socket.on('view_lst', function(input) { // slightly different from just opening the code editor
            var file_full;
            input.cmd = 'code_editor';
            if (input.file.match(/^\//)) { // possibly a PsN / nmfe folder
		// Query the entry
		stats = fs.lstatSync('/the/path');

		// Is it a directory?
		if (stats.isDirectory()) {
		    // Yes it is
		}
                var stats = fs.lstatSync(input.folder + input.file + '/NM_run1/psn-1.lst');
                if (stats.isFile) {
                    var file_full = input.folder + input.file + '/NM_run1/psn-1.lst';
                    input.cmdline = 'cat ' + file_full;
                    input.file = file_full;
                    cmd_exec(socket, input, session);
                }
            } else { // file
                var file_full = input.folder + "/" + input.file;
                input.file = file_full;
                input.cmdline = 'cat ' + file_full;
                cmd_exec(socket, input, session);
            }
        });

	socket.on('editor_save', function(input) {
            if (input.text !== undefined && input.file !== undefined) {
                var spl = input.file.split(/\//);
                var file = spl.pop();
                var tmp_file = tmp + '/' + file + "_" + Math.round(10000 * Math.random());
                fs.writeFile(tmp_file, input.text, {
                    mode: '777'
                }, function(err) {
                    if (err) {
                        debug(err);
                    } else {
                        debug("File " + tmp_file + " saved to tmp!");
                        input.cmdline = "cp " + tmp_file + " " + input.file;
                        input.cmd = "file_saved_editor";
                        input.folder = tmp + "/";
                        cmd_exec(socket, input, session);
                        // socket.emit('relay', { 'cmd': 'file_saved', 'file': input.file } );
                    }
                });
            }
        });

	socket.on('rename_file', function(input) {
            if (input.newfile !== undefined && input.oldfile !== undefined && input.newfile !== input.oldfile) {
                debug('Renaming file ' + input.oldfile + ' to ' + input.newfile);
                move_file_on_server(input.folder + '/' + input.oldfile, input.folder, input.newfile, socket, session, 'refresh_pirana', true);
            }
        });

	socket.on('server_file_viewer', function(input) {
            path = file.split(/\//g);
            file_bare = path[path.length - 1];
            fs.exists(input.folder + '/' + input.file, function(exists) {
                console.log("File: " + exists + " " + input.folder + '/' + input.file);
                if (exists) {
                    debug("File check 1");
                    fs.createReadStream(input.folder + '/' + finput.ile).pipe(fs.createWriteStream(__dirname + '/public/tmp/' + file_bare));
                    fs.exists(tmp + '/' + file_bare, function(exists2) {
                        if (exists2) {
                            debug("File check 2");
                            socket.emit('server_file_viewer', {
                                'cmd': 'server_file_viewer',
                                'format': input.format,
                                'file_url': 'tmp/' + file_bare
                            });
                        } else {
                            debug("File does not exist (" + tmp + "/" + file_bare + ")");
                            socket.emit('cmd', {
                                'cmd': 'cmd',
                                'output': "An error occurred while reading the file (2)",
                                size: 'small',
                                noadd: true
                            });
                        }
                    });
                } else {
                    socket.emit('cmd', {
                        'cmd': 'cmd',
                        'output': "An error occurred while reading the file (1).",
                        size: 'small',
                        noadd: true
                    });
                }
            });
        });

	socket.on('get_last_nm_error', function(input) {
          var files = fs.readdirSync(input.folder);
          files.sort(function(a, b) {
               return fs.statSync(input.folder+'/'+a).mtime.getTime() -
                      fs.statSync(input.folder+'/'+b).mtime.getTime();
           });
           filt1 = function filt1 (el) { return el.match("modelfit_dir") };
           var files1 = files.filter(filt1);
           filt2 = function filt1 (el) { return el.match(".mod.dir") };
           var files2 = files.filter(filt2);
           var folders = files1.concat(files2);
           var latest = get_latest_file(input.folder, folders);
           var errfile = path.join(input.folder, latest, "NM_run1", "nmtran_error.txt");
           console.log(errfile);
           fs.readFile(errfile, 'utf8', function (err, nmtran) {
             if (err) {
               return console.log(err);
             }
             if (nmtran === undefined || nmtran === "") {
                socket.emit('get_last_nm_error', {
                  'text': "PiranaJS tried, but couldn't get additional info on the NONMEM error, sorry."
                });
             } else {
                socket.emit('get_last_nm_error', {
                  'text': path.join(latest, "NM_run1", "nmtran_error.txt") + ":<br>" + nmtran
                });
             }
           });
        });

	socket.on('compare_estimates', function(input) {
            input.cmdline = apirana + ' -compare_estimates -v=0 -f=csv -dir=' + input.folder + ' ' + input.mods.join(" ");
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('get_estimates', function(input) {
            if (input.file !== '' && input.file !== undefined) {
                var cmdline = apirana + ' -estimates -user='+session.user_id+' -dir=' + input.folder + ' -v=0 -f=json ' + input.file;
                debug(cmdline);
                child = child_process.exec(cmdline, function(error, stdout, stderr) {
                    if (error !== null) {
                        debug('exec error ' + error);
                    }
                    socket.emit('get_estimates', {
                        'cmd': 'get_estimates',
                        'run': input.file.replace('.lst', ''),
                        'output': stdout
                    });
                });
                child.on('error', function(err) {
                    socket.emit('cmd', {
                        'cmd': 'cmd',
                        'output': "An error occurred while loading this folder.\n"
                    });
                });
            } else {
                socket.emit('cmd', {
                    'cmd': 'cmd',
                    'output': "An unknown error occurred while extracting estimates.\n"
                });
            }
        });

	socket.on('unhide_all_runs', function(input) {
            input.cmdline = apirana + ' --unhide --all --dir=' + input.folder + ' --user=' + session.user_id;
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('hide_runs', function(input) {
            if (input.runs !== undefined) {
                var runs = input.runs.join(" ");
                input.cmdline = apirana + ' -v=0 --hide --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
                input.folder = tmp + '/';
                cmd_exec(socket, input, session);
            }
        });

  socket.on('refresh', function(input) {
	    console.log("refresh");
      // fs.readdir(input.folder, function(err, files) {
      // if (!err) {
        input.cmdline = apirana + ' -run_record -folders=' + input.folder_filter + ' -dir=' + input.folder + ' -f=json -v=0';
        input.folder = tmp + '/';
        cmd_exec(socket, input, session);
      // } else {
      //       socket.emit('refresh', {
      //           'cmd': 'refresh',
      //           'output': "Folder not readable"
      //       });
      //   }
    // });
  });

	socket.on('set_info', function(input) {
            if (input.runs !== undefined && input.note !== undefined) {
                var runs = input.runs.join(" ");
                input.note = input.note.replace(/ /g, "{s}");
                input.refmod = input.refmod.replace(/ /g, "{s}");
                input.description = input.description.replace(/ /g, "{s}");
                input.author = input.author.replace(/ /g, "{s}");
                input.cmdline = apirana + ' -v=0 -set_info -notes=' + input.note + ' -description=' + input.description + ' -author=' + input.author + ' -refmod=' + input.refmod + ' -dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
                console.log("****" + input.cmdline);
                input.folder = tmp + '/';
                cmd_exec(socket, input, session);
            }
        });

	socket.on('set_color', function(input) {
            if (input.runs !== undefined) {
                var runs = input.runs.join(" ");
                input.cmdline = apirana + ' --color=' + input.color + ' --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
                input.folder = tmp + '/';
                cmd_exec(socket, input, session);
            }
        });

	socket.on('set_flag', function(input) {
            if (input.runs !== undefined) {
                var runs = input.runs.join(" ");
                input.cmdline = apirana + ' --flag=' + input.flag + ' --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
                input.folder = tmp + '/';
                cmd_exec(socket, input, session);
            }
        });

	socket.on('remove_flags', function(input) {
            if (input.runs !== undefined) {
                var runs = input.runs.join(" ");
                input.cmdline = apirana + ' --flag=remove' + ' --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
                input.folder = tmp + '/';
                cmd_exec(socket, input, session);
            }
        });

	socket.on('start_zed', function(input) {
            var executable = ini.commands.zedrem;
            input.cmdline = executable + " " + input.folder + " &";
            debug("Executing command: " + input.cmdline);
            input.cmd = "cmd";
            cmd_stream(socket, input, executable, session);
        });

	socket.on('translate', function(input) {
            to = input.translate_to;
            var out = input.run + ".txt";
            if (to == "R") {
                out = input.run + ".R";
            }
            if (to == "Matlab") {
                to = "MATLAB";
                out = input.run + ".m";
            }
            if (to == "Berkeley Madonna") {
                to = "BM";
                out = input.run + ".bm";
            }
            if (to == "NONMEM ADVAN6") {
                to = "NM";
                out = input.run + "_ode.mod";
            }
            input.cmdline = apirana + ' --translate --format=' + to + ' --dir=' + input.folder + ' --o=' + out + ' ' + input.run;
            input.out = out;
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('run_report', function(input) {
            if (input.file !== '' && input.file !== undefined) {
                var file_rel = 'pirana_reports/pirana_sum_' + input.file + '.html';
                var file_full = input.folder + '/' + file_rel;
                // var fs = require('fs');
                // fs.mkdir(folder + '/pirana_reports', function(e){
                //   if (e) { console.log(e); }
                // });
                if (input.format == undefined) {
                    input.format = 'txt';
                };
                var outfile = folder + "/pirana_reports/pirana_sum_" + input.file + ".html";
                var cmdline = apirana + ' -run_report -dir=' + input.folder + ' -v=0 -f=html -output=' + outfile + ' ' + input.file + '.lst';
                var format = input.format;
                if (format == "pdflatex") {
                    format = "tex"
                };
                if (format == 'txt' || format == 'r_obj' || format == 'tex' || format == 'pdflatex') {
                    cmdline = apirana + ' -run_report -dir=' + input.folder + ' -v=0 -f=' + format + ' ' + input.file + '.lst';
                }
                if (input.format == "pdflatex") {
                    outfile = "pirana_reports/pirana_sum_" + input.file + ".pdf";
                    // APIRANA: make new folder if not exists!
                    cmdline += " -output=" + input.folder + "/pirana_reports/pirana_sum_" + input.file + ".tex -pdflatex";
                }
                if (input.format == "docx") {
                    outfile = "pirana_reports/pirana_sum_" + input.file + ".docx";
                    cmdline += " -output=" + input.folder + "/pirana_reports/pirana_sum_" + input.file + ".docx";
                }
                input.cmdline = cmdline;
                input.outfile = outfile;
//                input.file = file;
                input.folder = tmp + '/';
                cmd_exec(socket, input, session);
            } else {
                socket.emit('cmd', {
                    'cmd': 'cmd',
                    'output': "An unknown error occurred while loading this folder.\n"
                });
            }
        });

	socket.on('open_run_report', function(input) {
            input.folder = tmp + '/';
            var file_dest = 'public/tmp/tmp_' + input.user_id + '_' + random_string(5) + '_' + input.file + '.html';
            // fs = require('fs');
            debug("Trying to open report on the client...");
            move_file_on_server(input.outfile, __dirname, file_dest, socket, session, "open_run_report", false);
        });

	socket.on('login', function(input) {
	    console.log(input);
            input.folder = tmp + '/';
            input.pw.replace(/[\'\"\\]/, ""); // against XSS attacks
            input.user_id.replace(/[\'\"\\]/, "");
            process.env['USERNAME'] = input.user_id;
            process.env['PASSWORD'] = input.pw;
            var child = child_process.exec('expect authenticate.exp', {
                cwd: __dirname + '/expect'
            }, function(error, stdout, stderr) {
                process.env['USERNAME'] = "";
                process.env['PASSWORD'] = "";
                if (error !== null) {
                    debug('Authentication error: ' + error);
                }
                if (stdout.match(/^spawn/)) {
                    var lines = stdout.split('\n');
                    lines.splice(0, 1);
                    stdout = lines.join('\n');
                }
                if (stdout.match(/^Password:/)) {
                    var lines = stdout.split('\n');
                    lines.splice(0, 1);
                    stdout = lines.join('\n');
                }
                if (stdout.match(/^OK/) && !(stdout.match(/sorry/i))) {
                    debug("login succeeded!");
                    if (session !== undefined) {
                        session.user_id = input.user_id;
                        session.save();
                    }
                    socket.emit('session', session);
                    sockets[input.user_id] = socket.id;
                    io.sockets.emit('initialize_call', {
                        'cmd': "initialize_call",
                        user_id: input.user_id
                    });
                    debug("Logging in " + input.user_id + " " + socket.id);
                    socket.emit('login', {
                        'cmd': 'login',
                        'user_id': input.user_id,
                        'output': "Logged in."
                    });
                } else {
                    debug("login failed!");
                    socket.emit('wrong_login', {
                        'cmd': 'wrong_login',
                        'user_id': input.user_id
                    });
                }
            });
        });

	socket.on('logout', function(input) {
            if (session !== undefined) {
                session.destroy();
            }
            if (socket !== undefined) {
                socket.emit('logout', {
                    'cmd': 'logout',
                    'output': "Logged out."
                });
            }
        });

	socket.on('get_home_folder', function(input) {
            input.folder = tmp + '/';
            debug("Getting home folder");
            if (session !== undefined) {
                if (ini.folders.user_home_folder == "") {
                    child = child_process.exec('echo ~' + session.user_id, {}, function(error, stdout, stderr) {
                        if (error !== null) {
                            debug('Error retrieving home folder ' + error);
                        }
                        var spl = stdout.split('\n');
                        var home_folder = undefined;
                        for (var i = 0; i < spl.length; i++) { // slightly different on linux vs osx
                            if (!spl[i].match('spawn') && spl[i].length > 5) {
                                home_folder = spl[i].replace('\r', '');
                            }
                        }
                        if (home_folder !== undefined) {
                            if (home_folder.match('Sorry')) {
                                socket.emit('cmd', {
                                    'cmd': 'cmd',
                                    'output': 'Sorry, that username and password did not match.'
                                });
                            } else {
				var socketid = sockets[input.user_id];
                                debug("Sending back home folder info: " + home_folder + socketid);
                                session.home_folder = home_folder;
                                socket.emit('get_home_folder', {
                                    'cmd': 'get_home_folder',
                                    'folder': home_folder
                                });
                            }
                        } else {
                            debug("Home folder not defined!");
                        }
                    });
                    child.on('error', function(err) {
                        socket.emit('cmd', {
                            'cmd': 'cmd',
                            'output': "An error occurred while getting the user information.\n"
                        });
                    });
                } else {
                    socket.emit('get_home_folder', {
                        'cmd': 'get_home_folder',
                        'folder': ini.folders.user_home_folder
                    });
                }
            }
        });

	socket.on('get_templates', function(input) {
            input.folder = tmp + '/';
            input.cmdline = apirana + " -run_record -dir='" + __dirname + "/templates" + "' -f=json -v=0";
            cmd_exec(socket, input, session);
        });

	socket.on('new_model_from_template', function(input) {
            debug("Trying to copy template model to new file...");
            input.cmdline = apirana + " -duplicate='" + input.folder + "/" + input.new_model_name + "' -description='" + input.description + "' -f=json -v=0 -force -update_numbers " + __dirname + '/templates/' + input.template_model + '.mod';
            input.folder = tmp + '/';
            // console.log(input.cmdline);
            cmd_exec(socket, input, session);
        });

	socket.on('process_info', function(input) {
            input.cmdline = apirana + ' -ps -f=json -v=0';
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('qstat_info', function(input) {
            input.cmdline = apirana + ' -qstat -f=json -v=0';
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('intermed_info', function(input) {
            input.cmdline = apirana + ' -inter -f=json -v=0 -dir=' + input.folder;
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('files', function(input) {
            get_files(socket, input.folder, input.cmd, "files", input);
            input.folder = tmp + '/';
        });

	socket.on('psn_help', function(input) {
            input.folder = tmp + '/';
            child = child_process.exec(input.command + ' --' + input.type, function(error, stdout, stderr) {
                socket.emit(cmd, {
                    'cmd': cmd,
                    'output': stdout,
                    'mode': 'text'
                });
            });
            child.on('error', function(err) {
                socket.emit('cmd', {
                    'cmd': 'cmd',
                    'output': "An error occurred while getting PsN help.\n"
                });
            });
        });

	socket.on('nm_help_index', function(input) {
            input.folder = tmp + '/';
            input.cmdline = apirana + ' -nm_help -f=json -v=0';
            cmd_exec(socket, input, session);
        });

	socket.on('nm_help_topic', function(input) {
            input.folder = tmp + '/';
            input.key = input.key.replace(/\$/g, '\\\$');
            input.cmdline = apirana + ' -nm_help=' + input.key + ' -f=json -v=0';
            cmd_exec(socket, input, session);
        })

	socket.on('psn_tool_default_args', function(input) {
            input.folder = tmp + '/';
            input.cmdline = apirana + ' -psn_tool_default_args -f=json -v=0';
            cmd_exec(socket, input, session);
        });

	socket.on('refresh_reports', function(input) {
            input.folder = tmp + '/';
            input.cmdline = apirana + ' -reports -f=json -dir=' + folder + ' -v=0';
            cmd_exec(socket, input, session);
        });

	socket.on('refresh_vc', function(input){
            input.cmdline = apirana + ' -vc_log=12 -f=json -v=0 -dir='+input.folder;
            input.run_in_folder = folder;
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('refresh_scripts', function(input) {
            //	    input.cmdline = apirana + ' -list_scripts -f=json -v=0 -dir='+ini.folders.pirana_scripts;
            input.cmdline = apirana + ' -list_scripts -f=json -v=0 -dir=' + input.folder + '/pirana_scripts';
            // console.log(input.cmdline);
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('reset_pirana_db', function(input) {
            input.folder = tmp + '/';
            input.cmdline = 'unlink ' + input.folder + '/pirana.dir';
            cmd_exec(socket, input, session);
        });

	socket.on('remove_modelfit_folder', function(input) {
            input.folder = tmp + '/';
            input.cmdline = 'rm -rf ' + input.folder + '/modelfit_dir*';
            cmd_exec(socket, input, session);
        });

	socket.on('r_object_from_est', function(input) {
            input.cmdline = apirana + ' -rr ' + input.file + '.mod -f=r_obj -v=0';
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('build_tex_pdf', function(input) {
            input.cmdline = 'pdflatex -output-directory=' + input.folder + '/pirana_reports ' + folder + '/' + input.tex_file + ' >/dev/null';
            input.folder = tmp + '/';
            debug("\n\n" + input.cmdline + "\n\n");
            cmd_exec(socket, input, session);
        });

	socket.on('get_data_info', function(input) {
            input.cmdline = apirana + ' -data_info=' + input.file + ' -dir=' + input.folder + ' -f=json -v=0';
            input.folder = tmp + '/';
            debug("Data info: " + input.cmdline);
            cmd_exec(socket, input, session);
        });

	socket.on('update_data_inspector_plot', function(input) {
            dat = input.data.split('\/').pop()
            dat = dat.replace(/\./g, '_');
            input.outfile = 'pl_' + input.user_id + '_' + dat + '_' + input.x_sel + '_' + input.y_sel + '.svg';
            input.cmdline = 'R --vanilla --args wd=' + input.folder + ' out=' + tmp + '/' + input.outfile + ' data=' + input.data + ' x=' + input.x_sel + ' y=' + input.y_sel +
                ' point=' + input.point + ' line=' + input.line + ' smooth=' + input.smooth +
                ' facet1=' + input.facet1 + ' facet2=' + input.facet2 +
                ' colour=' + input.colour + ' group=' + input.group + ' axes=' + input.axes + ' < ' + __dirname + '/R/datainspector_plot.R';
            debug(input.cmdline);
            input.r_folder = input.folder;
            input.folder = tmp + '/';
            cmd_exec(socket, input, session);
        });

	socket.on('data_inspector_r_code', function(input) {
            var code = ggplot.generate_code(input);
            socket.emit('data_inspector_r_code', {
                'cmd': 'data_inspector_r_code',
                'code': code
            });
        });

	socket.on('handle_file_upload', function(input) {
      handle_file_upload(socket, input, session);
  });
        // io.sockets.emit('relay', { 'connections': Object.keys(io.connected).length, 'ip': ip, 'xdomain': socket.handshake.xdomain, 'timestamp': new Date()});

});

////////////////////////////////////////////////////////////////////////////////////

// This method will be called when Electron has done everything
// initialization and ready for creating browser windows.
app_e.on('ready', function() {

  // Create the browser window.
  mainWindow = new BrowserWindow({width: 1200, height: 768});

  // and load the index.html of the app.
  mainWindow.loadUrl('http://localhost:8000');
  if(argv.debug) {
    mainWindow.openDevTools();
  }

  // Emitted when the window is closed.
  mainWindow.on('closed', function() {
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null;
  });
});


////////////////////////////////////////////////////////////////////////////////////

// Functions
function clean_folder(dirPath) {
    fs.readdir(dirPath, function(err, files) {
        if (err) return debug(err);
        files.forEach(function(file) {
            var filePath = dirPath + '/' + file;
            fs.stat(filePath, function(err, stat) {
                if (err) return debug(err);
                var current = new Date();
                var diff = (current - stat.ctime) / (1000 * 3600);
                unlink_file(filePath);
            });
        });
    });
}

function handle_file_upload(socket, input, session) {
    var new_file = input.source_name.replace(/[^\w\-\.]/g, "_");
    move_file_on_server(input.source_file, input.target_folder, new_file, socket, session, "upload_file_done", true)
};

function random_string(n) {
    return (Math.random().toString(36).substring(n));
}

function cmd_stream(socket, input, cmd_id, session) { // streaming output
    if (session !== undefined) {
        if (session.user_id !== undefined) {
            debug("Starting stream");
            var fs = require('fs');
            var tmp_script = 'sudo -u ' + session.user_id + ' -i sh -c "';
            if (ini.general.run_before_psn !== null & ini.general.run_before_psn !== "") {
              tmp_script += 'bash '+ini.general.run_before_psn + '; ';
            }
            tmp_script += 'cd '+input.folder+'; '+input.cmdline+'"';
            if (platform === 'darwin') { // slightly different on OS X
              tmp_script = 'cd '+input.folder+'; sudo -u ' + session.user_id + ' -s '+input.cmdline;
            }
            // console.log(tmp_script);
            tmp_f = "tmp_" + session.user_id + "_" + Math.round(10000 * Math.random()) + ".sh";
            tmp_file = tmp + '/' + tmp_f;
            fs.writeFile(tmp_file, tmp_script, function(err) {
                if (err) {
                    debug(err);
                }
                var tail = require("child_process").spawn('/bin/bash', [tmp_file], {
                    cwd: input.folder
                });
                tail.stderr.on("data", function(data) {
                    var out = data.toString();
                    // debug(out);
                    // console.log(out);
                    socket.emit(input.cmd, {
                        'cmd': input.cmd,
                        'cmd_id': cmd_id,
                        'console_number': input.console_number,
                        'output': out
                    });
                });
                tail.stdout.on("data", function(data) {
                    var out = data.toString();
                    // debug(out);
                    // console.log(out);
                    socket.emit(input.cmd, {
                        'cmd': input.cmd,
                        'cmd_id': cmd_id,
                        'console_number': input.console_number,
                        'output': out
                    });
                    // console.log(stdout);
                });
            });
        }
    }
};

function cmd_exec (socket, input, session) {
    if (session !== undefined) {
        if (session.user_id !== undefined) {
            console.log('sudo -u ' + session.user_id + ' -i ' + input.cmdline);
            var socketid = sockets[session.user_id];
            var run_in_folder = tmp;
            if (input.run_in_folder !== undefined) {
                run_in_folder = input.run_in_folder;
            }
            var child = child_process.exec('sudo -u ' + session.user_id + ' -i ' + input.cmdline, {
                cwd: run_in_folder
            }, function(error, stdout, stderr) {
                if (error !== null) {
                    debug('exec error ' + error);
                }
                if (stdout.match(/^spawn/)) {
                    var lines = stdout.split('\n');
                    lines.splice(0, 1);
                    stdout = lines.join('\n');
                }
                if (stdout.match(/^Password:/)) {
                    var lines = stdout.split('\n');
                    lines.splice(0, 1);
                    stdout = lines.join('\n');
                }
                socket.emit(input.cmd, {
                    'cmd': input.cmd,
                    'output': stdout,
                    input_obj: input
                });
            });
            child.on('error', function(err) {
                socket.emit('cmd', {
                    'cmd': 'cmd',
                    'output': "An error occurred while getting the user information.\n"
                });
            });
        }
    }
}

function move_file_on_server(source, target_folder, target_file, socket, session, signal, del_file) {
    if (session !== undefined) {
        if (session.user_id !== undefined) {
            var cmdline = "cp " + source + " ";
            if (target_folder !== undefined) {
                cmdline += target_folder + "/";
            }
            cmdline += target_file;
            console.log(cmdline);
            //	    console.log(cmdline);
            var socketid = sockets[session.user_id];
            var child = child_process.exec("sudo -u " + session.user_id + " " + cmdline, {
                cwd: tmp
            }, function(error, stdout, stderr) {
                if (error !== null) {
                    debug('exec error ' + error);
                }
                if (del_file) {
                    unlink_file(source);
                }
                if(socket !== undefined) {
                  socket.emit(signal, {
                    'cmd': signal,
                    'output': stdout,
                    'source': source,
                    'target_folder': target_folder,
                    'target_file': target_file
                  });
                }
            });
            child.on('error', function(err) {
              if(socket !== undefined) {
                socket.emit('cmd', {
                    'cmd': 'cmd',
                    'output': "An error occurred while moving a file on the server.\n"
                });
              }
            });
        }
    }
}

function unlink_file(filePath) {
    fs.unlink(filePath, function(err) {
        if (err) return debug(err);
    });
}

function copyFileSync(srcFile, destFile) {
    var BUF_LENGTH, buff, bytesRead, fdr, fdw, pos;
    BUF_LENGTH = 64 * 1024;
    buff = new Buffer(BUF_LENGTH);
    fdr = fs.openSync(srcFile, "r");
    fdw = fs.openSync(destFile, "w");
    bytesRead = 1;
    pos = 0;
    while (bytesRead > 0) {
        bytesRead = fs.readSync(fdr, buff, 0, BUF_LENGTH, pos);
        fs.writeSync(fdw, buff, 0, bytesRead);
        pos += bytesRead;
    }
    fs.closeSync(fdr);
    return fs.closeSync(fdw);
};

function chomp(raw_text) {
    return raw_text.replace(/(\n|\r)+$/, '');
}

function run_r_script(socket, input, session) {
    if (session !== undefined) {
        if (session.user_id !== undefined) {
            var fs = require('fs');
            child = child_process.exec('sudo -u ' + session.user_id + ' ' + input.cmdline, {}, function(error, stdout, stderr) {
                if (error !== null) {
                    debug('exec error ' + error);
                }
                if (stdout.match(/^spawn/)) {
                    var lines = stdout.split('\n');
                    lines.splice(0, 1);
                    stdout = lines.join('\n');
                }
                if (stdout.match(/^Password:/)) {
                    var lines = stdout.split('\n');
                    lines.splice(0, 1);
                    stdout = lines.join('\n');
                }
                debug("Executing command: " + input.cmdline);
                var lines = stdout.split('\n');
                var pdf;
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].match(/\*\* Output/)) {
                        pdf = lines[i].replace("** Output file: ", "");
                        pdf = chomp(pdf.replace("pirana_reports/", ""));
                    }
                }
                var fs = require('fs');
                var tmp_pdf = tmp;
                mkdirp.sync(tmp_pdf);
                fs.exists(input.folder + '/pirana_reports/' + pdf, function(exists) {
                    if (exists) {
                        copyFileSync(input.folder + '/pirana_reports/' + pdf, tmp_pdf + '/' + pdf); // needs to be subfolder of piranajs/public
                        fs.exists(tmp_pdf + '/' + pdf, function(exists2) {
                            if (exists2) {
                                socket.emit('server_file_viewer', {
                                    'cmd': 'server_file_viewer',
                                    'file_url': 'tmp/' + pdf,
                                    "format": "pdf"
                                });
                            } else {
                                socket.emit('run_r_script', {
                                    'cmd': 'run_r_script',
                                    'output': "An error occurred while copying the file, see error message below.\n\n" + stdout
                                });
                            }
                        });
                    } else {
                        socket.emit('run_r_script', {
                            'cmd': 'run_r_script',
                            'output': "An error occurred while creating the PDF, please see\noutput from R below.\n\n" + stdout
                        });
                    }
                });
            });
            child.on('error', function(err) {
                socket.emit('run_r_script', {
                    'cmd': 'run_r_script',
                    'output': "An error occurred while running the R-script.\n"
                });
            });
        }
    }
};

function read_file (file, socket, session, cmd, input) {
    console.log("Reading file");
    if (session !== undefined) {
      console.log("sudo -u " + session.user_id + " -s cat " + file);
        var child = child_process.exec("sudo -u " + session.user_id + " -s cat " + file, function(error, stdout, stderr) {
          console.log(stdout);
            socket.emit(input.cmd, {
                'cmd': input.cmd,
                'file': input.file,
                'output': stdout,
                'mode': input.mode
            });
        });
        child.on('error', function(err) {
           console.log(err);
            socket.emit('cmd', {
                'cmd': 'cmd',
                'file': input.file,
                'output': "An error occurred while reading the files this folder.\n"
            });
        });
    } else {
      console.log("session undefined!!!");
    }
}

function get_latest_file(dir, files) {
    // var files = fs.readdirSync(dir);
    return _.max(files, function (f) {
        var fullpath = path.join(dir, f);
        // replace with mtime for modification time
        return fs.statSync(fullpath).ctime;
    });
}

function get_files(socket, folder, cmd, type, input) {
    var child = child_process.exec("find . -type f -maxdepth 1 | grep -v '\\./\\.'", {
        cwd: folder
    }, function(error, stdout, stderr) {
        var f = stdout.split('\n');
        var arr = [];
        var length = f.length;
        for (var i = 0; i < length; i++) {
            arr = arr.concat({
                file: f[i].replace('./', '')
            });
        }
        if (error !== null) {
            debug('exec error ' + error);
        }
        socket.emit(cmd, {
            'cmd': cmd,
            'output': arr
        });
    });
    child.on('error', function(err) {
        socket.emit('cmd', {
            'cmd': 'cmd',
            'output': "An error occurred while reading the files this folder.\n"
        });
    });
}
