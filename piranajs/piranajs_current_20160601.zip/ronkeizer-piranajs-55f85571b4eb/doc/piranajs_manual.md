---
title: PiranaJS manual & tutorial
author: Ron Keizer, October 2015

header-includes:
    - \usepackage{setspace}
    - \usepackage{color}
    - \usepackage{float}
    - \usepackage{enumitem}
    - \usepackage{listings}
    - \lstset{basicstyle=\small\ttfamily,breaklines=true,backgroundcolor=\color{lightGrey}}
    - \usepackage{hyperref}
    - \usepackage{lscape}
    - \definecolor{PiranaOrange}{rgb}{0.9,0.4,0.1}
    - \definecolor{Blue}{rgb}{0.0,0.0,0.7}
    - \definecolor{Red}{rgb}{0.7,0.0,0.0}
    - \definecolor{Grey}{rgb}{0.4,0.4,0.4}
    - \definecolor{Grey}{rgb}{0.4,0.4,0.4}
    - \definecolor{LightGrey}{rgb}{0.92,0.92,0.92}
    - \definecolor{grey2}{rgb}{.92, .92, .92}    
    - \renewcommand{\familydefault}{\sfdefault}
    - \renewcommand{\caption}{}
    - \usepackage{mathpazo}
    - \textheight 17.5cm    
    - \newcommand{\test}{\textcolor{Blue}{\textit{test}}\xspace}
    - \newcommand{\reference}{\textcolor{Green}{\textit{reference}}\xspace}
    - \newcommand{\valpsn}{\textcolor{Blue}{\textit{valpsn}}\xspace}
    - \newcommand{\ValPsN}{\textcolor{PiranaOrange}{\textit{ValPsN}}\xspace}
    - \newcommand{\psn}[1]{\textcolor{Grey}{#1}}    
    - \newcommand{\fname}[1]{\textit{#1}}
    - \newcommand{\action}[1]{\textcolor{Red}{\textit{#1}}}
    - \newcommand{\command}[1]{{\ttfamily{#1}}}    
---

![](images/pirana_logo_small.jpg)

## Introduction

PiranaJS is the web-based version of [Pirana](http://wwww.pirana-software.com), a workbench for
pharmacometricians aimed at facilitating the use of NONMEM, PsN,
R/Xpose, and other software. PiranaJS needs to be installed and
configured on a Linux or OSX system, along with several
dependencies. Since PiranaJS runs in the browser there are no
client-side dependencies other than a modern browser and a network connection. However, the
user is required to have a system account on the server and the user's
credentials will be requested upon login in the web application.

Similar to the original Pirana software, PiranaJS is licensed under
two licenses: for academic use, a Creative Commons license
(Attribution-NonCommercial-NoDerivs 3.0) allows free use of the
software for non-commercial use. For commercial use, proprietary
software licenses are available. Please check the Pirana website
(www.pirana-software.com), or contact us for more information
(info@pirana-software.com). Commercial use of PiranaJS on IaaS solutions like Amazon EC2 or Google Compute Engine is restricted to use within the [Metworx](http://www.metworx.com) platform.

### Installation

The installation procedure is detailed in the PiranaJS Installation Guide. PiranaJS can be installed on Linux and Mac OS X. PiranaJS on Windows servers might be possible with some modifications but will not be officially supported. Metworx, a cloud-based modeling & simulation platform developed by Metrum Research Group, comes with PiranaJS pre-installed by default (although a separate license must be purchased).

### Transferring from Pirana to PiranaJS

We have made efforts to keep the interface for PiranaJS as much the same as the one for Pirana Desktop as possible. Obviously, you will notice minor differences, also in what functionality is offered and how you interact with the software.  

## Working with PiranaJS

### First steps

- logging in
- auto logout

### The interface

- main parts (take from Pirana manual)

### Running NONMEM

- through nmfe directly
- through PsN (recommended)

### Diagnostic plots

- Data Inspector
- creating PDFs

### Working with the Grid Engine

-
- show 

## Miscellaneous features

### Model translation
