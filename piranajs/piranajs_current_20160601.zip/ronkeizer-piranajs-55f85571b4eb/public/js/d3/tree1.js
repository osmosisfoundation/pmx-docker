var xGap = 80;
var maxWidth = 800;
var yHeight = 400;

var m = [20, 120, 20, 120],
    w = maxWidth - m[1] - m[3],
    h = yHeight - m[0] - m[2],
    i = 0,
    root;

var tree = d3.layout.tree()
    .size([h, w]);

var diagonal = d3.svg.diagonal()
    .projection(function(d) { return [d.y, d.x]; });

var vis = d3.select("#vrr_inside")
    .append("svg:svg")
    .attr("width", w + m[1] + m[3])
    .attr("height", h + m[0] + m[2])
    .append("svg:g")
    .attr("transform", "translate(" + m[3] + "," + m[0] + ")");

// Add tooltip div
var balloon1 = d3.select("#vrr_inside").append("div")
    .attr("class", "tooltip1")
    .style("opacity", 1e-6);
var balloon2 = d3.select("#vrr_inside").append("div")
    .attr("class", "tooltip2")
    .style("opacity", 1e-6);
var balloon3 = d3.select("#vrr_inside").append("div")
    .attr("class", "tooltip3")
    .style("opacity", 1e-6);

refresh_vrr = function(json) {
    root = json;
    root.x0 = h / 2;
    root.y0 = 0;
    function toggleAll(d) {
    if (d.children) {
        d.children.forEach(toggleAll);
        toggle(d);
    }
    }
    update(root);

    d3.select("#download")
    .on("mouseover", function(){
            var html = d3.select("svg")
        .attr("version", 1.1)
        .attr("xmlns", "http://www.w3.org/2000/svg")
        .node().parentNode.innerHTML;

            d3.select(this)
        .attr("href-lang", "image/svg+xml")
        .attr("href", "data:image/svg+xml;base64,\n" + btoa(html));
    });
}

function update(source) {
    var duration = d3.event && d3.event.altKey ? 5000 : 500;

    // Compute the new tree layout.
    var nodes = tree.nodes(root).reverse();

    // Normalize for fixed-depth. (x-length of nodes)
    nodes.forEach(function(d) {
    d.y = d.depth * xGap;
    });

    // Update the nodes
    var node = vis.selectAll("g.node")
    .data(nodes, function(d) { return d.id || (d.id = ++i); });

    // Enter any new nodes at the parent's previous position.
    var nodeEnter = node.enter().append("svg:g")
    .attr("class", "node")
    .attr("transform", function(d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
    .on("click", function(d) { toggle(d); update(d); });

    nodeEnter.append("svg:circle")
    .attr("r", 1e-6)
    .on("mouseover", function (d) {mouseover(d);})
//        .on("mousemove", function(d) {mousemove(d);})
        .on("mouseout", mouseout);

    nodeEnter.append("svg:text")
        .attr("dx", 12)
        .attr("dy", 3)
        .text(function(d) { return model_label(d) })

    // nodeEnter.append("svg:text")
    //  .attr("x", function(d) { return d.children || d._children ? -10 : 10; })
    //  .attr("dy", ".35em")
    //  .attr("text-anchor", function(d) { return d.children || d._children ? "end" : "start"; })
    //  .text(function(d) { return d.name+" ("+d.dofv+")"; })
    //  .style("fill-opacity", 1e-6);

    // Transition nodes to their new position.
    var nodeUpdate = node.transition()
    .duration(duration)
    .attr("transform", function(d) {
            return "translate(" + d.y + "," + d.x + ")";
    });

    nodeUpdate.select("circle")
    .attr("r", function(d) { return node_size(d); })
    .style("stroke", function(d) { return node_stroke (d); })
    .style("stroke-width", function(d) { return node_stroke_width (d); })
    .style("fill", function(d) { return node_color (d); });

    nodeUpdate.select("text")
    .style("fill-opacity", 1);

    // Transition exiting nodes to the parent's new position.
    var nodeExit = node.exit().transition()
    .duration(duration)
    .attr("transform", function(d) { return "translate(" + source.y + "," + source.x + ")"; })
    .remove();

    nodeExit.select("circle")
    .attr("r", 1e-6);

    nodeExit.select("text")
    .style("fill-opacity", 1e-6);

    // Update the links…
    var link = vis.selectAll("path.link")
    .data(tree.links(nodes), function(d) {
            return d.target.id;
    });

    // Enter any new links at the parent's previous position.
    link.enter().insert("svg:path", "g")
    .attr("class", "link")
    .attr("d", function(d) {
            var o = {x: source.x0, y: source.y0};
            return diagonal({source: o, target: o});
    })
    .transition()
    .duration(duration)
    .attr("d", diagonal);

    // Transition links to their new position.
    link.transition()
    .duration(duration)
    .attr("d", diagonal);

    // Transition exiting nodes to the parent's new position.
    link.exit().transition()
    .duration(duration)
    .attr("d", function(d) {
            var o = {x: source.x, y: source.y};
            return diagonal({source: o, target: o});
    })
    .remove();

    // Stash the old positions for transition.
    nodes.forEach(function(d) {
    d.x0 = d.x;
    d.y0 = d.y;
    });

    d3.selectAll("path")
    .style("opacity", "1")
//      .style("stroke-dasharray", 8, 5 )
        .style("stroke-dasharray", function(d) { return d.target.nested == 1? (1,0) : 5; })
        .style("stroke-width", function(d) { return d.target.final_path == 1? "4px" : "2px"; })
        .style("stroke", function(d) { return d.target.final_path == 1 ? "#69c" : "#ccc"; })
    .style("fill", "none");

}

// Toggle children.
function toggle(d) {
    if (d.children) {
    d._children = d.children;
    d.children = null;
    } else {
    d.children = d._children;
    d._children = null;
    }
}
function model_label (d) {
//    label = d.name+" ("+d.dofv+")";
    label = d.name;
    if (d.name == "") {
    label = "";
    }
    return label;
}

function node_size(d) {
    size = 6
    return size;
}

function node_stroke(d) {
    color = "#fff";
    if (d.n_children > 0) {
    color = "#555";
    }
    return color;
}

function node_stroke_width (d) {
    width = 0;
    if (d.n_children > 0) {
    width = 3;
    }
    return width;
}

var x_offs = -15;
var y_offs = -60;
function mouseover(d) {
    if (d.name) {
    balloon1.transition().duration(100).style("opacity", .8);
    balloon2.transition().duration(100).style("opacity", .8);
    balloon3.transition().duration(100).style("opacity", .8);
    balloon1.text(d.descr)
            .style("left", (d3.event.pageX+x_offs) + "px")
            .style("top", (d3.event.pageY+y_offs) + "px");
    balloon2.text("OFV: " + d.ofv + ",  dOFV: " + d.dofv)
            .style("left", (d3.event.pageX+x_offs ) + "px")
            .style("top", (d3.event.pageY+19+y_offs) + "px");
    balloon3.text("Notes: " + d.notes)
            .style("left", (d3.event.pageX+x_offs) + "px")
            .style("top", (d3.event.pageY+37+y_offs) + "px");
    }
}

function mousemove(d) {
    balloon1.text("Descr: " + d.descr)
        .style("left", (d3.event.pageX+x_offs) + "px")
        .style("top", (d3.event.pageY+y_offs) + "px");
    balloon2.text("OFV: " + d.ofv + "   dOFV: " + d.dofv)
        .style("left", (d3.event.pageX+x_offs) + "px")
        .style("top", (d3.event.pageY+19+y_offs) + "px");
    balloon3.text("Notes: " + d.notes)
        .style("left", (d3.event.pageX+x_offs) + "px")
        .style("top", (d3.event.pageY+37+y_offs) + "px");
}

function mouseout() {
    balloon1.transition().duration(100).style("opacity", 1e-6);
    balloon2.transition().duration(100).style("opacity", 1e-6);
    balloon3.transition().duration(100).style("opacity", 1e-6);
}

function node_color(d) {
    color = "#cc3";
    if (d.dofv < -3.84) {
    color = "#3c3";
    }
    if (d.dofv > 0) {
    color = "#c33";
    }
    if (d.data_diff == 1) {
    color = "#bbb";
    }
    if (d.name == "") {
    color = "#bbb";
    }
    if (d.ofv == 0) {
    color = "#bbb";
    }
    return color;
}
