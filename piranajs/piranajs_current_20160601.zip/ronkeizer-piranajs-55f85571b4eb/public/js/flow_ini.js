// file upload
function start_file_upload_support() {
  if (!r.support) {
    popup_msg("notice", "Note: your browser does not support stable file uploads. Use Firefox 4+, Chrome 11+, Safari 6+ or Internet Explorer 10+ if you want to use upload functionality in PiranaJS.");
    return;
  } else {
    r.assignDrop($('#main_drop'));
  }
  // Handle file add event
  r.on('fileAdded', function(file) {
    flow_loaded = true;
    // Show progress bar
    $("#upload_window").dialog("open");
    $("#upload_window").focus();
    $('.flow-progress, .flow-list').show();
    // Add the file to the list
    $('.flow-list').append(
      '<tr class="flow-file flow-file-' + file.uniqueIdentifier + '">' +
      '<td width=345 class="flow-file-name"></td> ' +
      '<td width=65 class="flow-file-size"></td>' +
      '<td width=115><span class="flow-file-progress"></td> ' +
      '<td align="right">' +
      //'<span class="flow-file-pause">' +
      //'<i class="fa fa-pause grey"></i></span>&nbsp;' +
      //'<span class="flow-file-resume">' +
      //'<i class="fa fa-play grey"></i></span>&nbsp;' +
      //'<span class="flow-file-cancel">' +
      '<i class="fa fa-close grey"></i>' +
      '</span></td></tr>');
    var $self = $('.flow-file-' + file.uniqueIdentifier);
    $self.find('.flow-file-name').text(file.name);
    $self.find('.flow-file-size').text(readablizeBytes(file.size));
    $self.find('.flow-file-download').attr('href', '/download/' + file.uniqueIdentifier).hide();
    $self.find('.flow-file-pause').on('click', function() {
      file.pause();
      $self.find('.flow-file-pause').hide();
      $self.find('.flow-file-resume').show();
    });
    $self.find('.flow-file-resume').on('click', function() {
      file.resume();
      $self.find('.flow-file-pause').show();
      $self.find('.flow-file-resume').hide();
    });
    $self.find('.flow-file-cancel').on('click', function() {
      file.cancel();
      $self.remove();
    });
  });
  r.on('filesSubmitted', function(file) {
    r.upload();
  });
  r.on('complete', function() {
    // Hide pause/resume when the upload has completed
    $('.flow-progress .progress-resume-link, .flow-progress .progress-pause-link').hide();
  });
  r.on('fileSuccess', function(file, message) {
    var $self = $('.flow-file-' + file.uniqueIdentifier);
    // Reflect that the file upload has completed
    $self.find('.flow-file-progress').text('(completed)');
    $self.find('.flow-file-pause, .flow-file-resume').remove();
    $self.find('.flow-file-download').attr('href', '/download/' + file.uniqueIdentifier).show();
  });
  r.on('fileError', function(file, message) {
    // Reflect that the file upload has resulted in error
    $('.flow-file-' + file.uniqueIdentifier + ' .flow-file-progress').html('(file could not be uploaded: ' + message + ')');
  });
  r.on('fileProgress', function(file) {
    // Handle progress for both the file and the overall upload
    $('.flow-file-' + file.uniqueIdentifier + ' .flow-file-progress')
      .html(Math.floor(file.progress() * 100) + '% ' + readablizeBytes(file.averageSpeed) + '/s ' + secondsToStr(file.timeRemaining()) + '');
    $('.progress-bar').css({
      width: Math.floor(r.progress() * 100) + '%'
    });
    if(r.progress() === 1) {
      refresh_pirana();
    }
  });
  r.on('uploadStart', function() {
    // Show pause, hide resume
    $('.flow-progress .progress-resume-link').hide();
    $('.flow-progress .progress-pause-link').show();
  });
  r.on('catchAll', function() {
    // console.log.apply(console, arguments);
  });
  window.r1 = {
    pause: function() {
      r.pause();
      // Show resume, hide pause
      $('.flow-file-resume').show();
      $('.flow-file-pause').hide();
      $('.flow-progress .progress-resume-link').show();
      $('.flow-progress .progress-pause-link').hide();
    },
    cancel: function() {
      r.cancel();
      $('.flow-file').remove();
    },
    upload: function() {
      $('.flow-file-pause').show();
      $('.flow-file-resume').hide();
      r.resume();
    },
    flow: r
  };
};

function readablizeBytes(bytes) {
  var s = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'];
  var e = Math.floor(Math.log(bytes) / Math.log(1024));
  return (bytes / Math.pow(1024, e)).toFixed(2) + " " + s[e];
}

function secondsToStr(temp) {
  function numberEnding(number) {
    return (number > 1) ? 's' : '';
  }
  var years = Math.floor(temp / 31536000);
  if (years) {
    return years + ' year' + numberEnding(years);
  }
  var days = Math.floor((temp %= 31536000) / 86400);
  if (days) {
    return days + ' day' + numberEnding(days);
  }
  var hours = Math.floor((temp %= 86400) / 3600);
  if (hours) {
    return hours + ' hr' + numberEnding(hours);
  }
  var minutes = Math.floor((temp %= 3600) / 60);
  if (minutes) {
    return minutes + ' min' + numberEnding(minutes);
  }
  var seconds = temp % 60;
  return seconds + ' sec' + numberEnding(seconds);
}
