### R script supplied with jsPirana
### by Ron Keizer, 2010
### Descr: This script is used as a CLI to ggplot2
### Usage: system("R --vanilla --args --wd=/working_folder out=test.svg data=pktab1 x=DV y=TIME facet1=CENT < datainspector_plot.R")

## handle arguments
args <- commandArgs(trailingOnly = TRUE)
print (args)
arg <- list()
for (i in seq(args)) {
  spl <- strsplit(args[i], "=")[[1]]
  arg[[spl[1]]] = spl[2]
}

## Initialize
orig_wd <- getwd()
library(ggplot2)
if (!is.null(arg$wd)) {
  setwd(arg$wd)
}

## Read data
if (length(grep(".csv", arg$data))>0) {
  format = "csv"
  data <- read.csv(file=arg$data)
} else {
  format = "tab"
  data <- read.table(file=arg$data, header=T, skip=1)
}

## Handle some arguments
if (arg$colour == "none") {
  arg$colour <- NULL
} else {
  if (length(unique(data[[arg$colour]]))<8) {
    data[[arg$colour]] <- as.factor(data[[arg$colour]])
  }
}
if (arg$group == "none") {
  arg$group <- NULL
}

## Create the base plot
pl <- ggplot(data, mapping=aes_string(x=arg$x, y=arg$y,
                            group=arg$group,
                            colour=arg$colour)) +
  xlab (arg$x) +
  ylab (arg$y)
if (!is.null(arg$point)) {
  if (arg$point != 'false' & arg$point != '0') {
    pl <- pl + geom_point()
  }
} else { # assume points are wanted
    pl <- pl + geom_point()
}
if (!is.null(arg$line)) {
  if (arg$line != 'false' & arg$line != '0') {
    pl <- pl + geom_line()
  }
}
if (!is.null(arg$smooth)) {
  if (arg$smooth != 'none' & arg$smooth != '0') {
    pl <- pl + geom_smooth(method=arg$smooth)
  }
}

## Add faceting if requested
if (is.null(arg$facet1)) { arg$facet1 <- "none" }
if (is.null(arg$facet2)) { arg$facet2 <- "none" }
if (arg$facet1 == 'none') { fac1 <- "." } else { fac1 <- arg$facet1 }
if (arg$facet2 == 'none') { fac2 <- "." } else { fac2 <- arg$facet2 }
if (arg$facet1 != 'none' | arg$facet2 != "none") {
  facets <- facet_grid(paste(fac1, " ~ ", fac2, sep=""))
  pl <- pl + facets
}

## Other specifications
as.num <- function(x) { as.numeric(as.character(x)) }
if(!(as.num(arg$xv2) == 100 && as.num(arg$xv1) == 0)) {
  xr <- diff(range(data[[arg$x]]))
  xview <- c(min(data[[arg$x]]) + as.num(arg$xv1)/100 * xr, min(data[[arg$x]]) + as.num(arg$xv2)/100 * xr)
  pl <- pl + xlim(xview)
}
if(!(as.num(arg$yv2) == 100 && as.num(arg$yv1) == 0)) {
  yr <- diff(range(data[[arg$y]]))
  yview <- c(min(data[[arg$y]]) + as.num(arg$yv1)/100 * yr, min(data[[arg$y]]) + as.num(arg$yv2)/100 * yr)
  pl <- pl + ylim(yview)
}
if (!is.null(arg$axes)) {
  if (arg$axes == "logX" | arg$axes == "logX+logY") {
    pl <- pl + scale_x_log10()
  }
  if (arg$axes == "logY" | arg$axes == "logX+logY") {
    pl <- pl + scale_y_log10()
  }
}
if (!is.null(arg$unity) && arg$unity == "true") {
  pl <- pl + geom_abline(intercept = 0, slope = 1, colour='#5897FB', size=1)
}
if (!is.null(arg$x_lab)) {
  pl <- pl + xlab(arg$x_lab)
}
if (!is.null(arg$y_lab)) {
  pl <- pl + ylab(arg$y_lab)
}

theme_plain <-  function () {
  theme(
    text = element_text(family="mono"),
    plot.title = element_text(family="sans", size = 16, vjust = 1.5),
    axis.title.x = element_text(family="sans",vjust=-0.25),
    axis.title.y = element_text(family="sans"),
    legend.background = element_rect(fill = "white"),
    #legend.position = c(0.14, 0.80),
    panel.grid.major = element_line(colour = "#e5e5e5"),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "#efefef", colour = NA),
    strip.background = element_rect(fill = "#444444", colour = NA),
    strip.text = element_text(face="bold", colour = "white")
  )
}
pl <- pl + theme_plain()

## Save file
if (is.null(arg$out)) { arg$out <- "Rplot1.svg"}
if (is.null(arg$width)) { arg$width <- 6 }
if (is.null(arg$height)) { arg$height <- 5 }
ggsave(file=arg$out, plot=pl, width=arg$width, height=arg$height)
file_png <- gsub(".svg", ".png", arg$out)
ggsave(file=file_png, plot=pl, width=arg$width, height=arg$height)

quit()
