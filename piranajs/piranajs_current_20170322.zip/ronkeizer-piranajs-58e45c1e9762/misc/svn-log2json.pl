my $dir = @ARGV[0];
my $n = @ARGV[1];
if ($n eq "") { $n = 16};
chdir($dir);
my $cmd = "svn log --limit 10";
open (OUT, $cmd . " |");
my @lines = <OUT>;
my $i = 0; my $idx = 0;
my %tmp; my @all;
foreach (@lines) {
    if ($_ =~ m/^\-\-\-/) {
        $i = 0;
        if ($idx > 0) {
          push (@all, \%tmp);
        }
        $idx++;
    } else {
        $i++;
    }
    if ($i == 1) {
        my @info = split(" | ", $_);
        $tmp{rev} = @info[0];
        $tmp{user} = @info[1];
        $tmp{date} = @info[2];
        $tmp{what} = @info[3];
    }
    if ($i > 1) {
        $tmp{message} .= $_;
    }
}
close OUT;

print @all;
