////////////////////////////////////////////////////////////////////////////
// Setup, read ini file
////////////////////////////////////////////////////////////////////////////
var version = "1.4.0";
process.env.TMPDIR = 'tmp';
var ini = require('./piranajs.json');
var apirana = ini.commands.apirana;
console.log("\nPiranaJS v", version, "\n================\n");
console.log("- Configuration: \n", ini, "\n");

////////////////////////////////////////////////////////////////////////////
// Express4 libraries
////////////////////////////////////////////////////////////////////////////
var express = require('express')
  , expressValidator = require('express-validator')
  , favicon = require('serve-favicon')
  , morgan = require('morgan')
  , methodOverride = require('method-override')
  , cookieParser = require('cookie-parser')
  , session = require('express-session')
  , bodyParser = require('body-parser')
  , errorHandler = require('errorhandler')
  , json = require('express-json')
  , methodOverride = require('method-override')
  , sessionStore = new session.MemoryStore();

////////////////////////////////////////////////////////////////////////////
// Libraries
////////////////////////////////////////////////////////////////////////////
var app = express()
  , fs = require('fs')
  , path = require('path')
  , http = require('http')
  , https = require('https')
  , mkdirp = require('mkdirp')
  , child_process = require('child_process')
  , connect = require('connect')
  , multipart = require('connect-multiparty') // file uploads
  , multipartMiddleware = multipart()  // file uploads
  , debug = require('debug')('nodejs')
  , args = require('minimist')(process.argv.slice(2))
  , _ = require('underscore')
  , argv = require('minimist')(process.argv.slice(2))
  , util = require('util')
  , pty = require('pty.js')
  , terminal = require('./term.js')
  , mv = require('mv')
  , os = require('os')
  , flow = require('./flow/flow-node.js')('tmp') // file uploads
;

////////////////////////////////////////////////////////////////////////////
// Custom libraries
////////////////////////////////////////////////////////////////////////////
var  auth = require('./lib/auth')
  , routes = require('./lib/routes')
  , diskio = require('./lib/diskio')
  , misc = require('./lib/misc')
  , r = require('./lib/r')
  , cmd = require('./lib/cmd')
;

////////////////////////////////////////////////////////////////////////////
// Platform settings
////////////////////////////////////////////////////////////////////////////
var platform = os.platform();
var folders = {}; // store locations where users are
var sudo_login_flag = " -i ";
if(platform == "darwin") {
  sudo_login_flag = " ";
}

////////////////////////////////////////////////////////////////////////////
// Check license
////////////////////////////////////////////////////////////////////////////
var key = "mavericks";
var license_info = {};
auth.read_license_file(key, ini, auth.print_license_info);

////////////////////////////////////////////////////////////////////////////
// Custom R libraries
////////////////////////////////////////////////////////////////////////////
var ggplot = require('./lib/ggplot');
if(ini.custom.user_r_libs && ini.custom.user_r_libs !== "") {
  process.env.R_LIB = ini.custom.user_r_libs;
}
if(ini.custom.user_r_scripts && ini.custom.user_r_scripts !== "") {
  process.env.R_SCRIPTS = ini.custom.user_r_scripts;
}

////////////////////////////////////////////////////////////////////////////
// Express
////////////////////////////////////////////////////////////////////////////
var accessLogStream = fs.createWriteStream(__dirname + '/log/stdout.log', { flags: 'a' });
app.use(morgan('combined', {stream: accessLogStream}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(expressValidator()); // immediately after bodyParser()
app.use(methodOverride());
app.use(cookieParser('secret'));
app.use(session({
    store: sessionStore,        // We use the session store created above
    resave: false,              // Do not save back the session to the session store if it was never modified during the request
    saveUninitialized: false,    // Do not save a session that is "uninitialized" to the store
    secret: 'secret',           // Secret used to sign the session ID cookie. Must use the same as speficied to cookie parser
    name: EXPRESS_SID_KEY,       // Custom name for the SID cookie
    maxAge:  7 * 24 * 3600 * 1000
}));
if (ini.general.trust_proxy) {
  app.set('trust proxy', 1) // trust first proxy
}
if (process.env.NODE_ENV === 'development') {  // only use in development
  app.use(errorhandler())
}
app.use(terminal.middleware());
app.use(express.static(__dirname + '/public/')); // static files
var EXPRESS_SID_KEY = 'connect.sid';

////////////////////////////////////////////////////////////////////////////
// Misc settings
////////////////////////////////////////////////////////////////////////////
var cwd = require('path').dirname(require.main.filename);
var port = ini.general.port_http;
if (ini.general.https == true) {
  port = ini.general.port_https;
}
app.set('port', process.env.PORT || port);

////////////////////////////////////////////////////////////////////////////
// File upload
////////////////////////////////////////////////////////////////////////////
var upload_file = function(req, res) {
  flow.post(req, function(status, filename, original_filename, identifier, numberOfChunks) {
    // console.log('POST', status, original_filename, identifier, numberOfChunks);
    var tmp_full = tmp_local + '/' + filename
    if (status === 'done') {
      var stream = fs.createWriteStream(tmp_full);
      flow.write(identifier, stream);
      stream.on('close', function() { // clean up
        for (i = 1; i <= numberOfChunks; i++) {
          fs.unlink(tmp_local + '/flow-'+identifier+'.'+i);
        }
        var base_folder = folders[req.cookies.username];
        var full_folder = base_folder + "/" + path.dirname(req.body.flowRelativePath);
        var mkdir = child_process.exec("sudo -u " + req.cookies.username + " -s mkdir -p " + full_folder, { cwd: base_folder }, function(error, stdout, stderr) {
          if (error) {
            console.error(error)
          } else {
            var dirs = req.body.flowRelativePath.split('/');
            var full_dirs = [];
            var tmp = "";
            for (var j = 0; j < dirs.length; j++) {
              if(j == 0) {
                full_dirs.push(dirs[j]);
                tmp = dirs[j];
              } else {
                tmp = tmp + "/" + dirs[j];
                full_dirs.push(tmp);
              }
            }
            var all_dirs = full_dirs.join(" ");
            if(full_folder) {
              full_folder.replace(/\!/g, '/');
            }
            diskio.move_file_on_server(tmp_full, full_folder, filename, undefined, { "user_id" : req.cookies.username }, '', true, res);
          }
        });
      });
    }
  })
};

var upload_file_check = function(req, res) {
  flow.get(req, function(status, filename, original_filename, identifier) {
    console.log('GET', status);
    res.send(status == 'found' ? 200 : 404);
  });
};

////////////////////////////////////////////////////////////////////////////
// Routing
////////////////////////////////////////////////////////////////////////////
var router = express.Router();
router.get('/', routes.index);
router.get('/logout', routes.logout);
// router.get('/download/:file', routes.download_file);
router.get('/parse_login', routes.parse_login);
// Routes for uploads through Flow.js
router.post('/upload', multipartMiddleware, upload_file);
router.get('/upload', upload_file_check);
router.get('/download/:identifier', routes.download_flow);
app.use('/', router);

////////////////////////////////////////////////////////////////////////////
// Get home folder for the user and create a tmp folder there
////////////////////////////////////////////////////////////////////////////
var home = process.env['HOME'];
debug("Home folder: " + home);
// var tmp = home + '/.piranajs_tmp';
var tmp = __dirname + '/public/tmp';
var tmp_local = __dirname + '/tmp';
var R_folder = tmp + '/R';
try {
  mkdirp.sync(tmp);
  fs.chmodSync(tmp, 0777); // tmp folder for execution of apirana scripts
  diskio.clean_folder(tmp);
  mkdirp.sync(tmp_local);
  fs.chmodSync(tmp_local, 0777); // tmp folder for uploads
  diskio.clean_folder(tmp_local);
} catch(err) {
  console.log("- Warning: PiranaJS does not have write access temporary folders.");
}
var sockets = {};
var pw = {};
if(ini.custom.user_r_libs && !fs.exists(ini.custom.user_r_libs)) {
  try {
    mkdirp.sync(ini.custom.user_r_libs);
    fs.chmodSync(ini.custom.user_r_libs, 0777); // tmp folder for uploads
  } catch(err) { console.log('- Warning: cannot create folder: ', err.path); }
}
if(ini.custom.user_r_scripts && !fs.exists(ini.custom.user_r_scripts)) {
  try {
    mkdirp.sync(ini.custom.user_r_scripts);
    fs.chmodSync(ini.custom.user_r_scripts, 0777); // tmp folder for uploads
  } catch(err) { console.log('- Warning: cannot create folder: ', err.path); }
}

var stream;
if (process.argv[2] === '--dump') {
  stream = fs.createWriteStream(__dirname + '/dump.log');
}

////////////////////////////////////////////////////////////////////////////
// TTY
////////////////////////////////////////////////////////////////////////////
var buff = [], term;
var term = pty.fork('sh', [], {
  name: fs.existsSync('/usr/share/terminfo/x/xterm-256color') ? 'xterm-256color' : 'xterm',
  cols: 80,
  rows: 24,
  cwd: process.env.HOME
});

////////////////////////////////////////////////////////////////////////////
// Clean up temporary files at specific interval
////////////////////////////////////////////////////////////////////////////
setInterval(function() {
  debug("Cleaning tmp folder\n");
  diskio.clean_folder(tmp);
}, 1 * 60 * 1000);

////////////////////////////////////////////////////////////////////////////
// Define and start server
////////////////////////////////////////////////////////////////////////////
var server_http = http.createServer(app)
var port = ini.general.port_http;
var server;
if (ini.general.use_https === true) {
  var sslOptions = {
    key: fs.readFileSync(ini.ssl.key),
    cert: fs.readFileSync(ini.ssl.cert)
  };
  server_https = https.createServer(sslOptions, app);
  server = server_https;
  port = ini.general.port_https;
} else {
  server = server_http;
}
server.listen(port, function() {
  console.log("- Express server listening on port " + port + "\n");
});

////////////////////////////////////////////////////////////////////////////
// start server and socket
////////////////////////////////////////////////////////////////////////////
var io = require('socket.io')({});

////////////////////////////////////////////////////////////////////////////
// Main I/O with client-side
////////////////////////////////////////////////////////////////////////////
io.listen(server);
io.on('connection', function(socket) {
  console.log('- Socket connected ('+ socket.handshake.address+')');
  socket.emit('session', session);

  ////////////////////////////////////////////////////////////////////////////
  // Client-server talk
  // --> previously using sockets, now using plain http
  ////////////////////////////////////////////////////////////////////////////

  router.post('/api/login', function(req, res) {
      debug('login: ' + req.body.user_id);
      req.body.pw.replace(/[\'\"\\]/, ""); // against XSS attacks
      req.body.user_id.replace(/[\'\"\\]/, "");
      if(!ini.general.auth_method || ini.general.auth_method.toLowerCase() == "pam") {
        // authenticate using PAM, default
        debug("Using PAM to authenticate " + req.body.user_id);
        auth.authenticate_pam(req.body.user_id, req.body.pw, io, socket, sockets, session, res, auth.process_authentication);
      } else {
        if(ini.general.auth_method.toLowerCase() == "ldap") {
          debug("Using PAM to authenticate " + req.body.user_id);
          auth.authenticate_ldap(req.body.user_id, req.body.pw, io, socket, sockets, session, res, auth.process_authentication);
        } else {
          // fallback to legacy method using expect
          debug("Using expect to authenticate " + req.body.user_id);
          auth.authenticate_expect(req.body.user_id, req.body.pw, io, socket, sockets, session, res, auth.process_authentication);
        }
      }
  });
  router.post('/api/get_psn_nm_versions', function(req, res) {
    if(session) {
      var input = req.body;
      input.cmdline = apirana + ' --psn_nm_versions --v=0 --f=json --user=' + session.user_id;
      input.folder = tmp + "/";
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });
  router.post('/api/get_mpi_settings', function(req, res) {
    if(ini) {
      var input = req.body;
      res.status(200).send({'cmd': input.cmd, 'mpi': ini.mpi });
    }
  });
  router.post('/api/get_sge_settings', function(req, res) {
    if(ini) {
      var input = req.body;
      res.status(200).send({'cmd': input.cmd, 'sge': ini.sge });
    }
  });
  router.post('/api/psn_tool_default_args', function(req, res) {
    console.log('get psn defaults');
    var input = req.body;
    input.folder = tmp + '/';
    input.cmdline = apirana + ' -psn_tool_default_args -f=json -v=0';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });
  router.post('/api/get_templates', function(req, res) {
    var input = req.body;
    input.folder = tmp + '/';
    input.cmdline = apirana + " -run_record -dir='" + __dirname + "/templates" + "' -f=json -v=0";
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });
  router.post('/api/get_license_status', function(req, res) {
    console.log('get lic stat');
    var return_license_info = function(license_info) {
      res.status(200).send({
        'license_info': license_info
      });
    }
    auth.read_license_file(key, ini, return_license_info, socket);
  });
  router.post('/api/get_home_folder', function(req, res) {
    console.log('get home folder');
    var input = req.body;
    input.folder = tmp + '/';
    debug("Getting home folder");
    if (session !== undefined) {
      if (!ini.custom.user_home_folder || ini.custom.user_home_folder == "") {
        child = child_process.exec('echo ~' + session.user_id, {}, function(error, stdout, stderr) {
          if (error !== null) {
            debug('Error retrieving home folder ' + error);
          }
          var spl = stdout.split('\n');
          var home_folder = undefined;
          for (var i = 0; i < spl.length; i++) { // slightly different on linux vs osx
            if (!spl[i].match('spawn') && spl[i].length > 5) {
              home_folder = spl[i].replace('\r', '').replace(/\/\//g, "/");;
            }
          }
          if (home_folder !== undefined) {
            if (home_folder.match('Sorry')) {
              socket.emit('cmd', {
                'cmd': 'cmd',
                'output': 'Sorry, that username and password did not match.'
              });
            } else {
              var socketid = sockets[input.user_id];
              debug("Sending back home folder info: " + home_folder + socketid);
              session.home_folder = home_folder;
              res.status(200).send({
                'cmd': 'get_home_folder',
                'folder': home_folder
              });
            }
          } else {
            debug("Home folder not defined!");
          }
        });
        // child.on('error', function(err) {
        //   socket.emit('cmd', {
        //     'cmd': 'cmd',
        //     'output': "An error occurred while getting the user information.\n"
        //   });
        // });
      } else {
        session.home_folder = ini.custom.user_home_folder.replace(/\/\//g, "/");
        res.status(200).send({
          'cmd': 'get_home_folder',
          'folder': ini.custom.user_home_folder.replace(/\/\//g, "/")
        });
      }
    }
  });
  router.post('/api/refresh_projects', function(req, res) {
    if(session) {
      var input = req.body;
      if(input.home) {
        input.home = input.home.replace(/ /, "{s}");
        input.cmdline = apirana + ' --projects --v=0 --f=json --user=' + session.user_id + ' -home=' + session.home_folder.replace(/\/\//g, "/");
        cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
      }
    } else {
      console.log("session ended!");
    }
  });
  router.post('/api/get_project_active', function(req, res) {
    var input = req.body;
    input.home = input.home.replace(/ /, "{s}").replace(/\/\//g, "/");
    input.cmdline = apirana + ' -project_active -v=0 -home=' + session.home_folder.replace(/\/\//g, "/");
    if (session) {
      input.cmdline += ' --user=' + session.user_id;
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/refresh', function(req, res) {
    var input = req.body;
    input.folder = input.folder.replace(/\/\//g, "/");
    folders[input.user_id] = input.folder;
    input.cmdline = apirana + ' -run_record -folders=' + input.folder_filter + ' -dir=' + input.folder + ' -f=json -v=0';
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/message', function(req, res) {
    var input = req.body;
    console.log('message:', input.message);
  });

  router.post('/api/logout', function(req, res) {
    if (session && session.destroy) {
      session.destroy();
    }
    res.status(200).send({
        'output': "Logged out."
    });
  });

  router.post('/api/download_folder', function(req, res) {
    var input = req.body;
    var spl = input.folder.split(/\//);
    var last_part = spl.pop();
    var first_part = spl.join('/');
    input.filename = "download_" + last_part + ".zip";
    input.cmdline = "zip -r " + tmp + "/" + input.filename + " " + last_part + " > " + tmp + "/zip.out";
    input.run_in_folder = first_part;
    var mkzip = child_process.exec(input.cmdline, { cwd: input.run_in_folder }, function(error, stdout, stderr) {
       if(!error) {
           res.status(200).send({
            'output': stdout,
            'input_obj': input
          });
       }
    });
  });

  router.post('/api/get_folder_info', function(req, res) {
    var input = req.body;
    fs.exists(input.folder + input.subfolder + "/command.txt", function(exists) {
      // get NMTRAN error messages
      fs.exists(input.folder + input.subfolder + "/NM_run1/nmtran_error.txt", function(exists) {
        if(exists) {
          var tmp2 = Object.create(input);
          tmp2.cmdline = "cat " + input.folder + tmp2.subfolder + "/NM_run1/nmtran_error.txt";
          tmp2.type = "nmtran_error";
          cmd.cmd_exec(socket, tmp2, session, sockets, tmp, sudo_login_flag, res);
        } else { // show PsN info, if present
          var tmp = Object.create(input);
          tmp.cmdline = "cat " + input.folder + tmp.subfolder + "/command.txt";
          tmp.type = "psn_cmd";
          cmd.cmd_exec(socket, tmp, session, sockets, tmp, sudo_login_flag, res);
        }
      });
    });
  });

  router.post('/api/get_estimates', function(req, res) {
    var input = req.body;
    if (input.file !== '' && input.file !== undefined) {
      var cmdline = apirana + ' -estimates -user='+session.user_id+' -dir=' + input.folder + ' -v=0 -f=json ' + input.file;
      console.log(cmdline);
      child = child_process.exec(cmdline, function(error, stdout, stderr) {
        if (error !== null) {
          debug('exec error ' + error);
        }
        if(socket) {
          res.status(200).send({
            'run': input.file.replace('.lst', ''),
            'output': stdout
          });
        }
      });
      child.on('error', function(err) {
        res.status(200).send({
          'output': "An error occurred while loading this folder.\n"
        });
      });
    } else {
      res.status(200).send({
        'output': "An unknown error occurred while extracting estimates.\n"
      });
    }
  })

  router.post('/api/view_lst', function(req, res) {
    var input = req.body;
    var file_full;
    input.cmd = 'code_editor';
    if (input.file.match(/^\//)) { // possibly a PsN / nmfe folder
      // Query the entry
      stats = fs.lstatSync('/the/path');
      // Is it a directory?
      if (stats.isDirectory()) {
        // Yes it is
      }
      var stats = fs.lstatSync(input.folder + input.file + '/NM_run1/psn-1.lst');
      if (stats.isFile) {
        var file_full = input.folder + input.file + '/NM_run1/psn-1.lst';
        input.cmdline = 'cat ' + file_full;
        input.file = file_full;
        cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
      }
    } else { // file
      var file_full = input.folder + "/" + input.file;
      input.file = file_full;
      input.cmdline = 'cat ' + file_full;
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/compare_estimates', function(req,res) {
    var input = req.body;
    input.cmdline = apirana + ' -compare_estimates -v=0 -f=csv -dir=' + input.folder + ' ' + input.mods.join(" ");
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  })

  router.post('/api/get_notes', function(req, res) {
    var input = req.body;
    fs.exists(input.folder+"/pirana.md", function(e) {
      if (e) {
        diskio.read_file (input.folder + "/pirana.md", socket, session, input.cmd, input, res);
      } else {
        diskio.move_file_on_server(__dirname + '/templates/pirana.md', input.folder, 'pirana.md', socket, session, 'created_new_note', false, res);
      }
    });
  });

  router.post('/api/create_run_record', function(req, res) {
    var input = req.body;
    var today = new Date();
    var d = today.getFullYear().toString()+(today.getMonth()+1).toString()+today.getDate().toString();
    input.filename = "pirana_runrec_"+d+".csv";
    input.run_in_folder = input.folder;
    input.cmdline = "apirana -run_record -user="+session.user_id+" -f=csv -o="+input.filename+" -dir="+input.folder+" -v=0";
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/open_file_in_spreadsheet', function(req, res) {
    var input = req.body;
    // basically same as open in editor, parsing is done client-side since csv/tab is smaller than json
    child = child_process.exec('cat ' + input.folder + '/' + input.file, function(error, stdout, stderr) {
      res.status(200).send({
        'cmd': input.cmd,
        'file': input.file,
        'output': stdout,
        'mode': input.mode
      });
    });
    // child.on('error', function(err) {
    //   socket.emit('cmd', {
    //     'cmd': 'cmd',
    //     'file': input.file,
    //     'output': "An error occurred while reading the files this folder.\n"
    //   });
    // });
  })

  router.post('/api/hide_runs', function(req, res) {
    var input = req.body;
    if (input && input.runs !== undefined) {
      var runs = input.runs.join(" ");
      input.cmdline = apirana + ' -v=0 --hide --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
      input.folder = tmp + '/';
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/unhide_all_runs', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + ' --unhide --all --dir=' + input.folder + ' --user=' + session.user_id;
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/get_data_info', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + ' -data_info=' + input.file + ' -dir=' + input.folder + ' -f=json -v=0';
    input.folder = tmp + '/';
    debug("Data info: " + input.cmdline);
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  })

  router.post('/api/update_data_inspector_plot', function(req, res) {
    var input = req.body;
      dat = input.data.split('\/').pop()
      dat = dat.replace(/\./g, '_');
      input.outfile = 'pl_' + input.user_id + '_' + dat + '_' + input.x_sel + '_' + input.y_sel + '.svg';
      input.cmdline = 'R --vanilla --args wd=' + input.folder + ' out=' + tmp + '/' + input.outfile + ' data=' + input.data + ' x=' + input.x_sel + ' y=' + input.y_sel +
      ' point=' + input.point + ' line=' + input.line +' unity=' + input.unity + ' smooth=' + input.smooth +
      ' facet1=' + input.facet1 + ' facet2=' + input.facet2 + ' x_lab=' + input.x_lab + ' y_lab='+input.y_lab +
      ' colour=' + input.colour + ' group=' + input.group + ' axes=' + input.axes +
      ' xv1='+input.x_range[0]+' xv2='+input.x_range[1] + ' yv1='+input.y_range[0]+' yv2='+input.y_range[1] +
      ' < ' + __dirname + '/R/datainspector_plot.R';
      debug(input.cmdline);
      input.r_folder = input.folder;
      input.folder = tmp + '/';
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/data_inspector_r_code', function(req, res) {
    var input = req.body;
    var code = ggplot.generate_code(input);
    res.status(200).send({
      'cmd': 'data_inspector_r_code',
      'code': code
    });
  });

  router.post('/api/code_editor', function(req, res) {
    var input = req.body;
    var full_file = input.folder + '/' + input.file;
    if (input.folder === undefined) {
      full_file = input.file;
    }
    diskio.read_file (full_file, socket, session, input.cmd, input, res);
  });

  router.post('/api/nm_help_index', function(req, res) {
    var input = req.body;
    input.folder = tmp + '/';
    input.cmdline = apirana + ' -nm_help -f=json -v=0';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/nm_help_topic', function(req, res) {
    var input = req.body;
    input.folder = tmp + '/';
    input.key = input.key.replace(/\$/g, '\\\$');
    input.cmdline = apirana + ' -nm_help=' + input.key + ' -f=json -v=0';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  // router.post('/api/kill_process', function(req, res) {
  //   var input = req.body;
  //   console.log(JSON.stringify(input));
  //   input.cmdline = 'kill -s KILL ' + input.pid;
  //   input.folder = tmp + "/";
  //   cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  // });

  router.post('/api/kill_process', function(req, res) {
    var input = req.body;
    console.log(JSON.stringify(input));
    input.cmdline = 'qdel ' + input.pid;
    input.folder = tmp + "/";
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/rename_file', function(req, res) {
    var input = req.body;
    if (input.newfile !== undefined && input.oldfile !== undefined && input.newfile !== input.oldfile) {
      debug('Renaming file ' + input.oldfile + ' to ' + input.newfile);
      diskio.move_file_on_server(input.folder + '/' + input.oldfile, input.folder, input.newfile, socket, session, 'refresh_pirana', true, res);
    }
  });

  router.post('/api/copy_file', function(req, res) {
    var input = req.body;
    if (input.newfile !== undefined && input.oldfile !== undefined && input.newfile !== input.oldfile) {
      debug('Copying file ' + input.oldfile + ' to ' + input.newfile);
      diskio.move_file_on_server(input.folder + '/' + input.oldfile, input.folder, input.newfile, socket, session, 'refresh_pirana', false, res);
    }
  });

  router.post('/api/translate', function(req, res) {
    var input = req.body;
    to = input.translate_to;
    var out = input.run + ".txt";
    if (to == "R::PKPDsim") {
      out = input.run + ".R";
    }
    if (to == "R::deSolve") {
      out = input.run + ".R";
    }
    if (to == "Matlab") {
      to = "MATLAB";
      out = input.run + ".m";
    }
    if (to == "Berkeley Madonna") {
      to = "BM";
      out = input.run + ".bm";
    }
    if (to == "NONMEM ADVAN6") {
      to = "NM";
      out = input.run + "_ode.mod";
    }
    input.cmdline = apirana + ' --translate --format=' + to + ' --dir=' + input.folder + ' --o=' + out + ' ' + input.run;
    input.out = out;
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/psn_log_add', function(req, res) {
    var input = req.body;
    if(session) {
      input.psn_cmd = input.psn_cmd.replace(/ /g, "{s}");
      input.cmdline = apirana + ' --psn_history_add="' + input.psn_cmd + '" --v=0 --user=' + session.user_id + ' -home='+session.home_folder;
      input.folder = tmp + "/";
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    } else {
      console.log("session ended!");
    }
  });

  router.post('/api/psn_log_clear', function(req, res) {
    var input = req.body;
    if(session) {
      input.cmdline = apirana + ' --psn_history_clear --v=0 --f=json --user=' + session.user_id + ' -home='+session.home_folder;
      input.folder = tmp + "/";
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    } else {
      console.log("session ended!");
    }
  });

  router.post('/api/project_remove', function(req, res) {
    var input = req.body;
    input.home = input.home.replace(/ /g, "{s}");
    input.cmdline = apirana + " -project_remove='" + input.project + "' -v=0 -user=" + session.user_id + ' -home=' + session.home_folder;
    debug('Remove project: ' + input.cmdline + '\n');
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/project_add', function(req, res) {
    var input = req.body;
    input.home = input.home.replace(/ /g, "{s}");
    input.cmdline = apirana + ' -project_add=' + input.project + ' -v=0 -dir=' + input.folder + ' -user=' + session.user_id + ' -home=' + session.home_folder;
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/new_folder', function(req, res) {
    var input = req.body;
    cmdline = "mkdir " + input.folder + "/" + input.new_folder;
    debug("Executing command: " + cmdline);
    input.cmdline = cmdline;
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/get_templates', function(req, res) {
    var input = req.body;
    input.folder = tmp + '/';
    input.cmdline = apirana + " -run_record -dir='" + __dirname + "/templates" + "' -f=json -v=0";
    console.log(input.cmdline);
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/new_model_from_template', function(req, res) {
    var input = req.body;
    debug("Trying to copy template model to new file...");
    input.cmdline = apirana + " -duplicate='" + input.folder + "/" + input.new_model_name + "' -description='" + input.description + "' -f=json -v=0 -force -update_numbers " + __dirname + '/templates/' + input.template_model + '.mod';
    input.folder = tmp + '/';
    // console.log(input.cmdline);
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/copy_script', function(req, res) {
    var input = req.body;
    //        if (cmd.match(/copy_script/g)) {
    var target_folder; // copy to project folder
    if (input.folder_type.match("project")) {
      target_folder = input.folder + "/pirana_scripts";
    }
    if (input.folder_type.match("user")) {
      target_folder = home + "/.pirana/scripts";
    }
    if (input.folder_type.match("custom")) {
      target_folder = ini.custom.user_r_scripts;
    }
    fs.exists(target_folder, function(exists) {
      if (exists) {
        diskio.move_file_on_server(input.script, target_folder, input.new_script, socket, session, 'copy_script', false, res);
      } else {
        var cmdline = "mkdir " + target_folder;
        var socketid = sockets[session.user_id];
        var run_in_folder = tmp;
        console.log("sudo -u " + session.user_id + " -s " + cmdline);
        var child = child_process.exec("sudo -u " + session.user_id + " -s " + cmdline, {
          cwd: run_in_folder
        }, function(error, stdout, stderr) {
          diskio.move_file_on_server(input.script, target_folder, input.new_script, socket, session, 'copy_script', false, res);
        });
      }
    });
  });

  router.post('/api/duplicate', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + " -dir=" + input.folder.replace(/ /g, "{s}") + " -duplicate=" + input.new_mod + " -description=" + input.description.replace(/ /g, "{s}");
    if (input.ue) {
      input.cmdline += ' -ue'
    }
    if (input.un) {
      input.cmdline += ' -un'
    }
    input.cmdline += ' -force ' + input.model;
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/set_info', function(req, res) {
    var input = req.body;
    if (input.runs !== undefined && input.note !== undefined) {
      var runs = input.runs.join(" ");
      input.note = input.note.replace(/ /g, "{s}").replace(/[\(\)]/g, "");
      input.refmod = input.refmod.replace(/ /g, "{s}");
      input.description = input.description.replace(/ /g, "{s}").replace(/[\(\)]/g, "");
      input.author = input.author.replace(/ /g, "{s}");
      input.cmdline = apirana + ' -v=0 -set_info -notes=' + input.note + ' -description=' + input.description + ' -author=' + input.author + ' -refmod=' + input.refmod + ' -dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
      console.log("****" + input.cmdline);
      input.folder = tmp + '/';
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/create_pnm_file', function(req, res) {
    var input = req.body;
    if(ini.mpi.presets[input.preset] && ini.mpi.presets[input.preset].template) {
      var pnm_templ = ini.mpi.presets[input.preset].template;
      if(!ini.mpi.presets[input.preset].template.toString().match(/&\//)) {
        pnm_templ = __dirname + '/' + ini.mpi.presets[input.preset].template;
      }
      if(pnm_templ) {
        fs.readFile(pnm_templ, 'utf8', function(err, data) {
          if(data) {
            data = data.replace(/NODES=[0-9]+/, "NODES="+input.n);
            data = data.replace(/NODES=\[nodes\]/, "NODES="+input.n);
            data = data.replace(/ N_WORKERS/, " "+(Number(input.n)-1).toString());
            var tmp_file = tmp + '/' + input.file + "_" + Math.round(10000 * Math.random());
            fs.writeFile(tmp_file, data, { mode: '777' }, function(err) {
              if (err) {
                console.log(err);
              } else {
                diskio.move_file_on_server(tmp_file, input.folder, input.file, socket, session, 'create_pnm_file', true, res);
              }
            });
          }
        });
      }
    }
  });

  router.post('/api/editor_save', function(req, res) {
    var input = req.body;
    if (input.text !== undefined && input.file !== undefined) {
      var spl = input.file.split(/\//);
      var file = spl.pop();
      var tmp_file = tmp + '/' + file + "_" + Math.round(10000 * Math.random());
      fs.writeFile(tmp_file, input.text, {
        mode: '777'
      }, function(err) {
        if (err) {
          debug(err);
        } else {
          debug("File " + tmp_file + " saved to tmp!");
    	    input.cmdline="cp " + tmp_file + " " + input.file;
    	    input.cmd = "file_saved_editor";
    	    input.folder = tmp + "/";
    	    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
        }
      });
    }
  });

  router.post('/api/diff', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + " --diff -dir='" + input.folder + "' -v=0 -f=html " + input.file_new + " " + input.file_old;
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/run_r_script', function(req, res) { //if (cmd.match(/run_r_script/g)) {
    var input = req.body;
    input.cmdline = apirana + ' -dir=' + input.folder + ' -run_script=' + input.base_dir + '/' + input.file;
    for(var i = 0; i < input.mods.length; i++) {
      input.cmdline += " " + input.mods[i];
    }
    r.run_r_script(socket, input, session, tmp, res);
  });

  router.post('/api/server_file_viewer', function(req, res) {
    var input = req.body;
    if(input.file) {
      path = input.file.split(/\//g);
      file_bare = path[path.length - 1];
      fs.exists(input.folder + '/' + input.file, function(exists) {
        if (exists) {
          debug("File check 1");
          fs.createReadStream(input.folder + '/' + input.file).pipe(fs.createWriteStream(__dirname + '/public/tmp/' + file_bare));
          fs.exists(tmp + '/' + file_bare, function(exists2) {
            if (exists2) {
              debug("File check 2");
              res.status(200).send({
                'error': false,
                'cmd': 'server_file_viewer',
                'format': input.format,
                'file_url': 'tmp/' + file_bare
              });
            } else {
              debug("File does not exist (" + tmp + "/" + file_bare + ")");
              res.status(200).send({
                'error': true,
                'output': "An error occurred while reading the file (2)",
                size: 'small',
                noadd: true
              });
            }
          });
        } else {
          res.status(200).send({
            'error': true,
            'output': "An error occurred while reading the file (1).",
            size: 'small',
            noadd: true
          });
        }
      });
    } else {
      console.log("No file specified to open");
    }
  });

  router.post('/api/open_run_report', function(req, res) {
    var input = req.body;
    input.folder = tmp + '/';
    var return_msg = 'open_run_report';
    var fmt = "html";
    if(input.format == "docx") {
        return_msg = 'download_file';
        fmt = "docx";
    }
    var file_dest = 'public/tmp/tmp_' + input.user_id + '_' + misc.random_string(5) + '_' + input.file + '.' + fmt;
    // fs = require('fs');
    debug("Trying to open report on the client...");
    diskio.move_file_on_server(input.outfile, __dirname, file_dest, socket, session, return_msg, false, res);
  });

  router.post('/api/rm', function(req, res) {
    var input = req.body;
    var cmdline = "rm -rf ";
    for (i = 0; i < input.files.length; i++) {
      var run = input.files[i];
      if (run.match("^\/")) {
        var dir = run.replace(/^\//, "");
        if (dir !== "" && dir !== "." && dir !== "..") {
          cmdline += input.folder + "/" + dir + " ";
        }
      } else {
        cmdline += input.folder + "/" + run + ".mod ";
        if (input.del_all) {
          if (run.length > 1 && run !== "*") {
            cmdline += input.folder + "/" + run + ".*";
          }
        }
        if (input.del_tab) {
          // need to add
        }
      }
    }
    debug("Executing command: " + cmdline);
    input.cmdline = cmdline;
    if (i < input.files.length - 1) {
      input.cmd = "dummy"; // don't give signal to refresh pirana yet
    }
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/set_color', function(req, res) {
    var input = req.body;
    if (input.runs !== undefined) {
      var runs = input.runs.join(" ");
      input.cmdline = apirana + ' --color=' + input.color + ' --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
      input.folder = tmp + '/';
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/set_flag', function(req, res) {
    var input = req.body;
    if (input.runs !== undefined) {
      var runs = input.runs.join(" ");
      input.cmdline = apirana + ' --flag=' + input.flag + ' --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
      input.folder = tmp + '/';
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/remove_flags', function(req, res) {
    var input = req.body;
    if (input.runs !== undefined) {
      var runs = input.runs.join(" ");
      input.cmdline = apirana + ' --flag=remove' + ' --dir=' + input.folder + ' ' + runs + ' --user=' + session.user_id;
      input.folder = tmp + '/';
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/psn_log', function(req, res) {
    var input = req.body;
    if(session) {
      input.cmdline = apirana + ' --psn_history --v=0 --f=json -user=' + session.user_id + " -home="+session.home_folder;
      if(input.filter) {
        input.cmdline += " --filter="+input.filter;
      }
      input.folder = tmp + "/";
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    } else {
      console.log("session ended!");
    }
  });

  router.post('/api/file_delete', function(req, res) {
    var input = req.body;
    for(var i = 0; i<input.files.length; i++) {
      input.files[i] = input.folder + '/' + input.files[i];
    }
    var files = input.files.join(' ');
    input.cmdline = 'rm ' + files;
    input.run_in_folder = input.folder;
    console.log(input);
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/file_download', function(req, res) {
    var input = req.body;
    if(input.files.length == 1) {
      diskio.move_file_on_server(input.folder + '/' + input.filename, tmp, input.filename, socket, session, 'file_download', false, res);
    } else {
      input.filename = "download_" + input.files[0] + "_etc.zip";
      for (var i = 0; i < input.files.length; i++) {
          input.files[i] = input.folder + "/" + input.files[i];
      }
      input.cmdline = "zip -r " + tmp + "/" + input.filename + " " + input.files.join(" ") + " > " + tmp + "/zip.out";
      input.run_in_folder = input.folder;
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    }
  });

  router.post('/api/psn_help', function(req, res) {
    var input = req.body;
    input.folder = tmp + '/';
    child = child_process.exec(input.command + ' --' + input.type, function(error, stdout, stderr) {
      res.status(200).send({
        'cmd': input.cmd,
        'output': stdout,
        'mode': 'text'
      });
    });
    child.on('error', function(err) {
      res.status(200).send({
        'error': 'true',
        'cmd': 'cmd',
        'output': "An error occurred while getting PsN help.\n"
      });
    });
  });

  router.post('/api/create_vrr', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + ' -user='+session.user_id+' -vrr -v=0 -dir=' + input.folder;
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/build_tex_pdf', function(req, res) {
    var input = req.body;
    input.cmdline = 'pdflatex -output-directory=' + input.folder + '/pirana_reports ' + folder + '/' + input.tex_file + ' >/dev/null';
    input.folder = tmp + '/';
    debug("\n\n" + input.cmdline + "\n\n");
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/set_project_active', function(req, res) {
    var input = req.body;
    input.home = input.home.replace(/ /, "{s}");
    if (input.project && input.project !== "") {
      // input.cmdline = apirana + ' -project_active -v=0 -home=' + input.home;
      input.project = input.project.replace(/\s/, "{s}");
      input.cmdline = apirana + ' -project_active=' + input.project + ' -v=0 -home=' + session.home_folder;
      if (session) {
        input.cmdline += ' --user=' + session.user_id;
        cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
      }
    }
  });

  router.post('/api/get_last_nm_error', function(req, res) {
    var input = req.body;
    var files = fs.readdirSync(input.folder);
    files.sort(function(a, b) {
      return fs.statSync(input.folder+'/'+a).mtime.getTime() -
      fs.statSync(input.folder+'/'+b).mtime.getTime();
    });
    filt1 = function filt1 (el) { return el.match("modelfit_dir") };
    var files1 = files.filter(filt1);
    filt2 = function filt1 (el) { return el.match(".mod.dir") };
    var files2 = files.filter(filt2);
    var folders = files1.concat(files2);
    var latest = diskio.get_latest_file(input.folder, folders);
    var errfile = path.join(input.folder, latest, "NM_run1", "nmtran_error.txt");
    console.log(errfile);
    fs.readFile(errfile, 'utf8', function (err, nmtran) {
      if (err) {
        return console.log(err);
      }
      if (nmtran === undefined || nmtran === "") {
        res.status(200).send({
          'text': "PiranaJS tried, but couldn't get additional info on the NONMEM error, sorry."
        });
      } else {
        res.status(200).send({
          'text': path.join(latest, "NM_run1", "nmtran_error.txt") + ":<br>" + nmtran
        });
      }
    });
  });

  router.post('/api/run_report', function(req, res) {
    var input = req.body;
    if (input.file !== '' && input.file !== undefined) {
      var file_rel = 'pirana_reports/pirana_sum_' + input.file + '.html';
      var file_full = input.folder + '/' + file_rel;
      // var fs = require('fs');
      // fs.mkdir(folder + '/pirana_reports', function(e){
      //   if (e) { console.log(e); }
      // });
      if (input.format == undefined) {
        input.format = 'txt';
      };
      var outfile = input.folder + "/pirana_reports/pirana_sum_" + input.file + ".html";
      var cmdline = apirana + ' -run_report -dir=' + input.folder + ' -v=0 -f=html -output=' + outfile + ' ' + input.file + '.lst';
      var format = input.format;
      if (format == "pdflatex") {
        format = "tex"
      };
      if (format == 'txt' || format == 'r_obj' || format == 'tex' || format == 'pdflatex') {
        cmdline = apirana + ' -run_report -dir=' + input.folder + ' -v=0 -f=' + format + ' ' + input.file + '.lst';
      }
      if (input.format == "pdflatex") {
        outfile = "pirana_reports/pirana_sum_" + input.file + ".pdf";
        // APIRANA: make new folder if not exists!
        cmdline += " -output=" + input.folder + "/pirana_reports/pirana_sum_" + input.file + ".tex -pdflatex";
      }
      if (input.format == "docx") {
        outfile = "pirana_reports/pirana_sum_" + input.file + ".docx";
        cmdline += " -f=docx -output=" + input.folder + "/pirana_reports/pirana_sum_" + input.file + ".docx";
      }
      input.cmdline = cmdline;
      input.outfile = outfile;
      //                input.file = file;
      input.folder = tmp + '/';
      cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
    } else {
      socket.emit('cmd', {
        'cmd': 'cmd',
        'error': true,
        'output': "An unknown error occurred while loading this folder.\n"
      });
    }
  });

  router.post('/api/process_info', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + ' -ps -f=json -v=0';
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/qstat_info', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + ' -qstat -f=json -v=0';
    // input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/intermed_info', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + ' -inter -f=json -v=0 -dir=' + input.folder;
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/files', function(req, res) {
    var input = req.body;
    diskio.get_files(socket, input.folder, input.cmd, "files", input, res);
    input.folder = tmp + '/';
  });

  router.post('/api/refresh_reports', function(req, res) {
    var input = req.body;
    input.cmdline = apirana + ' -list_reports -f=json -dir=' + input.folder + ' -v=0';
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/refresh_vc', function(req, res){
    var input = req.body;
    input.cmdline = apirana + ' -vc_log=12 -f=json -v=0 -dir='+input.folder;
    input.run_in_folder = input.folder;
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/refresh_scripts', function(req, res) {
    var input = req.body;
    //	    input.cmdline = apirana + ' -list_scripts -f=json -v=0 -dir='+ini.folders.pirana_scripts;
    input.cmdline = apirana + ' -list_scripts -f=json -v=0 -dir=' + input.folder + '/pirana_scripts ';
    if(ini.custom.user_r_scripts) {
       input.cmdline += ' -custom_dir=' + ini.custom.user_r_scripts;
    }
    // console.log(input.cmdline);
    input.folder = tmp + '/';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/reset_pirana_db', function(req, res) {
    var input = req.body;
    input.folder = tmp + '/';
    input.cmdline = 'unlink ' + input.folder + '/pirana.dir';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/remove_modelfit_folders', function(req, res) {
    var input = req.body;
    input.cmdline = 'rm -rf ' + input.folder + '/modelfit_dir*';
    cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  });

  router.post('/api/handle_file_upload', function(req, res) {
    var input = req.body;
    diskio.handle_file_upload(socket, tmp, input, session, res);
  });

  // not used?
  // router.post('/api/r_object_from_est', function(req, res) {
  //   var input = req.body;
  //   input.cmdline = apirana + ' -rr ' + input.file + '.mod -f=r_obj -v=0';
  //   input.folder = tmp + '/';
  //   cmd.cmd_exec(socket, input, session, sockets, tmp, sudo_login_flag, res);
  // });

  ////////////////////////////////////////////////////////////////////////////
  // TTY
  ////////////////////////////////////////////////////////////////////////////
  if (ini.general.allow_tty) {
    term.on('data', function(data) {
      if (stream) stream.write('OUT: ' + data + '\n-\n');
      return !socket ? buff.push(data) : socket.emit('data', data);
    });
    socket.on('data', function(data) {
      if (stream) stream.write('IN: ' + data + '\n-\n');
      term.write(data);
    });
    socket.on('disconnect', function() {
      socket = null;
    });
    while (buff.length) {
      socket.emit('data', buff.shift());
    }
  };

  socket.emit('links', ini.links);
  if (ini.general.allow_tty) {
    socket.emit('allow_tty');
  } // current implementation is insecure! Do not use for production on shared servers.

  ip = socket.handshake.address;
  io.of('/user').on('connection', function(socket) {
    ss(socket).on('profile-image', function(stream, data) {
      var filename = path.basename(data.name);
      stream.pipe(fs.createWriteStream(filename));
    });
  });

  ////////////////////////////////////////////////////////////////////////////
  // Streaming command line (e.g. for NONMEM runs)
  ////////////////////////////////////////////////////////////////////////////

  socket.on('cmd', function(input) {
    var spl = input.cmdline.split(' ');
    var executable = spl.shift();
    input.cmdline = executable + ' ' + spl.join(' ');
    // console.log("Executing command: " + input.cmdline);
    cmd.cmd_stream(socket, input, executable, session, ini, tmp);
  });

});
