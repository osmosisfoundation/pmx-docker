var forever = require('forever-monitor');

var child = new (forever.Monitor)('app.js', {
    'silent': false,
    'pidFile': 'tmp/main.pid',
    'killTree': true,
    'logFile': 'log/server.log', // Path to log output from forever process (when daemonized)
    'outFile': 'log/server_stdout.log', // Path to log output from child stdout
    'errFile': 'log/server_stderr.log'  // Path to log output from child stderr
});

child.on('exit', function () {
});

child.start();
