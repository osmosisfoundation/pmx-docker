ace.define("ace/mode/nonmem", ["require", "exports", "module", "ace/lib/oop", "ace/mode/text", "ace/mode/nonmem_highlight_rules", "ace/range"], function (e, t, n) {
    var r = e("../lib/oop"),
        i = e("./text").Mode,
        s = e("./nonmem_highlight_rules").NonmemHighlightRules,
        o = e("../range").Range,
        u = function () {
            this.HighlightRules = s
        };
    r.inherits(u, i),
    function () {
        this.lineCommentStart = "*", this.$id = "ace/mode/nonmem"
    }.call(u.prototype), t.Mode = u
}), ace.define("ace/mode/nonmem_highlight_rules", ["require", "exports", "module", "ace/lib/oop", "ace/mode/text_highlight_rules"], function (e, t, n) {
    var r = e("../lib/oop"),
        i = e("./text_highlight_rules").TextHighlightRules,
        s = function () {          
            var e = "$ABBREVIATED|$ABBREVIATE|$ABBREVIAT|$ABBREVIA|$ABBREVI|$ABBREV|$ABBRE|$ABBR|$ABB|$AES|$AESINITIAL|$AESINITIA|$AESINITI|$AESINIT|$AESINI|$AESIN|$AESI|$AES0|$BIND|$BIN|$CONFIDENCE|$CONFIDENC|$CONFIDEN|$CONFIDE|$CONFID|$CONFI|$CONF|$CONTR|$CONT|$COVARIANCE|$COVARIANC|$COVARIAN|$COVARIA|$COVARI|$COVAR|$COVA|$COV|$COVR|$DATA|$DAT|$DES|$ERROR|$ERRO|$ERR|$ESTIMATION|$ESTIMATIO|$ESTIMATI|$ESTIMAT|$ESTIMA|$ESTIM|$ESTI|$EST|$ESTM|$ESTIMATE|$INCLUDE|$INCLUD|$INCLU|$INCL|$INC|INCLUDE|$include|include|$INDEX|$INDE|$IND|$INDEXES|$INDEXE|$INDXS|$INDX|$INFN|$INFILE|$INFIL|$INFI|$INPUT|$INPU|$INP|$MIX|$MODEL|$MODE|$MOD|$MSFI|$MSF|$NONPARAMETRIC|$NONPARAMETRI|$NONPARAMETR|$NONPARAMET|$NONPARAME|$NONPARAM|$NONPARA|$NONPAR|$NONPA|$NONP|$NON|$OMEGA|$OMEG|$OME|$OMIT|$OMI|$PK|$PRED|$PRE|$PRIOR|$PRIO|$PRI|$PROBLEM|$PROBLE|$PROBL|$PROB|$PRO|$SCATTERPLOTS|$SCATTERPLOT|$SCATTERPLO|$SCATTERPL|$SCATTERP|$SCATTER|$SCATTE|$SCATT|$SCAT|$SCA|$SCATTERS|$SCATTERGRAMS|$SCATTERGRAM|$SCATTERGRA|$SCATTERGR|$SCATTERG|$SIGMA|$SIGM|$SIG|$SIMULATION|$SIMULATIO|$SIMULATI|$SIMULAT|$SIMULA|$SIMUL|$SIMU|$SIM|$SIMULATE|$SIML|$SUBROUTINES|$SUBROUTINE|$SUBROUTIN|$SUBROUTI|$SUBROUT|$SUBROU|$SUBRO|$SUBR|$SUB|$SUBS|$SUPER|$SUPE|$SUP|$TABLE|$TABL|$TAB|$THETA|$THET|$THE|$TOL|$WARNINGS|$WARNING|$WARNIN|$WARNI|$WARN|$WAR",
                t = "/(IPRED|PRED|WRES|IWRES|CWRES|RES|ID|TIME|DV|MDV|EVID|PRED|AMT|ADVAN.|ADVAN..|TRANS.)/",
                n = "THETA|ETA|EPS|ERR",
                r = this.createKeywordMapper({
                    "support.function": n,
                    keyword: e,
                    "constant.language": t
                }, "identifier", !0);
            this.$rules = {
                start: [{
                    token: "comment",
                    regex: ";.*"
                }, {
                    token: "string",
                    regex: '".*?"'
                }, {
                    token: "string",
                    regex: "'.*?'"
                }, {
                    token: "constant.numeric",
                    regex: "[+-]?\\d+(?:(?:\\.\\d*)?(?:[eE][+-]?\\d+)?)?\\b"
                }, {
                    token: r,
                    regex: "[a-zA-Z_$][a-zA-Z0-9_$]*\\b"
                }, {
                    token: "keyword.operator",
                    regex: "\\+|\\-|\\/|\\/\\/|%|<@>|@>|<@|&|\\^|~|<|>|<=|=>|==|!=|<>|="
                }, {
                    token: "text",
                    regex: "\\s+"
                }]
            }
        };
    r.inherits(s, i), t.NonmemHighlightRules = s
})
