var radius = 10;

var tree = d3.layout.tree()
    .size([radius + 200, radius + 200])
    .separation(function(a, b) { return (a.parent == b.parent ? 1 : 2) / a.depth; });

var diagonal = d3.svg.diagonal.radial()
    .projection(function(d) { return [d.y, d.x / 180 * Math.PI]; });


var vis = d3.select("#body").append("svg")
    .attr("width", 1000)
    .attr("height", 700)
  .append("g")
    .attr("transform", "translate(" + (radius + 100) + "," + (radius + 200 ) + ")");

d3.json("runrec.json", function(json) {
  var nodes = tree.nodes(json);

    nodes.forEach(function(d) {
    	d.y = d.y * 3;
    });

  var link = vis.selectAll("path.link")
      .data(tree.links(nodes))
    .enter().append("path")
      .attr("class", "link")
      .attr("d", diagonal)
     	.style("stroke-width", function(d) { return d.target.final_path == 1? "4px" : "2px"; })
     	.style("stroke", function(d) { return d.target.final_path == 1 ? "#66a" : "#cc0"; })
    ;
  var node = vis.selectAll("g.node")
      .data(nodes)
    .enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) { return "rotate(" + (d.x - 90) + ")translate(" + d.y + ")"; })

  node.append("circle")
	//.style("fill", "#fff")
	// .style("stroke", "steelblue")
	// .style("stroke-width", 2)
	.style("stroke", function(d) { return node_stroke (d); })
	.style("stroke-width", function(d) { return node_stroke_width (d); })
	.style("fill", function(d) { return node_color (d); })
	.attr("r", 4.5);

  node.append("text")
      .attr("dx", function(d) { return d.x < 180 ? 8 : -8; })
      .attr("dy", ".31em")
      .attr("text-anchor", function(d) { return d.x < 180 ? "start" : "end"; })
      .attr("transform", function(d) { return d.x < 180 ? null : "rotate(180)"; })
      .text(function(d) { return d.name; });

    d3.selectAll("path.link")
	.style("opacity", "1")
//     	.style("stroke-width", function(d) { return d.target.final_path == 1? "4px" : "2px"; })
     	.style("stroke-width", function(d) { return d.depth + "px"; })
     	.style("stroke", function(d) { return d.target.final_path == 1 ? "#66a" : "#ccc"; })
	.style("fill", "none");

});


function node_stroke(d) {
    color = "#fff";
    if (d.n_children > 0) {
	color = "#888";
    }
    return color;
}
function node_color(d) {
    color = "#bbb";
    if (d.dofv < -3.84) {
	color = "#3a3";
    }
    if (d.dofv > 0) {
	color = "#a33";
    }
    return color;
}
function node_stroke_width (d) {
    width = 0;
    if (d.n_children > 0) {
	width = 3;
    }
    return width;
}