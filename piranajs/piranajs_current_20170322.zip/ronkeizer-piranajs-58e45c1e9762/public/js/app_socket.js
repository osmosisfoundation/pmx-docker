// var user_id = 'ronkeizer'; // + Math.floor((Math.random()*1000)+1);

function try_parse_json (jsonString){
  try {
    var o = JSON.parse(jsonString);
    if (o && typeof o === "object" && o !== null) {
      return o;
    }
  }
  catch (e) { }
  return false;
};

function sock (input) {
  if (input.cmd == 'cmd') {
    console_out = '';
    input.console_number = console_number;
  }
  if (input.user_id == '' || input.user_id == undefined) {
    input.user_id = window.user_id;
  }
  if (input.user_id !== '') {
    socket.emit(input.cmd, input);
  } else {
    //	alert ("You are not logged in!");
  }
}

function refresh_process_info () {
  $.post('/api/process_info', {
    cmd: "process_info",
    folder: $("#cwd_input").val()
  }, function(msg) {
    var ps_info = [{
      "command": "None active"
    }];
    var ps_get = try_parse_json(msg.output);
    if (ps_get) {
      ps_info = ps_get;
    }
    var dummy = false;
    if (dummy) {
      populate_list_with_data("#ps_monitor",
      [ { cpu: "1",
      mem: "1",
      time: "1",
      pid: "12345",
      user: "1",
      command: "1",
      args: "1",
    }]);
    } else {
      populate_list_with_data("#ps_monitor", ps_info);
    }
  });
  $.post('/api/qstat_info', {
    cmd: "qstat_info",
    folder: $("#cwd_input").val()
  }, function(msg) {
    jobs_a_info = [{ "name": "[No jobs]" }];
    jobs_s_info = [{ "name": "[No jobs]" }];
    nodes_use = [{ "name": "[No nodes]" }];
    nodes_jobs = [{ "name": "" }];
    var qstat_all = try_parse_json(msg.output);
    if (qstat_all) {
      // console.log(msg.output);
      if (qstat_all.running_jobs.length > 0) {
        jobs_a_info = qstat_all.running_jobs;
      }
      if (qstat_all.scheduled_jobs.length > 0) {
        jobs_s_info = qstat_all.scheduled_jobs;
      }
      if (qstat_all.node_use.length > 0) {
        nodes_use = qstat_all.node_info;
      }
    }
    populate_list_with_data("#jobs_a_monitor", jobs_a_info);
    populate_list_with_data("#jobs_s_monitor", jobs_s_info);
    populate_list_with_data("#nodes_monitor", nodes_use);
    if(qstat_all && monitor_active_node !== undefined && nodes_use) {
      var tmp = nodes_use[monitor_active_node]
      if(tmp) {
        nodes_jobs = tmp.jobs
      }
    } else {
      jobs_on_node = "";
    }
    populate_list_with_data("#nodes_jobs_monitor", nodes_jobs);
  });
}

function refresh_intermed_info () {
  $.post('/api/intermed_info', {
    cmd: "intermed_info",
    folder: $("#cwd_input").val()
  }, function(msg) {
      var inter = try_parse_json(msg.output);
      if (inter) {
        inter_db = inter;
        populate_intermed_info(inter);
      }
  })
}

function reset_pirana_db () {
  $.post('/api/reset_pirana_db', {
    cmd: "reset_pirana_db",
    folder: $("#cwd_input").val()
  }, function() {
    refresh_pirana();
  });
}

function remove_modelfit_folders () {
  $.post('/api/remove_modelfit_folders', {
    cmd: "remove_modelfit_folders",
    folder: $("#cwd_input").val()
  }, function(msg) {
    refresh_pirana();
  });
}

function refresh_process_info_monitor () {
  if(cluster_monitor_active == 1) {
    refresh_process_info();
  }
}
function refresh_qstat_info() {
  $.post('/api/qstat_info', {
    cmd: "qstat_info",
    folder: $("#cwd_input").val()
  }, function(msg) {
    jobs_a_info = [{ "name": "[No jobs]" }];
    jobs_s_info = [{ "name": "[No jobs]" }];
    nodes_use = [{ "name": "[No nodes]" }];
    nodes_jobs = [{ "name": "" }];
    var qstat_all = try_parse_json(msg.output);
    if (qstat_all) {
      // console.log(msg.output);
      if (qstat_all.running_jobs.length > 0) {
        jobs_a_info = qstat_all.running_jobs;
      }
      if (qstat_all.scheduled_jobs.length > 0) {
        jobs_s_info = qstat_all.scheduled_jobs;
      }
      if (qstat_all.node_use.length > 0) {
        nodes_use = qstat_all.node_info;
      }
    }
    populate_list_with_data("#jobs_a_monitor", jobs_a_info);
    populate_list_with_data("#jobs_s_monitor", jobs_s_info);
    populate_list_with_data("#nodes_monitor", nodes_use);
    if(qstat_all && monitor_active_node !== undefined && nodes_use) {
      var tmp = nodes_use[monitor_active_node]
      if(tmp) {
        nodes_jobs = tmp.jobs
      }
    } else {
      jobs_on_node = "";
    }
    populate_list_with_data("#nodes_jobs_monitor", nodes_jobs);
  })
}

function refresh_pirana (folder) {
  main_scroll_pos = $("#main").closest(".ui-jqgrid-bdiv").scrollTop();
  mod_sel = $("#main").getGridParam('selarrrow');
  $("#folder_nmtran_error").dialog("close");
  $("#folder_psn_cmd").dialog("close");
  if (!folder || folder === '') {
    folder = $('#cwd_input').val();
  }
  if (folder !== '') {
    folder = folder.replace(/\/\//g, "/");
    $("#cwd_input").val(folder);
    $("#message_dialog_no_title").dialog("open");
    $("#message_dialog_no_title").focus();
    status("Loading data from folder...")
    $.post('/api/refresh', {
      user_id: window.user_id,
      cmd: "refresh",
      folder: folder,
      folder_filter: $('#folder_filter').val()
    }, function(msg) {
      right_selector(window.sel, 1); // also calls refresh_files()
      var up_dir_data = [ {
        "descr" : " [ up one level ] ",
        "run" : "..",
      } ];
      if (msg.output.match("Folder not readable")) {
        $("#message_dialog_no_title").dialog("close");
        $("#main").jqGrid('clearGridData');
        $("#message_dialog").html("<p>This folder is not readable. Please check file and folder permissions.</p>").dialog("open");
        $("#main").trigger("reloadGrid");
        $("#cwd_input").select();
      } else {
        var parse_info = try_parse_json (msg.output);
        if (parse_info) {
          if (parse_info.dir_not_exists == 1) {
            console.log("Folder does not exist");
            main_model_data = {};
            $("#cwd_input").css({'background-color' : '#ff3333'});
          } else {
            $("#cwd_input").css({'background-color' : '#FFFFFF'});
            var new_data = parse_info.rows;
            new_data = _.reject(new_data, function(q) { return q.run.match(/^dir-/i) }); // filter out folders
            var filtered = filter_hidden_models(new_data);
            main_model_data = up_dir_data.concat(filtered.data); // global variable
            if (filtered.hidden > 0) {
              $("#n_hidden").html("<b>(" + filtered.hidden + " hidden)</b>");
            } else {
              $("#n_hidden").html("("+filtered.hidden + " hidden)");
            }
          }
          // $('#node_output').text(msg.output);
          $("#main").jqGrid('clearGridData');
          $("#main").jqGrid('setGridParam', { data: main_model_data });
          $("#main").trigger("reloadGrid");
          for (var i in mod_sel) {
            $("#main").jqGrid('setSelection', mod_sel[i]);
          }
          $("#main").closest(".ui-jqgrid-bdiv").scrollTop(main_scroll_pos);
          $("#message_dialog_no_title").dialog("close");
        } else {
          status("No data received from server during folder load.");
          //		alert("No data received from server during folder load:\n"+msg.output+"\nPlease log in if you haven't done so.\nAlso check installation of APIrana and PiranaJS.");
        }
      }
      // refresh_files(); // already called from "right_selector()"
    });
    // document.getElementById('cwd_input').value = folder;
  } else {
    $("#message_dialog").html("<p>Sorry, couldn't find folder to read.</p>").dialog("open");
  }
  // set upload target
  var folder_tmp = $('#cwd_input').val().replace(/\//g, '!');
  // if (r) { // Flow.js
  //   r.opts.target = '/upload/'+window.user_id+'/'+folder_tmp;
  // }
  if(license_valid === 0) {
    $("#message_dialog").html("<p>No valid PiranaJS license present!</p>").dialog("open");
  }
}

function refresh_files() {
  var loading_dummy = [ {
    "name" : "[ Loading ]",
  } ];
  $("#list_files").jqGrid('clearGridData');
  $("#list_files").jqGrid('setGridParam', { data: loading_dummy });
  status("Loading files...");
  $.post('/api/files', {
    cmd: "files",
    folder: document.getElementById('cwd_input').value
  }, function(msg) {
      file_list_data = msg.output;
      $("#list_files").jqGrid('clearGridData');
      $("#list_files").jqGrid('setGridParam', { data: msg.output } );
      $("#list_files").trigger("reloadGrid");
      status("");
  });
}

function refresh_scripts() {
  var loading_dummy = [ {
    "name" : "[ Loading ]",
  } ];
  $("#list_r").jqGrid('clearGridData');
  $("#list_r").jqGrid('setGridParam', { data: loading_dummy });
  //$("#list_r").trigger("reloadGrid");
  status("Loading scripts...");
  $.post('/api/refresh_scripts', {
    folder: $("#cwd_input").val(),
    cmd: "refresh_scripts"
  }, function(msg) {
    script_list_data = try_parse_json (msg.output);
    if (script_list_data) {
      populate_scripts_list(script_list_data);
    } else {
      console.log("Scripts not found!");
    }
  });
}

function refresh_reports() {
  var loading_dummy = [ {
    "name" : "[ Loading ]",
  } ];
  $("#list_reports").jqGrid('clearGridData');
  $("#list_reports").jqGrid('setGridParam', { data: loading_dummy });
  //$("#list_r").trigger("reloadGrid");
  status("Loading reports...");
  $.post('/api/refresh_reports', {
    cmd: "refresh_reports",
    folder: $('#cwd_input').val()
  }, function(msg) {
    report_list_data = try_parse_json(msg.output);
    if (report_list_data) {
      populate_reports_list(report_list_data);
    } else {
      console.log("Reports not found!");
    }
  });
}

function refresh_vc() {
  var loading_dummy = [ {
    "name" : "[ Loading ]",
  } ];
  $("#list_git").jqGrid('clearGridData');
  $("#list_git").jqGrid('setGridParam', { data: loading_dummy });
  //$("#list_r").trigger("reloadGrid");
  status("Loading version control commit history...");
  $.post('/api/refresh_vc', {
    cmd: "refresh_vc",
    folder: $('#cwd_input').val()
  }, function(msg) {
    git_list_data = try_parse_json(msg.output);
    if (git_list_data) {
      var today = new Date();
      for (i in git_list_data) {
        var tmp = new Date(git_list_data[i].date);
        var ago = (today-tmp)/(3600*1000);
        var unit = "hr";
        if (ago > 24) {
          ago = ago/24;
          unit = "day";
          if (ago > 7) {
            ago = ago/7;
            unit = "week";
            if (ago > 4.3) {
              ago = ago/4.3
              unit = "month";
              if (ago > 12) {
                ago = ago/12
                unit = "year";
              }
            }
          }
        }
        if (Math.round(ago) > 1) { unit += "s"}
        git_list_data[i].date = Math.round(ago) + " " + unit;
        git_list_data[i].message.replace(/\-/, " ");
      }
      populate_list_with_data("#list_git", git_list_data);
    } else {
      // console.log("Git commit info not found!");
      // console.log(msg.output);
    }
  });
}

function populate_scripts_list (script_data) {
  var grid_r = $("#list_r");
  grid_r.jqGrid('clearGridData');
  if (script_data !== undefined) {
    if (grid_r[0] !== undefined) {
      grid_r[0].addJSONData(script_data);
    } else {
      console.log("Scripts grid undefined");
    }
  } else {
    console.log("Output APIrana undefined");
  }
}
function populate_reports_list (reports_data) {
  var grid_reports = $("#list_reports");
  grid_reports.jqGrid('clearGridData');
  if (reports_data !== undefined) {
    if (grid_reports[0] !== undefined) {
      grid_reports[0].addJSONData(reports_data);
    } else {
      console.log("Reports grid undefined");
    }
  } else {
    console.log("Output APIrana undefined");
  }
}
function populate_intermed_info (inter) {
  var grid_inter = $("#intermediate_res_table");
  inter_sel = grid_inter.getGridParam('selarrrow');
  // console.log(inter_sel);
  grid_inter.jqGrid('clearGridData');
  if (inter !== undefined) {
    if (grid_inter[0] !== undefined) {
      grid_inter[0].addJSONData(inter);
      grid_inter.jqGrid('setSelection', inter_sel[0]);
    } else {
      console.log("Intermediate results grid undefined");
    }
  } else {
    console.log("Output APIrana undefined");
  }
}

function project_selected () {
  var s = document.getElementById('project_selector');
  var tmp = s.options[s.selectedIndex].value;
  var project = tmp.replace(/\#.*/, "");
  var folder  = tmp.replace(/.*?\#/, "");
  active_folder = project_folders[project];
  refresh_pirana(folder);
  setTimeout(function() { // just give preference to loading folder, this can be done later
    $.post('/api/set_project_active', {
      cmd: "set_project_active",
      home: home_folder,
      project: project
    }, function(msg) {
      // do nothing
    })
  }, 500);
}

function refresh_projects () {
  $.post('/api/refresh_projects', {
    cmd: "refresh_projects",
    home: home_folder
  }, function(msg) {
    var option_string = "";
    var reports_list_data = try_parse_json(msg.output);
    if (reports_list_data) {
      var proj_json = try_parse_json(msg.output);
      if (proj_json && proj_json.length > 0) {
        var active = proj_json[0].project;
        var active_folder = proj_json[0].folder;
        var options = [];
        for(var i = 0; i < proj_json.length; i++) {
          project_folders[proj_json[i].project] = proj_json[i].folder;
        }
      }
      active_folder = project_folders[active_project];
      if((_.indexOf(_.keys(project_folders), active_project) < 0) || (active_project == "")) {
        active_project = "";
        active_folder = home_folder;
      }
      // populate_projects();
      $.post('/api/get_project_active', {
        cmd: "get_project_active", // will also call populate_projects
        home: home_folder
      }, function(msg) {
        inc_login_progress("login_prg_project");
        if(msg.output && msg.output !== "") {
          active_project = msg.output;
        }
        populate_projects(active_project);
      });
      $('#cwd_input').val(active_folder);
    }
    status("");
  });
}

// var socket = io.connect();
var socket = io({ forceNew: true });
socket.on('connect', function () {
  socket.emit(window.location.href);
});

window.onhashchange = function () {
  socket.emit(window.location.href);
}

function chomp(raw_text) {
  if (raw_text !== undefined) {
    return raw_text.replace(/(\n|\r)+$/, '');
  }
}
function zero_add (num, places) {
  if (num !== undefined) {
    var zero = places - num.toString().length + 1;
    return Array(+(zero > 0 && zero)).join("0") + num;
  } else {
    return(num);
  }
}

function remove_console_tab (key) {
  if (key == "all") {
    var keys = Object.keys(console_windows);
    for (var i = 0; i < keys.length; i++) {
      $("#console_tabs_"+keys[i]).remove();
      $("#console_tabs_del_"+keys[i]).remove();
      delete console_windows[keys[i]];
      delete console_all[keys[i]];
    }
  } else {
    $("#console_tabs_"+key).remove();
    $("#console_tabs_del_"+key).remove();
    delete console_windows[key];
    delete console_all[key];
  }
  if (Object.keys(console_windows).length == 0) {
    console_active = undefined;
  } else {
    console_active = Object.keys(console_windows)[0];
  }
  refresh_console_tabs();
  refresh_console_content("", console_active);
}

function add_console_tab (key, console_number) {
  key = key.replace(/[\s\-\=]/g, "_");
  var console_id = zero_add(console_number,2) + "-" + key;
  var tabs = Object.keys(console_windows);
  console_windows[console_id] = " ";
  console_all[console_id] = "";
  console_active = console_id;
  refresh_console_content("", console_id);
  refresh_console_tabs();
}

function refresh_console_tabs () {
  //    $("#console_windows_td_left1").html("Consoles:<br>");
  var tabs = Object.keys(console_windows);
  for (var i = 0; i < tabs.length; i++) {
    $("#console_windows_td_left2").append("<div id='console_windows_div_"+tabs[i]+"'></div>");
    $("#console_windows_div_"+tabs[i]).html("<button id='console_tabs_"+tabs[i]+"' value='"+tabs[i]+
    "' onClick='show_active_console(\""+tabs[i]+"\"); return false;'>"+tabs[i]+"</button>")
    .append("<button id='console_tabs_del_"+tabs[i]+"'onClick='remove_console_tab(\""+tabs[i]+"\")'></button>");
    $("#console_tabs_"+tabs[i]).button().css("height", 20).css("width", 92)
    .next().button({ icons: {primary: "ui-icon-close"} }).css("height", 20);
    $("#console_windows_div_"+tabs[i]).buttonset();
    // set active tab
    if (tabs[i] == console_active) {
      $("#console_tabs_" + tabs[i]).css("background", "#ff7516");
      $("#console_tabs_" + tabs[i]).css("color", "#ffffff");
      $("#console_tabs_" + tabs[i]).addClass('active');
    } else {
      $("#console_tabs_" + tabs[i]).css("background", "#efefef");
      $("#console_tabs_" + tabs[i]).addClass('inactive');
    }
  }
}

function inc_login_progress(text, no_progress) {
  if (!no_progress) {
    login_progress = login_progress + 20;
    $("#progressbar" ).progressbar({ value: login_progress });
  }
  // $("#progress_text").html("<p>"+text+"</p>");
  $("#"+text).addClass("login_prg_done");
  if (login_progress > 80) {
    setTimeout(function() {
      $("#login_progress_dialog").dialog( "close" );
    }, 500);
    $("#statusbar").removeClass('hide');
    if(project_folders[active_project]) {
      refresh_pirana(project_folders[active_project]);
    } else {
      if(home_folder) {
        refresh_pirana(home_folder);
      } else {
        $("#message_dialog").html("<p>Sorry, could not find a folder to open.</p>").dialog("open");
      }
    }
    if(!flow_started) {
      start_file_upload_support();
      flow_started = true;
    }
    // popup_msg('success', "Welcome to PiranaJS");
  }
}

function show_active_console (console_id) {
  console_active = console_id;
  refresh_console_tabs();
  refresh_console_content("", console_active);
}

function refresh_console_content(str, console_id) {
  // if (str.match('^(Password)') || key == "R") { // new run
  if (str !== undefined) {
    if (console_all[console_id] === undefined) {
      console_all[console_id] = "";
    }
    if (! str.match(/^(spawn|Password|undefined)/)) {
      str.replace(/^\n/, "");
      console_all[console_id] += str;
    }
  }
  var outp = $("#node_output");
  if (console_all[console_active] !== undefined) {
    outp.val(console_all[console_active]); // this can be implemented faster!!
    outp.scrollTop(outp[0].scrollHeight - outp.height());
    if (show_console == 1) {
      $('#node_output_dialog').dialog('open');
    }
    status("");
  }
}

function start_cluster_autorefresh () {
  if(refresh_timer_started == 0) { // don't start the timer twice
  setInterval( "refresh_process_info_monitor()", 5000 );  // run
}
};

function populate_projects (active_project) {
  var options = [];
  var keys = Object.keys(project_folders).sort(function (a, b) {
    return a.toString().toLowerCase().localeCompare(b.toString().toLowerCase());
  });
  var option_string;
  var sel = keys[0];
  for(var i = 0; i < keys.length; i++) {
    sel_flag = "";
    if (keys[i] == active_project) {
      sel_flag = 'selected';
      sel = keys[i] + "#" + project_folders[keys[i]] ;
    };
    option_string += "<option value='" + keys[i] + "#" + project_folders[keys[i]] +"' "+sel_flag+">" + keys[i] + "</option>";
  };
  $("select[name='project_selector']").find('option').remove().end().append(option_string);
  $("select[name='project_selector']").select2('val', [sel]);
  active_project = sel;
  inc_login_progress("login_prg_project");
  // get last used project
  // refresh_pirana(home_folder);
}

function refresh_users_logged_in_selector(users_logged_in) {
  options = "<option value='all'>To: everybody</option>";
  for (i in users_logged_in) {
    options += "<option value='"+users_logged_in[i]+"'>To: "+users_logged_in[i]+"</option>";
  }
  $("#chat_user_selector").html(options);
}

function populate_model_templates (templates) {
  var option_string;
  if (templates !== undefined) {
    for (var key in templates) {
      option_string += "<option value='"+key+"'>" + templates[key] + "</option>";
    }
    $("select[name='template_selector']").find('option').remove().end().append(option_string);
    $("select[name='template_selector']").select2('val', [0]);
  }
}

function start_tty (user, socket) {
  // set up the TTY
  term = new Terminal({
    cols: 100,
    rows: 32,
    useStyle: true,
    screenKeys: false,
    cursorBlink: false
  });
  all_log = "";
  term.on('data', function(data) {
    all_log += data;
    var send = 1;
    socket.emit('data', data);
  });

  term.open(document.getElementById('tty'));
  var login_cmd = "sudo -u " + window.user_id.trim() + " -s sh\r\n";
  socket.emit('data', login_cmd);
  return (login_cmd);
}

socket.on('connect', function () {

  // socket.on('refresh', function (msg) {
    // right_selector(window.sel, 1); // also calls refresh_files()
    // var up_dir_data = [ {
    //   "descr" : " [ up one level ] ",
    //   "run" : "..",
    // } ];
    // if (msg.output.match("Folder not readable")) {
    //   $("#message_dialog_no_title").dialog("close");
    //   $("#main").jqGrid('clearGridData');
    //   $("#message_dialog").html("<p>This folder is not readable. Please check file and folder permissions.</p>").dialog("open");
    //   $("#main").trigger("reloadGrid");
    //   $("#cwd_input").select();
    // } else {
    //   var parse_info = try_parse_json (msg.output);
    //   if (parse_info) {
    //     if (parse_info.dir_not_exists == 1) {
    //       console.log("Folder does not exist");
    //       main_model_data = {};
    //       $("#cwd_input").css({'background-color' : '#ff3333'});
    //     } else {
    //       $("#cwd_input").css({'background-color' : '#FFFFFF'});
    //       var new_data = parse_info.rows;
    //       new_data = _.reject(new_data, function(q) { return q.run.match(/^dir-/i) }); // filter out folders
    //       var filtered = filter_hidden_models(new_data);
    //       main_model_data = up_dir_data.concat(filtered.data); // global variable
    //       if (filtered.hidden > 0) {
    //         $("#n_hidden").html("<b>(" + filtered.hidden + " hidden)</b>");
    //       } else {
    //         $("#n_hidden").html("("+filtered.hidden + " hidden)");
    //       }
    //     }
    //     // $('#node_output').text(msg.output);
    //     $("#main").jqGrid('clearGridData');
    //     $("#main").jqGrid('setGridParam', { data: main_model_data });
    //     $("#main").trigger("reloadGrid");
    //     for (var i in mod_sel) {
    //       $("#main").jqGrid('setSelection', mod_sel[i]);
    //     }
    //     $("#main").closest(".ui-jqgrid-bdiv").scrollTop(main_scroll_pos);
    //     $("#message_dialog_no_title").dialog("close");
    //   } else {
    //     status("No data received from server during folder load.");
    //     //		alert("No data received from server during folder load:\n"+msg.output+"\nPlease log in if you haven't done so.\nAlso check installation of APIrana and PiranaJS.");
    //   }
    // }
    // // refresh_files(); // already called from "right_selector()"
  // });

  var all_dat;
  socket.on('data', function(data) {
    all_dat += data;
    if(show_console) {
      if (term !== undefined) {
        term.write(data);
        $("#tty").focus();
      }
    } else {
      login_dat += data;
      if(login_dat.match(login_cmd)) {
        show_console = true;
        socket.emit('data', '\nclear\n');
      }
    }
  });
  socket.on('disconnect', function() {
    if (term !== undefined) {
      term.destroy();
    }
  });
  socket.on('zed_exists', function() {
    console.log("Zed found");
    $('#menu_tools').append('<li><a href="#" onclick="start_zed(); return false;">Start Zed remote</a></li>');
  });
  socket.on('links', function(links) {
    for (var key in links) {
      if(!(key in menu_links)) {
        var title = 'Open '+key;
        var regexp = /\:([0-9]*)$/;
        var match = regexp.exec(links[key]);
        var port_html = "";
        if (match !== null) {
          //console.log("Port specified: ");
          port_html = 'onclick="event.target.port='+match[1]+'"';
          links[key] = links[key].replace(/\:[0-9]*$/, "");
          links[key] = links[key].replace(/http:\/\/localhost/, "/");
        }
        var html = '<li title="'+title+'"><a href="'+links[key]+'" target="_blank" '+port_html+'>'+key+'</a></li>';
        $("#menu_view").after(html);
        menu_links[key] = links[key];
      }
    }
  });

  socket.on('allow_tty', function () {
    $("#toolbar_estimates").after('<button title="Open shell" id="button_tty" onClick="toggle_open_shell(); return false;">&nbsp;</button>');
    $("#button_tty").button({ icons: { primary: "ui-icon-console" } }).css("height", bht);
  });

  // main socket functions
  socket.on('cmd', function(msg) {
    // console.log("Message received: "+msg.output);
    var key = msg.cmd_id;
    var console_id = zero_add(msg.console_number, 2) + "-" + key;
    var str = msg.output;
    if (str.match(/zedapp/)) {
      str = str.replace(/edit\:/, "edit:<pre>");
      str = str.replace(/Press/, "</pre>Press");
      $("#message_dialog_large").html(str);
      $("#message_dialog_large").dialog("open");
    }
    if (str !== undefined) {
      refresh_console_content(str, console_id);
      var re = new RegExp("(" + key + ") done");
      var text = $("#message_dialog_non_modal").html();
      // if (text.trim() == "") {
      //     text = "<b class='focus'>Messages:</b><br>"
      // }
      var tabs = Object.keys(console_windows);
      var num = '"'+tabs[Number(msg.console_number)-1]+'"';
      if (str.match(re, "regex") || str.match(/^No file/)) {
        // var height = $("#message_dialog_non_modal").outerHeight() + 20;
        var job_text = "<a class='growl' href='#' onClick='show_active_console("+num+"); toggle_open_console();'><i class='fa fa-bell fa-lg'></i>&nbsp; [ "+ msg.console_number + " ] : "+ key + " ";
        var all = console_all[console_id] + str;
        if (all.match("NMtran failed")) {
          job_text += "failed to start (NM-TRAN error)</a><br>";
          play_sound("fail");
          popup_msg('error', text + job_text);
          $.post('/api/get_last_nm_error', {
            "cmd": "get_last_nm_error",
            "folder": $("#cwd_input").val()
          }, function(msg) {
            popup_msg('error', msg.text);
          });
        } else {
          var done = false;
          if (all.match("No file")) {
            job_text += "failed to start (dataset not found)</a><br>";
            play_sound("fail");
            popup_msg('error', text + job_text);
            done = true;
          }
          if (!done) {
            job_text += "is done</a><br>";
            play_sound("done");
            popup_msg('notice', text + job_text);
          }
        }
      }
      var job_text = "<a class='growl' href='#' onClick='show_active_console("+num+"); toggle_open_console();'><i class='fa fa-bell fa-lg'></i>&nbsp; [ "+ msg.console_number + " ] : ";
      if (str.match(/S\:1\s/)) {
        job_text += key + " started</a>";
        popup_msg('notice', text + job_text);
      }
      if (str.match("Resampling")) {
        job_text += "bootstrap started</a>";
        popup_msg('notice', text + job_text);
      }
      if (str.match('/tool/bootstrap.pm')) {
        job_text = "failed to start bootstrap</a>";
        play_sound("fail");
        popup_msg('error', text + job_text);
      }
    }
  });
  socket.on('cmd_r', function(msg) {
    var key = msg.cmd_id;
    var str = msg.output;
    refresh_console_tabs(str, "R");
    // console_out[msg.cmd_id] = console_out[msg.cmd_id].replace(/\[[\d;]*m/g,"");
  });
  // socket.on('get_last_nm_error', function(msg) {
  //   popup_msg('error', msg.text);
  // });
  // socket.on('wrong_login', function (msg) {
  //   $("#login_progress_dialog" ).dialog("close");
  //   play_sound("wrong");
  //   // $("#message_dialog").html("Wrong username or password. Please try again.").dialog("open");
  //   // popup_msg("error", "Wrong login credentials.");
  //   // logout();
  //   $("#user_login_form").dialog("open");
  // });
  socket.on('initialize_call', function (msg) {
    var currentdate = new Date();
    Date.prototype.timeNow = function(){
      return ((this.getHours() < 10)?"0":"") + this.getHours() +":"+ ((this.getMinutes() < 10)?"0":"") + this.getMinutes() ;
    };
    var time = currentdate.timeNow();
    $("#chat_area").val($('#chat_area').val() + "[" + time + "] "+ msg.user_id + " logged in.\n");
    if (_.indexOf(users_logged_in) === -1) {
      users_logged_in.push(msg.user_id);
    }
    refresh_users_logged_in_selector(users_logged_in);
  });
  // socket.on('run_r_script', function (msg) {
  //   var str = msg.output;
  //   //	    str = str.replace(/\n/g, '<br />');
  //   $('#node_output').val(str);
  //   $('#node_output_dialog').dialog('open');
  //   status("");
  // });
  // socket.on('refresh_scripts', function (msg) {
  //   script_list_data = try_parse_json (msg.output);
  //   if (script_list_data) {
  //     populate_scripts_list(script_list_data);
  //   } else {
  //     console.log("Scripts not found!");
  //   }
  // });
  // socket.on('copy_script', function (msg) {
  //   refresh_scripts();
  // });
  // socket.on('get_templates', function (msg) { // step 3 of login
  //   inc_login_progress("login_prg_templates");
  //   var outp = try_parse_json(msg.output);
  //   if (outp) {
  //     var model_templates = {};
  //     if (outp.rows !== undefined) {
  //       for (i = 0; i < outp.rows.length; i++) {
  //         model_templates[outp.rows[i].run] = outp.rows[i].descr;
  //       }
  //       populate_model_templates(model_templates);
  //     }
  //   } else {
  //     console.log("No templates found!");
  //   }
  // });
  // socket.on('refresh_reports', function (msg) {
  //   report_list_data = try_parse_json(msg.output);
  //   if (report_list_data) {
  //     populate_reports_list(report_list_data);
  //   } else {
  //     console.log("Reports not found!");
  //   }
  // });
  // socket.on('refresh_vc', function (msg) {
    // git_list_data = try_parse_json(msg.output);
    // if (git_list_data) {
    //   var today = new Date();
    //   for (i in git_list_data) {
    //     var tmp = new Date(git_list_data[i].date);
    //     var ago = (today-tmp)/(3600*1000);
    //     var unit = "hr";
    //     if (ago > 24) {
    //       ago = ago/24;
    //       unit = "day";
    //       if (ago > 7) {
    //         ago = ago/7;
    //         unit = "week";
    //         if (ago > 4.3) {
    //           ago = ago/4.3
    //           unit = "month";
    //           if (ago > 12) {
    //             ago = ago/12
    //             unit = "year";
    //           }
    //         }
    //       }
    //     }
    //     if (Math.round(ago) > 1) { unit += "s"}
    //     git_list_data[i].date = Math.round(ago) + " " + unit;
    //     git_list_data[i].message.replace(/\-/, " ");
    //   }
    //   populate_list_with_data("#list_git", git_list_data);
    // } else {
    //   // console.log("Git commit info not found!");
    //   // console.log(msg.output);
    // }
  // });
  socket.on('show_login_form', function (msg) {
    $( "#user_login_form" ).dialog( "open" );
  });
  // socket.on('get_license_status', function(msg) {
  //   if (msg.license_info === undefined || msg.license_info.license_valid_code === undefined || msg.license_info.license_valid_code === 0) {
  //     license_valid = 0;
  //     $("#license_info").html("<b class='error'>UNLICENSED USE OR LICENSE INVALID!</b>");
  //   } else {
  //     license_valid = 1;
  //     if (msg.license_info.client === 'academic') {
  //       $("#license_holder").html("Licensed to academic user ("+msg.license_info.license_valid+")");
  //     } else {
  //       $("#license_holder").html("Licensed to "+msg.license_info.client+ " ("+msg.license_info.license_valid+")");
  //     }
  //   }
  //   sock( {
  //     cmd: "get_home_folder"
  //   });
  // });

  socket.on('user_logon', function (msg) {
    // announce user login (is this still used?)
    var currentdate = new Date();
    Date.prototype.timeNow = function(){
      return ((this.getHours() < 10)?"0":"") + this.getHours() +":"+ ((this.getMinutes() < 10)?"0":"") + this.getMinutes() ;
    };
    var time = currentdate.timeNow();
    var chat = $("#chat_area");
    var chat = $("#chat_area");
    chat.val($('#chat_area').val() + "[" + time + "] "+ msg.user_id + " logged in.\n");
    chat.scrollTop(chat[0].scrollHeight - chat.height());
  });
  socket.on('logout', function (msg) {
    if(window.user_id != "") {
      $("#main").jqGrid('clearGridData');
      $("#list_scripts").jqGrid('clearGridData');
      $("#list_files").jqGrid('clearGridData');
      $("#list_est").jqGrid('clearGridData');
      $("#list_reports").jqGrid('clearGridData');
      $("#list_r").jqGrid('clearGridData');
      $("#list_git").jqGrid('clearGridData');
      main_model_data = [];
      script_list_data = [];
      file_list_data = [];
      report_list_data = [];
      console_windows = {}; console_all =  {};
      project_folders = {}; active_project;
      console_number = 0;
      cluster_monitor_active = 0;
      refresh_timer_started = 0;
      login_progress = 0;
      home_folder = ""; psn_history_log = [];
      refresh_flag = 0;
      $("#login_name").val("Not logged in")
      // alert(window.user_id + " was successfully logged out.");
    }
    window.user_id = "";
    var message = "<p class='grey'>Please login below using your server username and password. These are the same credentials that you use when you login to your server over ssh.</p>";
    if (logout_message !== "") {
      var message = logout_message + "<p class='grey'>Please login again below using your server username and password.</p>";
    }
    $("#login_message").html(message);
    $("#user_login_form").dialog("open");
    logout_message = "";
  });

  socket.on('get_mpi_settings', function(data) {
    mpi = data.mpi;
    if(mpi) {
      var keys = Object.keys(mpi.presets).sort();
      var option_string = "<option value='no' selected>Don't use MPI</option>";
      Object.keys(mpi.presets).forEach(function (key) {
        if (key !== undefined) {
          option_string += "<option value='" + key+"'>" + key + "</option>";
        }
      });
      $("select[name='mpi_selector']").find('option').remove().end().append(option_string);
      $("select[name='mpi_selector']").select2("val", "no");
    }
  });

  // socket.on('get_psn_nm_versions', function (msg) { // step 1 of login
  //   var psn_nm_versions = try_parse_json(msg.output);
  //   if (psn_nm_versions) {
  //     var keys = Object.keys(psn_nm_versions).sort();
  //     var option_string;
  //     Object.keys(psn_nm_versions).forEach(function (key) {
  //       if (key !== undefined) {
  //         var sel_flag = '';
  //         if (key == 'default') {
  //           sel_flag = "selected";
  //         }
  //         option_string += "<option value='" + key+"' "+sel_flag+">" + key + "</option>";
  //       }
  //     });
  //     $("select[name='psn_nm_selector']").find('option').remove().end().append(option_string);
  //     $("select[name='psn_nm_selector']").select2("val", "default");
  //   }
  // });
  // socket.on('psn_tool_default_args', function (msg) { // step 2 of login
  //   inc_login_progress("login_prg_psn");
  //   psn_tool_default_args = try_parse_json(msg.output);
  //   if (!psn_tool_default_args) {
  //     psn_tool_default_args = {};
  //   }
  // });
  // socket.on('refresh_projects', function (msg) {
    // var option_string = "";
    // var reports_list_data = try_parse_json(msg.output);
    // if (reports_list_data) {
    //   var proj_json = try_parse_json(msg.output);
    //   if (proj_json && proj_json.length > 0) {
    //     var active = proj_json[0].project;
    //     var active_folder = proj_json[0].folder;
    //     var options = [];
    //     for(var i = 0; i < proj_json.length; i++) {
    //       project_folders[proj_json[i].project] = proj_json[i].folder;
    //     }
    //   }
    //   active_folder = project_folders[active_project];
    //   if((_.indexOf(_.keys(project_folders), active_project) < 0) || (active_project == "")) {
    //     active_project = "";
    //     active_folder = home_folder;
    //   }
    //   // populate_projects();
    //   sock({
    //     cmd: "get_project_active", // will also call populate_projects
    //     home: home_folder
    //   });
    //   $('#cwd_input').val(active_folder);
    // }
    // status("");
  // });
  // socket.on('get_folder_info', function (msg) {
    // if (msg.output !== undefined && msg.output.trim() !== "" ) {
    //   var cmd = msg.output.replace("/usr/bin/","");
    //   var info = "<code>"+cmd+"</code>"
    //   var height = Math.round(26 + (cmd.length / 50) * 19);
    //   var jq = "#folder_"+msg.input_obj.type;
    //   if (msg.input_obj.type == "nmtran_error") {
    //     info = "<div class='error'><b>/NM_run1:</b></div>"+info;
    //     info_nmtran_error = height;
    //     $(jq).dialog({ "height": height});
    //     $(jq).dialog({ "position": ["right-5", "bottom-"+(info_psn_cmd).toString()]});
    //   }
    //   if (msg.input_obj.type == "psn_cmd") {
    //     info = "<div class='focus'><b>PsN command:</b></div>"+info;
    //     info_psn_cmd = height;
    //     $(jq).dialog({ "position": ["right-5", "bottom-15"]});
    //   }
    //   $(jq).html(info);
    //   $(jq).dialog({ "height": height });
    //   $(jq).dialog("open");
    //   // resetTimer_folder_info();
    // }
  // });

  // socket.on('download_folder', function (msg) {
  //   //console.log(msg);
  //   window.open('/download/'+msg.input_obj.filename,'_self');
  //   $("#message_dialog").html("").dialog("close");
  //   status();
  // });

  socket.on('file_saved_editor', function(msg) {
    	console.log(msg);
    	if(msg.error) {
    	    $("#message_dialog").html("Sorry, this file is not writeable.").dialog("open");
    	}
  });

  // socket.on('file_download', function (msg) {
  //   if(msg.target_file !== undefined) { // single file download
  //     window.open('/download/'+msg.target_file,'_self');
  //   } else {
  //     window.open('/download/'+msg.input_obj.filename,'_self');
  //   }
  //   $("#message_dialog").html("").dialog("close");
  //   status();
  // });

  // socket.on('create_run_record', function (msg) {
  //   sock({
  //     "cmd": "open_file_in_spreadsheet",
  //     "file": msg.input_obj.filename,
  //     "folder": $("#cwd_input").val()
  //   });
  //   status();
  // });

  // socket.on('file_delete', function (msg) {
  //   refresh_pirana();
  //   status();
  // });

  // socket.on('get_project_active', function (msg) {
  //   inc_login_progress("login_prg_project");
  //   if(msg.output && msg.output !== "") {
  //     active_project = msg.output;
  //   }
  //   populate_projects(active_project);
  // });

  // socket.on('set_project_active', function (msg) {
  //   // console.log('set proj active');
  // });

  // socket.on('kill_process', function (msg) {
  //   refresh_process_info_monitor();
  // });

//   socket.on('process_info', function (msg) {
//     var ps_info = [{
//       "command": "None active"
//     }];
//     var ps_get = try_parse_json(msg.output);
//     if (ps_get) {
//       ps_info = ps_get;
//     }
//     var dummy = false;
//     if (dummy) {
//       populate_list_with_data("#ps_monitor",
//       [ { cpu: "1",
//       mem: "1",
//       time: "1",
//       pid: "12345",
//       user: "1",
//       command: "1",
//       args: "1",
//     }
//   ]);
// } else {
//   populate_list_with_data("#ps_monitor", ps_info);
// }
// });

// socket.on('qstat_info', function (msg) {
  // jobs_a_info = [{ "name": "[No jobs]" }];
  // jobs_s_info = [{ "name": "[No jobs]" }];
  // nodes_use = [{ "name": "[No nodes]" }];
  // nodes_jobs = [{ "name": "" }];
  // var qstat_all = try_parse_json(msg.output);
  // if (qstat_all) {
  //   // console.log(msg.output);
  //   if (qstat_all.running_jobs.length > 0) {
  //     jobs_a_info = qstat_all.running_jobs;
  //   }
  //   if (qstat_all.scheduled_jobs.length > 0) {
  //     jobs_s_info = qstat_all.scheduled_jobs;
  //   }
  //   if (qstat_all.node_use.length > 0) {
  //     nodes_use = qstat_all.node_info;
  //   }
  // }
  // populate_list_with_data("#jobs_a_monitor", jobs_a_info);
  // populate_list_with_data("#jobs_s_monitor", jobs_s_info);
  // populate_list_with_data("#nodes_monitor", nodes_use);
  // if(qstat_all && monitor_active_node !== undefined && nodes_use) {
  //   var tmp = nodes_use[monitor_active_node]
  //   if(tmp) {
  //     nodes_jobs = tmp.jobs
  //   }
  // } else {
  //   jobs_on_node = "";
  // }
  // populate_list_with_data("#nodes_jobs_monitor", nodes_jobs);
// });

// socket.on('intermed_info', function (msg) {
//   var inter = try_parse_json(msg.output);
//   if (inter) {
//     inter_db = inter;
//     populate_intermed_info(inter);
//   }
// });

socket.on('message_all', function (msg) {
  if (msg.to_user === window.user_id | msg.to_user === 'all') {
    var currentdate = new Date();
    Date.prototype.timeNow = function(){
      return ((this.getHours() < 10)?"0":"") + this.getHours() +":"+ ((this.getMinutes() < 10)?"0":"") + this.getMinutes() ;
    };
    var time = currentdate.timeNow();
    var chat = $("#chat_area");
    var chat_status = $("#statusbar_chat");
    chat.val($('#chat_area').val() + "[" + time + "] "+ msg.user_id + "@"+msg.to_user+": "+ msg.text + "\n");
    chat_status.val("Chat: "+msg.text.substring(0,20));
    chat.scrollTop(chat[0].scrollHeight - chat.height());
    $("#chat_window").dialog("open");
  }
});
// socket.on('project_remove', function (msg) {
//   refresh_projects(cwd);
//   status("");
// });
// socket.on('project_add', function (msg) {
//   var proj = msg.input_obj.project;
//   active_project = proj;
//   active_folder = document.getElementById('cwd_input').value;
//   project_folders[proj] = active_folder;
//   populate_projects(active_project);
//   status("");
// });
// socket.on('rm', function (msg) {
//   var cwd = chomp(msg.input_obj.folder);
//   refresh_pirana(cwd);
//   status("");
// });
socket.on('file_saved', function (msg) { // first part done, now send the current folderpath back to the server
  var input = {
    "cmd": "handle_file_upload",
    "source_file": msg.event.file.pathName,
    "source_name" : msg.event.file.name,
    "target_folder":  $('#cwd_input').val()
  }
  sock (input);
});
socket.on('upload_file_done', function (msg) {
  setTimeout(function() { refresh_flag = 0; }, 200);
  if (refresh_flag == 0) { // mainly to avoid multiple refrehses during multiple file uploads
    // console.log('requesting refresh');
    refresh_flag = 1;
    refresh_pirana($('#cwd_input').val());
  }
  status("");
});
// socket.on('new_folder', function (msg) {
//   var cwd = chomp(msg.input_obj.folder);
//   refresh_pirana(cwd);
//   status("");
// });
// socket.on('duplicate', function (msg) {
//   refresh_pirana( $('#cwd_input').val() );
//   sock ({
//     cmd: 'code_editor',
//     mode: 'nonmem',
//     folder: $('#cwd_input').val(),
//     file: msg.input_obj.new_mod + '.mod'
//   });
//   console.log({
//     cmd: 'code_editor',
//     mode: 'nonmem',
//     folder: $('#cwd_input').val(),
//     file: msg.input_obj.new_mod + '.mod'
//   });
//   status("");
// });
// socket.on('files', function (msg) {
//   file_list_data = msg.output;
//   $("#list_files").jqGrid('clearGridData');
//   $("#list_files").jqGrid('setGridParam', { data: msg.output } );
//   $("#list_files").trigger("reloadGrid");
//   status("");
// });
// socket.on('diff', function (msg) {
//   open_diff_window(msg.output);
//   status("");
// });
// socket.on('psn_help', function (msg) {
//   code_editor(msg, {x: ($( window ).width() - 310), y: 10, hide_save_buttons: true });
//   status("");
// });

// socket.on('nm_help_index', function (msg) {
//   var tmp = try_parse_json(msg.output);
//   if (tmp) {
//     nm_help_index = [];
//     var help = tmp.help_files;
//     for (var key in help) {
//       nm_help_index.push({
//         key: key,
//         file: help[key]
//       })
//     }
//     nm_help_index = _.sortBy(nm_help_index, function(row) { return(row.key) });
//   }
//   populate_list_with_data("#list_nm_help", nm_help_index);
//   status("");
// });

// socket.on('nm_help_topic', function (msg) {
//   var tmp = try_parse_json(msg.output);
//   if (tmp) {
//     var key = Object.keys(tmp);
//     $("#nm_help_box").html(tmp[key.shift()]).scrollTop(0);
//   }
//   status("");
// });

// socket.on('get_notes', function (msg) {
//   if (msg.output !== undefined) {
//     show_notes_editor(msg.output);
//   }
//   status("");
// });

socket.on('created_new_note', function (msg) {
  sock({
    cmd: 'get_notes',
    folder: $("#cwd_input").val()
  })
});

// socket.on('code_editor', function (msg) {
//   code_editor(msg);
//   status("");
// });
// socket.on('open_file_in_spreadsheet', function (msg) {
  // var tmp;
  // flag = false;
  // if (msg.file.match(/\.csv$/)) {
  //   tmp = csv2json_obj(msg.output);
  //   flag = true;
  // }
  // if (msg.file.match(/tab/) && !flag) {
  //   tmp = tab2json_obj(msg.output);
  //   flag = true;
  // }
  // $('#spreadsheet').jqGrid('GridUnload');
  // load_spreadsheet_grid(tmp.colnames, tmp.colmodel);
  // show_in_spreadsheet(tmp.json, msg.file);
  // $("#spreadsheet_window").dialog("option", "width", 720);
  // $("#spreadsheet_window").dialog("option", "height", 560);
  // $("#spreadsheet").jqGrid('setGridHeight', 450 );
  // $("#spreadsheet").jqGrid('setGridWidth', 700 );
  // status("");
// });
// socket.on('create_vrr', function (msg) {
//   // console.log(msg.output);
//   var json = try_parse_json(msg.output);
//   if (json) {
//     refresh_vrr(json);
//   }
//   $('#vrr').dialog('open');
//   $('#vrr').focus();
//   status("");
// });
// socket.on('build_tex_pdf', function (msg) {
//   var file = msg.input_obj.tex_file.replace(/\.tex/, ".pdf");
//   // console.log(file);
//   sock ({
//     cmd: 'server_file_viewer',
//     format: "pdf",
//     folder: $('#cwd_input').val(),
//     file: file
//   });
// });

// socket.on('psn_log', function (msg) {
//   psn_history_log = [];
//   var log = try_parse_json(msg.output);
//   if (log) {
//     psn_history_log = log;
//   }
//   // if(msg.input_obj.callback === 'repeat') {
//   var cmd = psn_history_log[0];
//   if(cmd && cmd.command) {
//       var all = cmd.command.split(" ");
//       var tool = all[0];
//       var new_command = "";
//       var mods = $("#main").getGridParam('selarrrow');
//       for(var i = 0; i < all.length; i++) {
// 	  if(all[i] == tool || all[i].match(/^\-/)) {
// 	      new_command += all[i] + " ";
// 	  }
//       }
//       for(var j = 0; j < mods.length; j++ ) {
// 	  new_command += mods[j] + ".mod ";
//       }
//       if (cmd !== undefined) {
// 	  $('#psn_execute_dialog_command').val(new_command);
// 	  if(new_command.match("run_on_sge")) {
// 	      $("#run_on_grid").attr('checked',true);
// 	  } else {
// 	      $("#run_on_grid").attr('checked',false);
// 	  }
//       }
//       // force update of mpi arguments
//       var val = $("select[name='mpi_selector']").select2("val");
//       $("select[name='mpi_selector']").select2("val", val);
//       update_mpi_arguments(val);
//     }
//     status("");
// });

// socket.on('get_data_info', function (msg) {
//   if (msg.output !== undefined) {
//     var data_info = try_parse_json(msg.output);
//     if (data_info) {
//       update_data_inspector(data_info, 0);
//     } else {
//       // console.log(msg.output);
//     }
//   }
//   status("");
// });

// socket.on('update_data_inspector_plot', function (msg) {
//   download_png = "";
//   if(msg.error) {
//     $("#message_dialog_large").html("<p>Oops... something went wrong running R: </p><pre>"+msg.output+"</pre>").dialog("open");
//   } else {
//     $("#data_inspector_plot").html('<embed width="480" height="400" src="tmp/'+msg.input_obj.outfile+'" type="image/svg+xml" />');
//     download_png = msg.input_obj.outfile.replace(/.svg/, ".png");
//     $("#download_png_link").attr('href', window.location.origin + "/tmp/" + download_png);
//     $("#download_svg_link").attr('href', window.location.origin + "/tmp/" + msg.input_obj.outfile);
//   }
//   status("");
// });

// socket.on('data_inspector_r_code', function (msg) {
//   data_inspector_r_code = msg.code;
// });

// socket.on('server_file_viewer', function (msg) {
//   var url = msg.file_url;
//   if (msg.format == "pdflatex" || msg.format == "pdf") {
//     url = "pdfobject/viewer.html?pdf=../../" + url;
//   }
//   var pdf= "<embed id='pdf_embed' width=640 height=640 src='"+"../../" + url + "'/>";
//   $("#pdf_viewer").html(pdf);
//   $("#pdf_viewer").dialog("option", "width", ($("#pdf_embed").width() + 14));
//   $("#pdf_viewer").dialog("option", "height", ($("#pdf_embed").height() + 40));
//   $("#pdf_viewer").dialog("open");
//   status("");
// });
// socket.on('compare_estimates', function (msg) {
  // var tmp = csv2json_obj(msg.output);
  // $('#spreadsheet').jqGrid('GridUnload');
  // load_spreadsheet_grid(tmp.colnames, tmp.colmodel);
  // //        $("#spreadsheet").jqGrid('setGridParam', { width: 300, height: 200 });
  // $("#spreadsheet_window").dialog("option", "width", 300);
  // $("#spreadsheet_window").dialog("option", "height", 300);
  // show_in_spreadsheet(tmp.json, msg.file);
  // $("#spreadsheet").jqGrid('setGridWidth', parseInt($("#spreadsheet_window").width() - 20) );
  // $("#spreadsheet").jqGrid('setGridHeight', parseInt($("#spreadsheet_window").height() - 20) );
  // status("");
// });

// socket.on('get_estimates', function (msg) {
//   current_est = msg;
//   var run_info = parse_estimates_data(msg);
//   curr_run_estimates = run_info;
//   $("#list_estimates").jqGrid('clearGridData');
//   $("#list_estimates").jqGrid('setGridParam', { data: run_info });
//   $("#list_estimates").trigger("reloadGrid");
//   status();
// });

// socket.on('run_report', function (msg) {
//   // console.log(msg);
//   // console.log("Attempting to open created run report...");
//   if (msg.input_obj.format == "txt") {
//     msg.mode = "txt";
//     code_editor(msg);
//   }
//   if (msg.input_obj.format == "r_obj") {
//     msg.mode = "r";
//     console.log(msg);
//     code_editor(msg);
//   }
//   if (msg.input_obj.format == "tex") {
//     msg.mode = "tex";
//     code_editor(msg);
//   }
//   if (msg.input_obj.format == 'pdflatex') {
//     // console.log("Requesting file: "+msg.input_obj.outfile);
//     sock ({
//       cmd: 'server_file_viewer',
//       format: msg.input_obj.format,
//       folder: $('#cwd_input').val(),
//       file: msg.input_obj.outfile
//     });
//   }
//   if (msg.input_obj.format == 'docx') {
//     sock ({
//       cmd: 'open_run_report',
//       folder: $('#cwd_input').val(),
//       outfile: msg.input_obj.outfile,
//       file: msg.input_obj.file,
//       format: msg.input_obj.format,
//       output: msg.output
//     })
//   }
//   if (msg.input_obj.format == "html") {
//     sock ({
//       cmd: 'open_run_report',
//       folder: $('#cwd_input').val(),
//       outfile: msg.input_obj.outfile,
//       file: msg.input_obj.file,
//       format: msg.input_obj.format,
//       output: msg.output
//     })
//   }
// });

socket.on('download_file', function (msg) {
  if (msg.target_file !== undefined) {
    var url = msg.target_file.replace(/public\//,"");
    // console.log("Opening run report " + url);
    window.open(url, '_self');
  }
  status("");
});

// socket.on('open_run_report', function (msg) {
//   if (msg.target_file !== undefined) {
//     var url = msg.target_file.replace(/public\//,"");
//     // console.log("Opening run report " + url);
//     window.open(url, '_blank');
//   }
//   status("");
// });

// socket.on('unhide_all_runs', function (msg) {
//   var cwd = chomp(msg.folder);
//   refresh_pirana(cwd);
// });
// socket.on('reset_pirana_db', function (msg) {
//   refresh_pirana();
// });
// socket.on('remove_modelfit_folders', function (msg) {
//   refresh_pirana();
// });
// socket.on('set_color', function (msg) {
//   status('');
// });
// socket.on('set_flag', function (msg) {
//   status('');
// });
// socket.on('set_info', function (msg) {
//   status('');
//   var cwd = chomp(msg.folder);
//   refresh_pirana(cwd);
// });
socket.on('refresh_pirana', function (msg) {
  status('');
  var cwd = chomp(msg.folder);
  // console.log("refresh from refresh_pirana");
  refresh_pirana(cwd);
});
// socket.on('get_home_folder', function (msg) { // step 4 of login
//   var cwd = chomp(msg.folder);
//   if (cwd.match(/no passwd entry/i)) {
//     $("#login_progress_dialog" ).dialog("close");
//     play_sound("wrong");
//     // popup_msg("error", "Wrong login credentials.");
//     logout();
//     $("#user_login_form").dialog("open");
//   } else {
//     // console.log("home folder:"+ cwd);
//     inc_login_progress("login_prg_folder");
//     play_sound("login");
//     home_folder = cwd;
//     //            setTimeout(
//     refresh_projects(cwd);
//     //, 200);
//   }
// });
// socket.on('translate', function (msg) {
//   if (msg.output.match(/\*\* Translated code: \*\*/)) {
//     var tmp = msg.output.split(/\*\* Translated code: \*\*/);
//     msg.output = tmp[1];
//   }
//   msg.mode = msg.input_obj.translate_to.toLowerCase();
//   if(msg.mode.match(/R::/)) {
//     msg.mode = "R";
//   }
//   code_editor(msg);
//   //console.log(input.input_obj.out);
// });
// socket.on('new_model_from_template', function (msg) {
//   refresh_pirana($('#cwd_input').val() );
// });

status("");
});

function filter_hidden_models(data) {
  var new_data = [];
  var hidden = 0;
  for(var i = 0; i < data.length; i++) {
    if (data[i].hidden != 1) {
      new_data.push(data[i]);
    } else {
      hidden++;
    }
  }
  var filtered = {
    "data": new_data,
    "hidden": hidden
  }
  return(filtered);
}
