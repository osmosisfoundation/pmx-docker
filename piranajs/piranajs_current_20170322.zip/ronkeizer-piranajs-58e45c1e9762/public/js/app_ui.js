// globals
var menu_links = {};
var y_len = 130;
var datainspector_x_selected;
var datainspector_y_selected;
window.sel = 1;
window.view_column_filters = 0;
window.user_id = "";
var current_editor_file = "";
var show_console = 0;
var console_active;
var psn_help_dat = [];
var doc_height = $(window).height() * 0.8;
var doc_width = $(window).width() * 0.8;
var main_grid_active = 1;
var files_grid_active = 1;
var editor_active = 0;
var psn_tool_default_args = {};
var main_model_data, script_list_data, file_list_data, report_list_data, psn_nm_versions;
var inter_db; // object with intermediate estimates
var show_gradients = true;
var curr_est;
var logged_in = false;
var nm_help_index = [];
var logout_message = "";
var users_logged_in = [];
var login_progress = 0;
var info_psn_cmd = 0;
var info_nmtran_error = 0;
var main_scroll_pos = 0;
var right_grid_width = 295;
var mod_sel = [];
var messages = 0;
var term;
var login_cmd = "",
    login_dat = "";
var flow_started = false;
var show_console = false;
var tty_open = 0;
var script_sel = undefined;
var license_valid = -1;
var project_folders = {}; var active_project;
var console_windows = {}; var console_all =  {};
var console_number = 0; var cluster_monitor_active = 0;
var refresh_timer_started = 0; var data_inspector_r_code = "";
var home_folder; var psn_history_log = [];
var refresh_flag = 0;
var jobs_a_info = [{ "name": "[No jobs]" }];
var jobs_s_info = [{ "name": "[No jobs]" }];
var nodes_use = [{ "name": "[No nodes]" }];
var nodes_jobs = [{ "job-id": "" }];
var monitor_active_node = undefined;
var jobs_on_node = "";
var relative_var = 0;
var current_est = {};
var mpi = {}; var mpi_prv;
var sge = {};

function show_rstudio_viewer_pane() {
    //    alert('RStudio will be opened in a new tab.');
}

function show_notes_editor(output) {
    notes_editor.setValue(output, -1);
    $("#notes_editor_dialog").dialog("open");
}

function get_project_notes() {
    $.post('/api/get_notes', {
        folder: $("#cwd_input").val()
    }, function(msg) {
      if (msg.output !== undefined) {
        show_notes_editor(msg.output);
      }
      status("");

    });
}

function toggle_open_shell() {
    tty_open = 1 - tty_open;
    if (tty_open === 1) {
        $("#tty_dialog").dialog("open");
    } else {
        $("#tty_dialog").dialog("close");
    }
}

function get_file_extension(file) {
    if (file !== undefined) {
        return (file.split('\.').pop());
    } else {
        return ("")
    }
}

function get_file_name(file) {
    if (file !== undefined) {
        return (file.split('\/').pop());
    } else {
        return ("")
    }
}

function get_folder_name(file) {
    if (file !== undefined) {
        var tmp = file.split('\/');
        tmp.pop()
        return(tmp.join("/"));
    } else {
        return ("")
    }
}

function file_action(files, action) {
    var id = files[0];
    if (id !== undefined) {
      status("Requesting action: " + action);
      $.post('/api/'+action, {
        cmd: action,
        folder: $('#cwd_input').val(),
        filename: id,
        files: files
      }, function(msg) {
        if(action == 'file_download') {
          if(msg.target_file !== undefined) { // single file download
            window.open('/tmp/'+msg.target_file,'_self');
          } else {
            window.open('/tmp/'+msg.input_obj.filename,'_self');
          }
          $("#message_dialog").html("").dialog("close");
          status();
        }
        if(action == 'file_delete') {
          refresh_pirana();
          status();
        }
      });
    }
}

function populate_list_with_data(list, data) {
    $(list).jqGrid('clearGridData');
    $(list).jqGrid('setGridParam', {
        data: data
    });
    $(list).trigger("reloadGrid");
}

function show_in_spreadsheet(data, file) {
    // var data = [
    // 	{"col1": "test", "col2": "bla", "col3": "bla"},
    // 	{"col1": "test", "col2": "bla", "col3": "bla"},
    // 	{"col1": "test", "col2": "bla", "col3": "bla"},
    // 	{"col1": "test", "col2": "bla", "col3": "bla"}
    // ];
    if (file !== undefined) {
        $('#spreadsheet_window').dialog('option', 'title', file);
    }
    // if (layout.x !== undefined) {
    //     $('#code_editor').dialog('option', 'position', [layout.x, layout.y] );
    // }
    $("#spreadsheet").jqGrid('clearGridData');
    $("#spreadsheet").jqGrid('setGridParam', {
        data: data
    });
    $("#spreadsheet").trigger("reloadGrid");
    $('#spreadsheet_window').dialog('open');
};

function parse_estimates_data (msg) {
  var run_info = [ {
    "id": "---",
    "par" : " [ " + msg.run + " ] ",
    "est": "---",
    "se": "---",
  } ];
  if (msg.run.match('/')) {
    run_info = [ {
      "id": "---",
      "par" : "---",
      "est": "---",
      "se": "---",
    } ];
  }
  var est_data = try_parse_json(msg.output);
  if (est_data) { // check
    for (var i in est_data) {
      if (est_data[i] !== undefined) {
        est_data[i].par = est_data[i].par.toString().substr(0, 12);
        est_data[i].rse = est_data[i].rse.replace(/[\(\)]/g, "");
        if(est_data[i].id.match(/^TH/)) {
          var sd = Number(est_data[i].se);
          var est = Number(est_data[i].est);
          if(sd && est) {
            var ci1 = (est - (1.96 * sd)).toPrecision(3).toString();
            var ci2 = (est + (1.96 * sd)).toPrecision(3).toString();
            est_data[i].ci = ci1 + "&ndash;" + ci2;
          }
        }
        if(relative_var) {
          if(est_data[i].id.match(/^OM/) && est_data[i].est && est_data[i].rse) {
            // est_data[i].est = (Math.sqrt(Number(est_data[i].est))*100).toFixed(1).toString() + "%";
            est_data[i].est = (Math.sqrt(Math.exp(Number(est_data[i].est))-1)*100).toPrecision(3).toString() + "%";
            est_data[i].rse = (Number(est_data[i].rse.replace(/[\(\)%]/g,""))/2).toPrecision(3).toString() + "%";
          }
          if(est_data[i].id.match(/^SI/) && est_data[i].est && Number(est_data[i].rse)) {
            if(est_data[i].par.match(/prop/i)) {
              est_data[i].est = (Math.sqrt(Number(est_data[i].est))*100).toPrecision(3).toString() + "%";
            } else {
              est_data[i].est = (Math.sqrt(Number(est_data[i].est))).toPrecision(3).toString();
            }
            est_data[i].rse = (Number(est_data[i].rse.replace(/[\(\)%]/g,""))/2).toPrecision(3).toString() + "%";
          }
        }
      }
    }
    run_info = run_info.concat(est_data);
  }
  return(run_info)
}

function csv2json_obj(csv) {
    var json = [];
    var lines = csv.split(/\n/);
    var colnames = [];
    var colmodel = [];
    for (var i = 0; i < lines.length; i++) {
        var tmp = lines[i];
        var vals = tmp.split(/\,/);
        if (i == 0) {
            colnames = vals;
            var colwidth = Math.round(700 / vals.length);
            if(colwidth < 50) {
              colwidth = 50;
            }
            for (j = 0; j < vals.length; j++) {
                colmodel.push({
                    name: colnames[j],
                    index: colnames[j],
                    width: colwidth.toString(),
                    align: 'right'
                })
            }
        } else {
            var json_tmp = _.object(colnames.slice(0, vals.length), vals);
            json.push(json_tmp);
        }
    }
    var obj = {
        json: json,
        colnames: colnames,
        colmodel: colmodel
    }
    return (obj);
}

function tab2json_obj(tab) {
    var json = [];
    tab = tab.replace(/  +/g, ' ');
    tab = tab.replace(/\t/g, ' ');
    var lines = tab.split(/\n/);
    var colnames = [];
    var colmodel = [];
    if (lines[0].match(/TABLE NO\./)) {
        lines.shift();
    }
    for (var i = 0; i < lines.length; i++) {
        var tmp = lines[i];
        tmp = tmp.replace(/^ +/g, '');
        var vals = tmp.split(/ /);
        if (i == 0) {
            colnames = vals;
            var colwidth = Math.round(700 / vals.length);
            if(colwidth < 50) {
              colwidth = 50;
            }
            for (j = 0; j < vals.length; j++) {
                colmodel.push({
                    name: colnames[j],
                    index: colnames[j],
                    width: colwidth.toString(),
                    align: 'right'
                })
            }
        } else {
            var json_tmp = _.object(colnames.slice(0, vals.length), vals);
            for (k in json_tmp) {
                json_tmp[k] = Number(json_tmp[k]);
            }
            json.push(json_tmp);
        }
    }
    //    console.log(json);
    var obj = {
        json: json,
        colnames: colnames,
        colmodel: colmodel
    }
    return (obj);
}

function show_intermed_est(id) {
    // make plot of intermediate estimates or gradients
    if (id !== undefined) {
        curr_est = inter_db[(id - 1)];
    }
    if (curr_est !== undefined) {
        if (curr_est.theta.length > 0) {
            var th = curr_est.theta[(curr_est.theta.length) - 1];
            var om = [];
            var si = [];
            var om_mat = curr_est.omega[(curr_est.omega.length) - 1];
            var si_mat = curr_est.sigma[(curr_est.sigma.length) - 1];
            for (var i = 0; i < om_mat.length; ++i) {
                om.push(om_mat[i][i]);
            }
            for (var i = 0; i < si_mat.length; ++i) {
                si.push(si_mat[i][i]);
            }
            all = [];
            for (var i = 0; i < Math.max(th.length, om.length, si.length); ++i) {
                var tmp = {
                    parno: (i + 1)
                };
                if (i < th.length) {
                    tmp.theta = th[i];
                }
                if (i < om.length) {
                    tmp.omega = om[i];
                }
                if (i < si.length) {
                    tmp.sigma = si[i];
                }
                all.push(tmp);
            }
            populate_list_with_data("#intermediate_est_table", all);
            show_intermed_est_plot();
        }
    }
}

function show_intermed_est_plot() {
    var dat = curr_est;
    var data_obj = parse_inter_data_for_plot(dat);
    console.log(dat);
    var data_parsed = data_obj.data;
    console.log(data_parsed);
    nv.addGraph(function() {
        var chart = nv.models.lineChart()
            .margin({
            left: 75,
            right: 25
        })
            .useInteractiveGuideline(true)
            .transitionDuration(350)
            .showLegend(true)
            .showYAxis(true)
            .showXAxis(true)
        //.forceY([1, data_obj.maxy])
        .showLegend(false)
            .width(340)
            .height(250)
        //    .yScale(d3.scale.log())
        ;
        chart.xAxis.axisLabel('Iteration');
        chart.yAxis.axisLabel('Parameter value');

        d3.select('#inter_plot svg')
            .datum(data_parsed)
            .call(chart);

        nv.utils.windowResize(function() {
            chart.update()
        });
        return chart;
    });
}

function parse_inter_data_for_plot(dat) {
    var th_all = [];
    var om_all = [];
    var si_all = [];
    var data = [];
    var th_tmp = dat.theta;
    var om_tmp = dat.omega;
    var si_tmp = dat.sigma;
    var maxy = 0;
    var th_all = [];
    //    var convert = [th_tmp, om_tmp, si_tmp];
    console.log(dat.iterations);
    console.log(th_tmp);
    console.log(dat.gradients);
    var th_dat = convert_inter_format(th_tmp, dat.iterations, false);
    var om_dat = convert_inter_format(om_tmp, dat.iterations, true);
    var si_dat = convert_inter_format(si_tmp, dat.iterations, true);
    var gradients_dat = convert_inter_format(dat.gradients, dat.iterations, false);
    show_gradients = false;
    if (show_gradients === false) {
        for (var i = 0; i < th_dat.length; ++i) {
            data.push({
                key: "th" + (i + 1),
                values: th_dat[i]
            })
        }
        for (var i = 0; i < om_dat.length; ++i) {
            data.push({
                key: "om" + (i + 1),
                values: om_dat[i]
            })
        }
        for (var i = 0; i < si_dat.length; ++i) {
            data.push({
                key: "si" + (i + 1),
                values: si_dat[i]
            })
        }
    } else {
        for (var i = 0; i < 3; ++i) {
            data.push({
                key: "gradient" + (i + 1),
                color: "#51A351",
                values: gradients_dat[i]
            })
        }
    }
    var data_obj = {
        data: data,
        maxy: maxy
    }
    return (data_obj);
}

// function convert_gradients_format (tmp) {
//     var tmp_dat = [];
//     for (var i = 0; i < tmp.length; ++i) { // loop over iterations
//     }
// }

function convert_inter_format(tmp, iterations, diag) {
    var tmp_dat = [];
    for (var i = 0; i < tmp.length; ++i) { // loop over iterations
        for (var j = 0; j < tmp[i].length; ++j) { //  loop over thetas
            if (i == 0) {
                tmp_dat[j] = new Array(tmp.length);
            }
            var y = Number(tmp[i][j]);
            if (diag) {
                y = Number(tmp[i][j][j]);
            }
            tmp_dat[j][i] = {
                x: Number(iterations[i]),
                y: y
            };
            //	    if (tmp[i][j] > maxy) { maxy = Number(tmp[i][j]) }
        }
    }
    return (tmp_dat);
}

function up_one_dir(dir) {
    var spl = dir.split('/');
    spl.pop();
    return (spl.join('/'));
}

function dbl_click(id) {
    var matched = false;
    if (id) {
        if (id == '..') {
            cwd_input.value = up_one_dir(cwd_input.value);
            refresh_pirana(cwd_input.value);
            matched = true;
        }
        if (id.match(/^\//)) {
            cwd_input.value += id;
            refresh_pirana(cwd_input.value);
            matched = true;
        }
    }
    if (!matched) {
        status("Opening model in editor");
        $.post('/api/code_editor', {
            folder: document.getElementById('cwd_input').value,
            file: id + '.mod'
        }, function(msg) {
          code_editor(msg);
          status("");
        });
    }
}

function folder_keypress(inField, e) {
    var charCode;
    if (e && e.which) {
        charCode = e.which;
    } else if (window.event) {
        e = window.event;
        charCode = e.keyCode;
    }
    if (charCode == 13) {
        refresh_pirana(document.getElementById('cwd_input').value);
    }
}

function login(user_id, pw) {
    $('#project_selector').select2('enable');
    // $('#project_selector').select2('data', null);
    $.post('/api/login', {
      cmd: "login",
      user_id: user_id,
      pw: pw
    }, function(data) {
      if(!data.authenticated) {
        $("#login_progress_dialog" ).dialog("close");
        play_sound("wrong");
        // $("#message_dialog").html("Wrong username or password. Please try again.").dialog("open");
        // popup_msg("error", "Wrong login credentials.");
        // logout();
        $("#user_login_form").dialog("open");
      } else {
        logged_in = true;
        inc_login_progress("login_prg_server", 1);
        login_progress = 0;
        $("#progressbar").progressbar({ value: login_progress });
        $("#login_name").html("<i class='fa fa-user'></i> &nbsp; " + data.user_id);

        $.post('/api/get_psn_nm_versions', {}, function(msg) {
          var psn_nm_versions = try_parse_json(msg.output);
          if (psn_nm_versions) {
            var keys = Object.keys(psn_nm_versions).sort();
            var option_string;
            Object.keys(psn_nm_versions).forEach(function (key) {
              if (key !== undefined) {
                var sel_flag = '';
                if (key == 'default') {
                  sel_flag = "selected";
                }
                option_string += "<option value='" + key+"' "+sel_flag+">" + key + "</option>";
              }
            });
            $("select[name='psn_nm_selector']").find('option').remove().end().append(option_string);
            $("select[name='psn_nm_selector']").select2("val", "default");
          }
        });

        $.post('/api/get_mpi_settings', {}, function(data) {
          mpi = data.mpi;
          if(mpi) {
            var keys = Object.keys(mpi.presets).sort();
            var option_string = "<option value='no' selected>Don't use MPI</option>";
            Object.keys(mpi.presets).forEach(function (key) {
              if (key !== undefined) {
                option_string += "<option value='" + key+"'>" + key + "</option>";
              }
            });
            $("select[name='mpi_selector']").find('option').remove().end().append(option_string);
            $("select[name='mpi_selector']").select2("val", "no");
          }
        });

        $.post('/api/get_sge_settings', {}, function(data) {
          sge = data.sge;
        });

        $.post('/api/psn_tool_default_args', {}, function(msg) {
          inc_login_progress("login_prg_psn");
          psn_tool_default_args = try_parse_json(msg.output);
          if (!psn_tool_default_args) {
            psn_tool_default_args = {};
          }
        });

        $.post('/api/get_templates', {}, function(msg) {
          inc_login_progress("login_prg_templates");
          var outp = try_parse_json(msg.output);
          if (outp) {
            var model_templates = {};
            if (outp.rows !== undefined) {
              for (i = 0; i < outp.rows.length; i++) {
                model_templates[outp.rows[i].run] = outp.rows[i].descr;
              }
              populate_model_templates(model_templates);
            }
          } else {
            console.log("No templates found!");
          }
        });

        $.post('/api/get_license_status', {}, function(msg) {
          if (msg.license_info === undefined || msg.license_info.license_valid_code === undefined || msg.license_info.license_valid_code === 0) {
            license_valid = 0;
            $("#license_info").html("<b class='error'>UNLICENSED USE OR LICENSE INVALID!</b>");
          } else {
            license_valid = 1;
            if (msg.license_info.client === 'academic') {
              $("#license_holder").html("Licensed to academic user ("+msg.license_info.license_valid+")");
            } else {
              $("#license_holder").html("Licensed to "+msg.license_info.client+ " ("+msg.license_info.license_valid+")");
            }
          }
          $.post('/api/get_home_folder', {}, function(msg) {
            var cwd = chomp(msg.folder);
            if (cwd && cwd.match(/no passwd entry/i)) {
              $("#login_progress_dialog" ).dialog("close");
              play_sound("wrong");
              logout();
              $("#user_login_form").dialog("open");
            } else {
              inc_login_progress("login_prg_folder");
              play_sound("login");
              home_folder = cwd;
              refresh_projects(cwd);
            }
          });
        });
      }
      }
    );
    $("#logout_link").html("<a href='#' title='Logout' class='login_button' onclick='logout(); return false;'><i class='fa fa-plug'></i>&nbsp; Log out</a>");
}

var timer1, timer2;
document.onkeypress = resetTimer;
document.onmousemove = resetTimer;

function resetTimer() {
    clearTimeout(timer1);
    var wait = 10; // minutes
    if (logged_in) {
        timer1 = setTimeout(alert_logout, (60000 * wait));
    }
}

function alert_logout() {
    logout_message = "<p class='grey'>Sorry, we logged you out since your session was idle for more than 10 minutes.</p>";
    logout();
}

function logout() {
    $("#login_name").html("Not logged in");
    $.post('/api/logout', {}, function(data) {
      if(term) {
        term.destroy();
      }
      show_console = false;
      login_dat = "";
      logged_in = false;
      var progress = ["login_prg_psn", "login_prg_folder", "login_prg_server", "login_prg_project", "login_prg_templates"];
      for(var i = 0; i < progress.length; i++) {
        $("#" + progress[i]).removeClass('login_prg_done');
      }
      $('#project_selector').select2('disable');
      $('#project_selector').select2('data', null);
      $("#cwd_input").val("");
      $("#logout_link").html("<a href='#' id='login_link' class='login_button' onclick='$(\"#user_login_form\").dialog(\"open\");'>Login</a>");
      $("#user_login_form").dialog("open")
      if ($.cookie('username') !== '') {
          $("#name").val($.cookie('username'));
          $("#password").focus();
      } else {
          $("#name").focus();
      }
    });
}

function zip_folder() {
    $.post('/api/download_folder', {
        folder: $('#cwd_input').val()
    }, function(msg) {
      window.open('/tmp/'+msg.input_obj.filename,'_self');
      $("#message_dialog").html("").dialog("close");
      status();
    });
    $("#message_dialog").html("<p>Your download is being prepared, download will start automatically when it is ready.</p>").dialog("open");
}

function create_run_record() {
    $.post('/api/create_run_record', {
        folder: $('#cwd_input').val()
    }, function(msg) {
      $.post('/api/open_file_in_spreadsheet', {
        "file": msg.input_obj.filename,
        "folder": $("#cwd_input").val()
      }, function(msg) {
        open_file_in_spreadsheet(msg);
      });
    });
}

function open_file_in_spreadsheet (msg) {
  var tmp;
  flag = false;
  if (msg.file.match(/\.csv$/)) {
    tmp = csv2json_obj(msg.output);
    flag = true;
  }
  if (msg.file.match(/tab/) && !flag) {
    tmp = tab2json_obj(msg.output);
    flag = true;
  }
  $('#spreadsheet').jqGrid('GridUnload');
  load_spreadsheet_grid(tmp.colnames, tmp.colmodel);
  show_in_spreadsheet(tmp.json, msg.file);
  $("#spreadsheet_window").dialog("option", "width", 720);
  $("#spreadsheet_window").dialog("option", "height", 560);
  $("#spreadsheet").jqGrid('setGridHeight', 450 );
  $("#spreadsheet").jqGrid('setGridWidth', 700 );
  status("");
}

function hide_runs() {
    var mods = $("#main").getGridParam('selarrrow');
    if (mods[0] == undefined) {
        $("#message_dialog").html("Please select a run.").dialog("open");
        return;
    }
    $.post('/api/hide_runs', {
        folder: $('#cwd_input').val(),
        runs: mods
    }, function(msg) {
      status('');
    });
    // refresh interface
    var new_model_data = new Array();
    for (var i = 0; i < main_model_data.length; i++) {
        if (!(_.contains(mods, main_model_data[i].run))) {
            new_model_data.push(main_model_data[i]);
        }
    }
    main_model_data = new_model_data;
    $("#main").jqGrid('clearGridData');
    $("#main").jqGrid('setGridParam', {
        data: main_model_data
    });
    $("#main").trigger("reloadGrid");
}

function niy() {
    $("#message_dialog").html("Sorry, not implemented yet...").dialog("open");
}

function unhide_all_runs() {
    $.post('/api/unhide_all_runs', {
        folder: document.getElementById('cwd_input').value
    }, function(msg) {
      var cwd = chomp(msg.folder);
      refresh_pirana(cwd);
    })
}

function send_message() {
    var to_user = $("#chat_user_selector").val();
    var text = $("#chat_message_area").val();
    $.post('/api/message', {
        text: text,
        to_user: to_user
    })
    $("#chat_message_area").val("");
}

function open_data_inspector() {
    var mods = $("#main").getGridParam('selarrrow');
    if (mods[0] == undefined) {
        $("#message_dialog").html("Please select a run.").dialog("open");
        return;
    }
    $.post('/api/get_data_info', {
        folder: document.getElementById('cwd_input').value,
        file: mods[0] + '.mod'
    }, function(msg) {
      if (msg.output !== undefined) {
        var data_info = try_parse_json(msg.output);
        if (data_info) {
          update_data_inspector(data_info, 0);
        } else {
          // console.log(msg.output);
        }
      }
      status("");
    });
    $('#data_inspector').dialog('open');
    $('#data_inspector_plot').focus();
}

function update_data_inspector(data_info, dataset_chosen) {
    if (data_info == undefined) {
        data_info = window.data_info;
    }
    if (dataset_chosen == undefined) {
        dataset_chosen = 0;
    }
    window.data_info = data_info; // set to global
    var headers = data_info[dataset_chosen].headers.split(',');
    var html = "";
    var dataset_string = "";
    for (var i = 0; i < data_info.length; i++) {
        dataset_string += "<option value='" + (i + 0) + "' ";
        if (i == dataset_chosen) {
            dataset_string += "selected";
        }
        dataset_string += ">" + data_info[i].name + "</option>";
    }
    $("select[name='dataset_selector']").find('option').remove().end().append($(dataset_string));
    //  $("#data_inspector_dataset").html(data_info[0].name);
    var option_string = "<option value='none'>none</option>";
    var id_found = false;
    for (var i = 0; i < headers.length; i++) {
        html += '<li class="ui-widget-content">' + headers[i] + '</li>';
        if(headers[i] === "ID" || headers[i] === "id") {
          id_found = headers[i];
        }
        option_string += "<option value='" + headers[i] + "'>" + headers[i] + "</option>";
    }
    $("#data_x_sel").html(html);
    $("#data_y_sel").html(html);
    $("select[name='facet_selector1']").find('option').remove().end().append($(option_string));
    $("select[name='facet_selector2']").find('option').remove().end().append($(option_string));
    $("select[name='colour_selector']").find('option').remove().end().append($(option_string));
    $("select[name='group_selector']").find('option').remove().end().append($(option_string));
    if(id_found) {
      $("#group_selector").val(id_found);
    }
}

function data_insp_set_label(axis) {
  $("#plot_label_type").html("Plot label " + axis + ": &nbsp;");
  $("#plot_label_dialog").dialog('open');
}

function update_data_inspector_plot(change_input) {
    var xlab = $('#data_x_sel li').eq(datainspector_x_selected).html();
    var ylab = $('#data_x_sel li').eq(datainspector_y_selected).html();
    if(change_input) {
      $("#data_insp_x_label_btn").html(xlab);
      $("#data_insp_y_label_btn").html(ylab);
    } else {
      xlab = $("#data_insp_x_label_btn").html();
      ylab = $("#data_insp_y_label_btn").html();
    }
    if (datainspector_x_selected !== undefined && datainspector_y_selected !== undefined) {
        $("#data_inspector_plot").html('<center>Loading new plot...</center>');
        var input = {
            cmd: 'update_data_inspector_plot',
            folder: document.getElementById('cwd_input').value,
            data: $('#dataset_selector').find('option:selected').html(),
            x_sel: $('#data_x_sel li').eq(datainspector_x_selected).html(),
            y_sel: $('#data_y_sel li').eq(datainspector_y_selected).html(),
            x_lab: xlab,
            y_lab: ylab,
            facet1: $('#facet_selector1').find('option:selected').val(),
            facet2: $('#facet_selector2').find('option:selected').val(),
            point: $('#point_selector').is(':checked'),
            line: $('#line_selector').is(':checked'),
            unity: $('#unity_selector').is(':checked'),
            smooth: $('#smooth_selector').find('option:selected').val(),
            group: $('#group_selector').find('option:selected').val(),
            colour: $('#colour_selector').find('option:selected').val(),
            axes: $('#axes_selector').find('option:selected').val(),
            x_range: $('#data_inspector_x_slider').slider("option", "values"),
            y_range: $('#data_inspector_y_slider').slider("option", "values"),
        };
        $.post('/api/update_data_inspector_plot', input, function(msg) {
          download_png = "";
          if(msg.error) {
            $("#message_dialog_large").html("<p>Oops... something went wrong running R: </p><pre>"+msg.output+"</pre>").dialog("open");
          } else {
            $("#data_inspector_plot").html('<embed width="480" height="400" src="tmp/'+msg.input_obj.outfile+'" type="image/svg+xml" />');
            download_png = msg.input_obj.outfile.replace(/.svg/, ".png");
            $("#download_png_link").attr('href', window.location.origin + "/tmp/" + download_png);
            $("#download_svg_link").attr('href', window.location.origin + "/tmp/" + msg.input_obj.outfile);
          }
          status("");
        });
        // get the R code
        input2 = input;
        $.post('/api/data_inspector_r_code', input2, function(msg) {
          data_inspector_r_code = msg.code;
        });
    }
}

function update_psn_nm_version(v) {
    var spl = $("#psn_execute_dialog_command").val().match(/[^\s"']+|"([^"]*)"|'([^']*)'/g);
    for(var i=0; i < spl.length; i++) {
      if (spl[i].match(/^\'/g)) {
        spl[i-1] = spl[i-1] + spl[i];
        spl.splice(i, 1);
      }
    }
    var cmd = spl.shift();
    var flag = 0;
    var args = [];
    var mods = [];
    for (var i = 0; i < spl.length; i++) {
        if (spl[i] !== undefined && spl[i] != "") {
            if (spl[i].match(/^-/)) {
                if (!spl[i].match("nm_version")) {
                    args.push(spl[i]);
                }
            } else { // a model
                mods.push(spl[i]);
            }
        }
    }
    if (flag == 0) {
        args.push("-nm_version=" + v);
    }
    cmdline = cmd + " " + args.join(" ") + " " + mods.join(" ");
    $("#psn_execute_dialog_command").val(cmdline);
}

function update_psn_command(psn_help_dat, e, value) {
    if (e.added !== undefined) {
        var q = _.findWhere(psn_help_dat, {
            id: e.added.id
        });
        if (q.syntax !== "" && value === undefined) {
            ask_for_psn_argument(e.added.id, q.syntax, q.help, psn_help_dat, e);
        } else {
            update_psn_command_function(psn_help_dat, e, q.id, value);
        }
    }
    if (e.removed !== undefined) {
        remove_psn_argument(e.removed.id);
    }
}

function ask_for_psn_argument(arg, syntax, help, psn_help_dat, e) {
    $("#psn_arg_details_dialog").dialog("moveToTop");
    $("#argument_detail_info").html();
    $("#argument_detail_info").html("<p>" + help + "</p>");
    $("#arg_detail_value").val("");
    $("#psn_arg_details_dialog").dialog("option", "height", (175 + Math.floor(help.length / 4)));
    $("#psn_arg_details_dialog").dialog("option", "buttons", {
        "Update": function() {
            var value = $("#arg_detail_value").val();
            $("#psn_arg_details_dialog").dialog('close');
            update_psn_command_function(psn_help_dat, e, e.added.id, value);
        }
    });
    $("#psn_arg_details_dialog").dialog("open");
    // $("#arg_detail_help").text(help);
    $("#arg_detail_value").focus();
    $("#arg_detail_syntax").text("(" + syntax + ")");
}

function add_psn_argument(arg) {
    var cmd = $("#psn_execute_dialog_command").val();
    var re = new RegExp(arg + ".*?", "g");
    if(!cmd.match(re)) {
      var spl = cmd.split(/ /);
      var tool = spl.shift();
      cmd = tool + " "+arg+" " + spl.join(" ");
    }
    $("#psn_execute_dialog_command").val(cmd);
}

function remove_psn_argument(arg) {
  var cmd = $("#psn_execute_dialog_command").val();
  var re1 = new RegExp("-" + arg + "(\='+.*?'+)", "g");
  cmd = cmd.replace(re1, "");
  var re2 = new RegExp("-" + arg + "(\=.*?)* ", "g");
  cmd = cmd.replace(re2, " ");
  var re3 = new RegExp("( )+", "g");
  cmd = cmd.replace(re3, " ");
  $("#psn_execute_dialog_command").val(cmd);
}

function update_psn_command_function(psn_help_dat, e, arg, value) {
    var cmd = $("#psn_execute_dialog_command").val();
    var spl = cmd.split(" ");
    var psn_cmd = spl.shift();
    var psn_runs = _.filter(spl, function(str) {
        return str.match(/\.mod/);
    });
    var psn_args = [];
    for (i = 0; i < spl.length; ++i) {
        if (!spl[i].match(/\.mod/)) {
            if (spl[i].match(/=/)) {
                var tmp = spl[i].split("=");
                if (tmp[0] == "-" + arg) {
                    tmp[1] = value;
                    arg = "";
                }
                if (tmp[1] === undefined) {
                    psn_args.push(tmp[0]);
                } else {
                    psn_args.push(tmp[0] + '=' + tmp[1]);
                }
            } else {
                if (spl[i] === "-" + arg) {
                    arg = "";
                }
                psn_args.push(spl[i]);
            }
        }
    }
    cmd = psn_cmd + " " + psn_args.join(" ");
    if (arg !== "") {
        if (value === undefined) {
            cmd = cmd + " -" + arg;
        } else {
            cmd = cmd + " -" + arg + "=" + value;
        }
    }
    cmd = cmd + " " + psn_runs.join(" ");
    cmd = cmd.replace(/  /, " ");
    $("#psn_execute_dialog_command").val(cmd);
}

function psn_help(command, type) {
  var msg = {
    "title": "psn_help",
    "mode": "text",
    "output": "\nLoading help...\n"
  };
  code_editor(msg, {x: ($( window ).width() - 310), y: 10, hide_save_buttons: true });
  $.post('/api/psn_help', {
      cmd: 'psn_help',
      command: command,
      type: type
  }, function(msg) {
      if(!msg.error) {
        code_editor(msg, {x: ($( window ).width() - 310), y: 10, hide_save_buttons: true });
        status("");
      } else {
        console.log(msg.error);
      }
  });
  return false;
}

function nm_help(key) {
    $.post('/api/nm_help_topic', {
        cmd: 'nm_help_topic',
        key: key
    }, function(msg) {
        var tmp = try_parse_json(msg.output);
        if (tmp) {
          var key = Object.keys(tmp);
          $("#nm_help_box").html(tmp[key.shift()]).scrollTop(0);
        }
        status("");
    });
    return false;
}

function open_vrr_window() {
    $.post('/api/create_vrr', {
        cmd: 'create_vrr',
        folder: $('#cwd_input').val()
    }, function(msg) {
      var json = try_parse_json(msg.output);
      if (json) {
        refresh_vrr(json);
      }
      $('#vrr').dialog('open');
      $('#vrr').focus();
      status("");
    });
}

function show_chat_window() {
    $("#chat_window").dialog("open");
}

function build_tex_pdf(tex_file) {
    if (tex_file === undefined) {
        tex_file = current_editor_file;
    }
    $.post('/api/build_tex_pdf', {
        cmd: 'build_tex_pdf',
        folder: $('#cwd_input').val(),
        tex_file: tex_file
    }, function(msg) {
        var file = msg.input_obj.tex_file.replace(/\.tex/, ".pdf");
        $.post('/api/server_file_viewer', {
          cmd: 'server_file_viewer',
          format: "pdf",
          folder: $('#cwd_input').val(),
          file: file
        }, function(msg) {
          server_file_viewer(msg);
        });
    });
}

function toggle_open_console() {
    show_console = 1 - show_console;
    if (show_console == 1) {
        $('#node_output_dialog').dialog('open');
    } else {
        $('#node_output_dialog').dialog('close');
    }
}

function code_editor(msg, layout) {
    var str;
    if (msg.output !== undefined) {
        var str = msg.output;
    } else {
        if (typeof(msg) == 'string') {
            str = msg;
        }
    }
    editor_active = 1;
    current_editor_file = msg.file;
    if (current_editor_file !== undefined && current_editor_file.match(/\.mod/)) {
        $("#button_duplicate").show();
        $("#button_diff").show();
        $("#button_info").show();
        $("#button_execute").show();
        $("#button_build").hide();
    } else {
        $("#button_duplicate").hide();
        $("#button_diff").hide();
        $("#button_info").hide();
        $("#button_execute").hide();
        if (current_editor_file !== undefined && current_editor_file.match(/\.tex/i)) {
            $("#button_build").show();
        } else {
            $("#button_build").hide();
        }
    }
    $("#button_save").show();
    $("#button_saveas").show();
    if (layout !== undefined) {
        if (layout.hide_save_buttons !== undefined && layout.hide_save_buttons == true) {
            $("#button_save").hide();
            $("#button_save_as").hide();
        }
        if (layout.title !== undefined) {
            $('#code_editor').dialog('option', 'title', layout.title);
        }
        if (layout.x !== undefined) {
            $('#code_editor').dialog('option', 'position', [layout.x, layout.y]);
        }
    }
    if (str !== undefined) {
        editor.setValue(str, -1);
        doc_height = $(window).height() * 0.8 + 8;
        $('#code_editor').dialog('option', 'width', $('#editor').width() + 4);
        $('#code_editor').dialog('option', 'height', doc_height);
        if (msg.mode !== undefined) {
            editor.getSession().setMode("ace/mode/" + msg.mode);
        } else { // decide based on file extension
            var mode = undefined;
            ext = get_file_extension(msg.file);
            if (ext.toLowerCase() == "r") {
                mode = "r";
            }
            if (ext.toLowerCase() == "tex") {
                mode = "latex";
            }
            if (ext.toLowerCase() == "mod" || ext.toLowerCase() == "lst") {
                mode = "nonmem";
            }
            if (mode === undefined) {
                mode = "text";
            }
            editor.getSession().setMode("ace/mode/" + mode);
        }
        $('#code_editor').dialog('option', 'title', msg.file);
        $('#code_editor').dialog('open');
        $("#main").blur();
    }
}

function edit_file(file_id) {
    if (file_id == undefined) {
        file_id = $("#list_files").jqGrid('getGridParam', 'selrow');
    }
    $.post('/api/code_editor', {
        cmd: 'code_editor',
        folder: $('#cwd_input').val(),
        file: current_editor_file,
        mode: "txt"
    }, function(msg) {
        code_editor(msg);
        status("");
    });
    return false;
}

function editor_save_action(edtr, file) {
    if (edtr === undefined) {
        edtr = editor;
    }
    if (file === undefined || file == "") {
        file = current_editor_file;
    }
    var text = edtr.getValue();
    $.post('/api/editor_save', {
        cmd: "editor_save",
        text: text,
        file: file,
        folder: $('#cwd_input').val()
    }, function(msg) {

    });
    return false;
}

function notes_editor_save_action() {
    editor_save_action (notes_editor, $('#cwd_input').val()+"/pirana.md");
}

function editor_save_as_action() {
    var new_file = prompt("New file name", current_editor_file);
    var folder = $('#cwd_input').val();
    var text = editor.getValue();
    if (new_file != null) {
        if (new_file.length > 0) {
            $.post('/api/editor_save', {
                cmd: "editor_save",
                text: text,
                file: new_file,
                folder: folder
            }, function(msg) {
              // do nothing?
            })
            current_editor_file = new_file;
            $('#code_editor').dialog('option', 'title', new_file);
            refresh_pirana(folder);
        }
    }
}

function open_diff_from_editor(file1, file2) {
    var folder = get_folder_name(file1);
    console.log(folder);
    var file1_no = get_file_name(file1.replace(/\.mod/, ''));
    var ref_obj = _.findWhere(main_model_data, {
        run: file1_no
    });
    console.log(ref_obj);
    if (file2 === undefined) {
        if (ref_obj !== undefined && ref_obj.refmod !== undefined) {
            file2 = ref_obj.refmod.toString() + ".mod";
        }
    }
    if(file1 && file2) {
      status("Requesting diff...");
      $.post('/api/diff', {
          cmd: "diff",
          file_new: get_file_name(file1),
          file_old: get_file_name(file2),
          folder: $("#cwd_input").val()
      }, function(msg) {
          open_diff_window(msg.output);
          status("");
      });
    } else {
      $("#message_dialog_large").html("Either two models need to be selected, or a reference model should be specified to perform a diff!").dialog("open");
      console.log(file1);
      console.log(file2);
    }
}

function open_diff_window(diff_html) {
    $("#diff_window_content").val();
    $("#diff_window_content").html("<pre class='diff'>" + diff_html + "</pre>");
    $("#diff_window").dialog("open");
}

function edit_script(script_id) {
    if (script_id == undefined) {
        script_id = $("#list_r").jqGrid('getGridParam', 'selrow');
    }
    var script;
    if (script_id !== undefined) {
        if (script_list_data[script_id - 1] !== undefined) {
            script = script_list_data[script_id - 1].base_dir + "/" + script_list_data[script_id - 1].full;
            if (!script.match(/.R$/i)) {
                $("#message_dialog").html("Please select an R-script from the list.").dialog("open");
                return;
            }
        }
    }
    if (script !== undefined && script.match(".R")) {
        $.post('/api/code_editor', {
            cmd: 'code_editor',
            //            folder: "#pirana_script",
            file: script,
            mode: "r"
        }, function(msg) {
            code_editor(msg);
            status("");
        });
    } else {
        $("#message_dialog").html("Please select an R-script from the list.").dialog("open");
        return;
    }
}

function copy_script(script_id) {
    if (script_id == undefined) {
        script_id = $("#list_r").jqGrid('getGridParam', 'selrow');
    }
    var script;
    if (script_id !== undefined) {
        if (script_list_data[script_id - 1] !== undefined) {
            script = script_list_data[script_id - 1].full;
            if (!script.match(/.R$/i)) {
                $("#message_dialog").html("Please select an R-script from the list.").dialog("open");
                return;
            }
            script_sel = script_list_data[script_id - 1].base_dir + "/" + script;
        }
    }
    //    console.log(script_sel);
    if (script !== undefined && script.match(/.R$/i)) {
        var spl = script.split(/\//);
        var new_script = spl.pop();
        new_script = new_script.replace(/\.R$/i, "");
        new_script = new_script + "_copy.R";
        $("#script_copy_new_name").val(new_script);
        $("#copy_script_dialog").dialog("open");
        console.log(script_sel);
    } else {
        $("#message_dialog").html("Please select an R-script from the list.").dialog("open");
    }
}

function return_script_parent(id) {
    for (var i = 0; i < scripts.length; i++) {
        if (scripts[i].id == id) {
            recurs = return_script_parent(scripts[i].parent);
            if (recurs !== undefined && recurs !== "null") {
                return recurs + "/" + scripts[i].parent;
            } else {
                return scripts[i].parent;
            }
        }
    }
}

function status(stat) {
    if (stat == "" || stat == undefined) {
        stat = "idle";
    }
    $('#statusbar').val("Status: " + stat);
}

function run_r_script(id) {
    var r_script_id = id; // return_script_parent(id)+"/"+id;
    if (r_script_id == undefined) {
        r_script_id = $("#list_r").jqGrid('getGridParam', 'selrow');
    }
    var r_script = script_list_data[r_script_id - 1].full;
    var base_dir = script_list_data[r_script_id - 1].base_dir;
    if (!r_script.match(/.R$/i)) {
        $("#message_dialog").html("Please select an R-script from the list.").dialog("open");
        return;
    }
    //    console.log($("#list_r").find("tr:"+r_script));
    if (r_script == undefined) {
        $("#message_dialog").html("Please select an R-script from the list.").dialog("open");
        return;
    }
    var mods = $("#main").getGridParam('selarrrow');
    if (mods[0] == undefined) {
        $("#message_dialog").html("Please select a run.").dialog("open");
        return;
    } else {
        status("Running R script...");
        $.post('/api/run_r_script', {
            cmd: 'run_r_script',
            folder: $('#cwd_input').val(),
            file: r_script,
            base_dir: base_dir,
            mods: mods
        }, function(msg) {
          if(msg.error) {
            var str = msg.output;
            $('#node_output').val(str);
            $('#node_output_dialog').dialog('open');
          } else {
            $.post('/api/server_file_viewer', {
              format: msg.format,
              folder: $('#cwd_input').val(),
              file: msg.file_url
            }, function(msg) {
              server_file_viewer(msg);
            });
          }
          status("");
        });
    }
}

function open_report(id) {
    if (id === undefined) {
        id = $("#list_reports").jqGrid('getGridParam', 'selrow');
    }
    if (id === undefined) {
        return false;
    }
    var filename = report_list_data[id - 1].full;
    if (filename.match(/Summary/)) {
        filename = "pirana_sum_" + filename.replace(/Summary_/, "");
    }
    filename = filename.replace(/\//, "_")
        .replace(/\s/, "_")
        .replace(/\_html$/, ".html")
        .replace(/\_tex$/, ".tex")
        .replace(/\_docx$/, ".docx")
        .replace(/\_txt$/, ".txt")
        .replace(/\_pdf$/, ".pdf");
    if(filename.match(/\.docx/)) {
      $("#message_dialog").html("Sorry... The current version of PiranaJS does not yet support opening of Word documents.").dialog("open");
    } else {
      dbl_click_file("pirana_reports/" + filename, "", id);
    }
}

function dbl_click_file(id, type, run) {
    if (id !== '' && id !== undefined) {
        var ext_known = 0;
        if (id.match(/\.pdf/)) {
            $.post('/api/server_file_viewer', {
                cmd: 'server_file_viewer',
                format: "pdf",
                folder: $('#cwd_input').val(),
                file: id
            }, function(msg) {
                var url = msg.file_url;
                if (msg.format == "pdflatex" || msg.format == "pdf") {
                  url = "pdfobject/viewer.html?pdf=../../" + url;
                }
                var pdf= "<embed id='pdf_embed' width=640 height=640 src='"+"../../" + url + "'/>";
                $("#pdf_viewer").html(pdf);
                $("#pdf_viewer").dialog("option", "width", ($("#pdf_embed").width() + 14));
                $("#pdf_viewer").dialog("option", "height", ($("#pdf_embed").height() + 40));
                $("#pdf_viewer").dialog("open");
                status("");
            });
            ext_known = 1;
        }
        if ((type == undefined && id.match(/\.R$/i)) || type == "R") {
            run_r_script(id);
            ext_known = 1;
        }
        if (id.match(/\.html/)) {
            $.post('/api/open_run_report', {
                cmd: 'open_run_report',
                folder: $('#cwd_input').val(),
                outfile: id,
                run: run,
                file: run,
                format: 'html'
            }, function(msg) {
              open_run_report(msg);
            });
            ext_known = 1;
        }
        if (ext_known == 0) {
            status("Opening file in editor...");
            $.post('/api/code_editor', {
                folder: $('#cwd_input').val(),
                file: id
            }, function(msg) {
                code_editor(msg);
                status("");
            });
        }
    }
}

function delete_files(files) {
    if (files !== undefined) {
        status("Deleting files...");
        $.post('/api/rm', {
            cmd: 'rm',
            folder: $('#cwd_input').val(),
            del_all: document.getElementById('delete_dialog_all').checked,
            del_tab: document.getElementById('delete_dialog_tab').checked,
            files: files
        }, function(msg) {
          var cwd = chomp(msg.input_obj.folder);
          refresh_pirana(cwd);
          status("");
        });
    }
}

function translate_model_dialog() {
    var ids = $("#main").getGridParam('selarrrow');
    var mod = ids[0];
    if (mod != undefined) {
        $("#translate_model").val(ids[0]);
        $("#translate_model_dialog").dialog("open");
    } else {
        $("#message_dialog").html("Please select a model/run from the list!").dialog("open");
    }
}

function confirm(question, callback_function) {
    $("#confirm_dialog_question").html("<p>" + question + "</p>");
    $("#confirm_dialog").dialog("option", "buttons", {
        No: function() {
            $(this).dialog("close");
        },
        Yes: function() {
            callback_function();
            $(this).dialog("close");
        }
    });
    $("#confirm_dialog").dialog("open");
}

function colors_dialog() {
    var ids = $("#main").getGridParam('selarrrow');
    var mod = ids[0];
    if (mod != undefined) {
        $("#colors_dialog").dialog("open");
    } else {
        $("#message_dialog").html("Please select a model/run from the list!").dialog("open");
    }
}

function set_color(color) {
    var runs = $("#main").getGridParam('selarrrow');
    $.post('/api/set_color', {
        cmd: 'set_color',
        folder: document.getElementById('cwd_input').value,
        runs: runs,
        color: color
    }, function(){
      status('');
    });
    $("#colors_dialog").dialog("close");
    // refresh interface
    for (var i = 0; i < main_model_data.length; i++) {
        if (_.contains(runs, main_model_data[i].run)) {
            main_model_data[i].colors = color;
        }
    }
    $("#main").jqGrid('clearGridData');
    $("#main").jqGrid('setGridParam', {
        data: main_model_data
    });
    $("#main").trigger("reloadGrid");
}

function set_flag(flag) {
    var runs = $("#main").getGridParam('selarrrow');
    $.post('/api/set_flag', {
        cmd: 'set_flag',
        folder: document.getElementById('cwd_input').value,
        runs: runs,
        flag: flag
    }, function() {
      status('');
    });
    $("#colors_dialog").dialog("close");
    // refresh interface
    if (flag == 'key') {
        flag = 1
    };
    if (flag == 'green') {
        flag = 2
    };
    if (flag == 'red') {
        flag = 3
    };
    for (var i = 0; i < main_model_data.length; i++) {
        if (_.contains(runs, main_model_data[i].run)) {
            main_model_data[i].key_run = flag;
        }
    }
    $("#main").jqGrid('clearGridData');
    $("#main").jqGrid('setGridParam', {
        data: main_model_data
    });
    $("#main").trigger("reloadGrid");
}

function remove_flags(flag) {
    var runs = $("#main").getGridParam('selarrrow');
    $.post('/api/remove_flags', {
        cmd: 'remove_flags',
        runs: runs,
        folder: document.getElementById('cwd_input').value
    }, function() {
      status('');
    });
    $("#colors_dialog").dialog("close");
    // refresh interface
    for (var i = 0; i < main_model_data.length; i++) {
        if (_.contains(runs, main_model_data[i].run)) {
            main_model_data[i].key_run = "";
        }
    }
    $("#main").jqGrid('clearGridData');
    $("#main").jqGrid('setGridParam', {
        data: main_model_data
    });
    $("#main").trigger("reloadGrid");
}

function psn_get_arguments_for_tool(tool) {
    var tags = [];
    var data1_tmp;
    $.getJSON('psn/psn_' + tool + '.json', function(data1) {
      data1_tmp = data1;
      $.getJSON('psn/psn_psn_options.json', function(data2) {
          var data = data1_tmp; //.concat(data2);
          for (var i in data2) {
            var tmp = _.where(data, {syntax_full: data2[i].syntax_full });
            if(tmp.length == 0) {
              data.push(data2[i]);
            }
          }
          for (var i = 0; i < data.length; i++) {
              tags.push(data[i].id);
          }
          // select2 has to be recreated
          $("#psn_arg_td").html('<input name="psn_arg_selector" id="psn_arg_selector"></input>');
          $("#psn_arg_selector").select2({
              allowClear: true,
              width: 350,
              data: {
                  results: data,
                  text: 'id'
              },
              tags: tags,
              formatResult: psn_format_result,
              formatSelection: psn_format_selection,
              dropdownCssClass: "bigdrop"
          });
          $("#psn_arg_selector").on("change", function(e) {
              update_psn_command(data, {
                  val: e.val,
                  added: e.added,
                  removed: e.removed
              });
              setTimeout(function() {
                  $("#arg_detail_value").focus();
              }, 100); // workaround
          })
        });
    });
};

function toggle_run_on_grid () {
    if($("#run_on_grid").attr('checked')) {
      $("#run_on_grid").attr('checked', false);
      remove_psn_argument("run_on_sge");
      remove_psn_argument("sge_prepend_flags");
    } else {
      $("#run_on_grid").attr('checked', true);
      add_psn_argument("-run_on_sge");
      if(sge && sge.prepend_flags) {
        add_psn_argument("-sge_prepend_flags='"+sge.prepend_flags+"'");
      }
    }
};

function open_psn_dialog(command, model, cmd) {
    $.post('/api/psn_log', {
        cmd: "psn_log",
        filter: command,
        callback: "show_log"
    }, function(msg) {
      psn_log(msg);
    });
    var cmdline;
    if (cmd !== undefined && cmd !== "") {
        cmdline = cmd;
    } else {
        var ids = $("#main").getGridParam('selarrrow');
        var models = "";
        for (var i = 0; i < ids.length; i++) {
            if (!ids[i].match(/\.\./) && !ids[i].match(/\//)) {
                models += ids[i] + '.mod ';
            }
        }
        if (model !== undefined) { // e.g. when called from editor
            var tmp = model.split(/\//);
            models = tmp.pop();
        }
        if (models == undefined || models == "") {
            $("#message_dialog").html("First select a model!").dialog("open");
            return (false);
        }
        cmdline = command + " ";
        if (psn_tool_default_args[command] !== undefined) {
            cmdline += psn_tool_default_args[command];
        }
        cmdline += " " + models;
        cmdline = cmdline.replace(/\s\s/, ' ');
        cmdline = cmdline.replace(/\%num/g, ids[0]);
        cmdline = cmdline.replace(/\%mod/g, ids[0]);
    }
    $('#psn_execute_dialog_command').val(cmdline);
    $("#psn_arg_selector").select2({
        allowClear: true,
        width: 350,
        data: {},
    });
    psn_get_arguments_for_tool(command);
    $("#psn_dialog").dialog("open");
    $("#button_psn_tool_h_span").text(command + " -h");
    $("#button_psn_tool_help_span").text(command + " -help");
    $("#button_psn_tool_h").attr("onClick", "psn_help('" + command + "', 'h'); return false;");
    $("#button_psn_tool_help").attr("onClick", "psn_help('" + command + "', 'h'); return false;");
   // force update of mpi arguments
    var val = $("select[name='mpi_selector']").select2("val");
    $("select[name='mpi_selector']").select2("val", val);
    update_mpi_arguments(val);
    return false;
};

function open_psn_log() {
  populate_list_with_data("#psn_log_list", psn_history_log);
  $("#psn_log_dialog").dialog( "open" );
};

function psn_log (msg) {
    psn_history_log = [];
    var log = try_parse_json(msg.output);
    if (log) {
      psn_history_log = log;
    }
    // if(msg.input_obj.callback === 'repeat') {
    var cmd = psn_history_log[0];
    if(cmd && cmd.command) {
        var all = cmd.command.split(" ");
        var tool = all[0];
        var new_command = "";
        var mods = $("#main").getGridParam('selarrrow');
        for(var i = 0; i < all.length; i++) {
  	  if(all[i] == tool || all[i].match(/^\-/)) {
  	      new_command += all[i] + " ";
  	  }
        }
        for(var j = 0; j < mods.length; j++ ) {
  	  new_command += mods[j] + ".mod ";
        }
        if (cmd !== undefined) {
  	      $('#psn_execute_dialog_command').val(new_command);
      	  if(new_command.match("run_on_sge")) {
      	      $("#run_on_grid").attr('checked',true);
      	  } else {
      	      $("#run_on_grid").attr('checked',false);
      	  }
        }
        // force update of mpi arguments
        var val = $("select[name='mpi_selector']").select2("val");
        $("select[name='mpi_selector']").select2("val", val);
        update_mpi_arguments(val);
      }
      status("");
}

function repeat_last_psn_command() {
    $.post('/api/psn_log', {
        cmd: "psn_log",
        callback: "repeat"
    }, function(msg) {
      psn_log(msg);
    });
}

function show_video_player() {
    $("#video_player").dialog("open");
}

function show_selected_video(video) {
    jwplayer('player').setup({
        playlist: '//jwpsrv.com/feed/' + video + '.rss',
        width: '100%',
        aspectratio: '16:10'
    });
}

function open_model_info_dialog() {
    status("Getting model info...");
    var mods = $("#main").getGridParam('selarrrow');
    if (mods[0] == undefined || mods[0].match(/^\//)) {
        $("#message_dialog").html("Please select a run.").dialog("open");
        return;
    }
    var model = mods[0].replace(/\.mod/, '');
    var all_models = _.pluck(main_model_data, "run");
    var ref_obj = _.findWhere(main_model_data, {
        run: model
    });
    var option_string;
    var run;
    option_string += "<option value=''>No reference</option>";
    for (i = 0; i < all_models.length; i++) {
        run = all_models[i];
        if ((run !== undefined) && (!run.match(/\//)) && (run !== model) && run != "\.\.") {
            selected = "";
            if (run == ref_obj.refmod) {
                selected = " selected";
            }
            option_string += "<option value='" + run + "'" + selected + ">" + run + "</option>";
        }
    }
    $("#model_info_refmod").find('option').remove().end().append(option_string);
    $("#model_info_refmod").select2('val', [ref_obj.refmod]);
    $("#model_info_model").val(model);
    $("#model_info_model").prop('disabled', true);
    $("#model_info_author").val(ref_obj.author);
    $("#model_info_description").val(ref_obj.descr);
    $("#model_info_note").val(ref_obj.notes);
    $("#model_info_dialog").dialog("open");
    status("");
}

function open_delete_dialog() {
    var ids = $("#main").getGridParam('selarrrow');
    var data = [];
    for (var i = 0; i < ids.length; i++) {
        data.push({
            "file": ids[i]
        });
    }
    if (ids[0] != undefined) {
        // if (run.match(/^\//)) {
        //     $("#delete_dialog_all").prop('disabled', true);
        //     $("#delete_dialog_all").prop('checked', false);
        //     $("#delete_dialog_tab").prop('disabled', true);
        //     $("#delete_dialog_tab").prop('checked', false);
        // } else {
        //     $("#delete_dialog_all").prop('disabled', false);
        //     $("#delete_dialog_all").prop('checked', true);
        //     $("#delete_dialog_tab").prop('disabled', false);
        //     $("#delete_dialog_tab").prop('checked', true);
        // }
        if (ids[0] !== "..") {
            //            $('#delete_dialog_mod').val(run);
            $("#delete_dialog_list").jqGrid('clearGridData');
            $("#delete_dialog_list").jqGrid('setGridParam', {
                data: data
            });
            $("#delete_dialog_list").trigger("reloadGrid");
            $("#delete_dialog").dialog("open");
        }
    }
}

function sumo_command(cmd) {
    if (cmd == undefined) {
        cmd = "sumo"
    };
    var ids = $("#main").getGridParam('selarrrow');
    if (ids != undefined) {
        var cmdline = cmd + " ";
        for (var i = 0; i < ids.length; i++) {
            if (!ids[i].match(/\.\./) && !ids[i].match(/\//)) {
                cmdline += ids[i] + '.lst ';
            }
        }
        status("Running sumo...");
        show_console = 1;
        console_number++;
        $('#node_output_dialog').dialog('open');
        add_console_tab("sumo", console_number);
        sock({
            cmd: 'cmd',
            folder: document.getElementById('cwd_input').value,
            cmdline: cmdline.trim()
        })
    }
}

function duplicate_command() {
    var ids = $("#main").getGridParam('selarrrow');
    var mod = ids[0];
    if (mod != undefined) {
        $('#duplicate_dialog_orig_mod').val(mod);
        $('#duplicate_dialog_orig_mod').prop('disabled', true);
        $('#duplicate_dialog_new_mod').val(new_model_name(mod));
        $('#duplicate_dialog_new_mod').focus();
        $("#duplicate_dialog").dialog("open");
    }
}

function server_file_viewer(msg) {
    var url = msg.file_url;
    if (msg.format == "pdflatex" || msg.format == "pdf") {
      url = "pdfobject/viewer.html?pdf=../../" + url;
    }
    var pdf= "<embed id='pdf_embed' width=640 height=640 src='"+"../../" + url + "'/>";
    $("#pdf_viewer").html(pdf);
    $("#pdf_viewer").dialog("option", "width", ($("#pdf_embed").width() + 14));
    $("#pdf_viewer").dialog("option", "height", ($("#pdf_embed").height() + 40));
    $("#pdf_viewer").dialog("open");
    status("");
};

function open_run_report(msg) {
    if (msg.target_file !== undefined) {
      var url = msg.target_file.replace(/public\//,"");
      // console.log("Opening run report " + url);
      window.open(url, '_blank');
    }
    status("");
}

function run_report(rtype) {
    var ids = $("#main").getGridParam('selarrrow');
    var mod = ids[0];
    if (mod !== undefined && !mod.match(/^\//)) {
        status("Creating run report");
        $.post('/api/run_report', {
            cmd: 'run_report',
            format: rtype,
            folder: document.getElementById('cwd_input').value,
            file: mod
        }, function(msg) {
            // console.log(msg);
            // console.log("Attempting to open created run report...");
            if (msg.input_obj.format == "txt") {
              msg.mode = "txt";
              code_editor(msg);
            }
            if (msg.input_obj.format == "r_obj") {
              msg.mode = "r";
              console.log(msg);
              code_editor(msg);
            }
            if (msg.input_obj.format == "tex") {
              msg.mode = "tex";
              code_editor(msg);
            }
            if (msg.input_obj.format == 'pdflatex') {
              // console.log("Requesting file: "+msg.input_obj.outfile);
              $.post('/api/server_file_viewer', {
                cmd: 'server_file_viewer',
                format: msg.input_obj.format,
                folder: $('#cwd_input').val(),
                file: msg.input_obj.outfile
              }, function(msg) {
                server_file_viewer(msg);
              });
            }
            if (msg.input_obj.format == 'docx') {
              $.post('/api/open_run_report', {
                cmd: 'open_run_report',
                folder: $('#cwd_input').val(),
                outfile: msg.input_obj.outfile,
                file: msg.input_obj.file,
                format: msg.input_obj.format,
                output: msg.output
              }, function(msg) {
                open_run_report(msg);
              })
            }
            if (msg.input_obj.format == "html") {
              $.post('/api/open_run_report', {
                cmd: 'open_run_report',
                folder: $('#cwd_input').val(),
                outfile: msg.input_obj.outfile,
                file: msg.input_obj.file,
                format: msg.input_obj.format,
                output: msg.output
              }, function(msg) {
                open_run_report(msg);
              })
            }
        });
    } else {
        $("#message_dialog").html("Please select a model/run from the list!").dialog("open");
    }
}

function toggle_column_filters() {
    window.view_column_filters = 1 - window.view_column_filters;
    $("#main")[0].toggleToolbar();
}

function project_remove_dialog() {
    var bool = confirm("Are you sure you want to remove this project?\n(Removing a project will not delete the folder.)",       function() {
        var s = document.getElementById('project_selector');
        //console.log(s.options[s.selectedIndex].text);
        status("Removing project");
        $.post('/api/project_remove', {
            cmd: "project_remove",
            folder: document.getElementById('cwd_input').value,
            project: s.options[s.selectedIndex].text,
            home: home_folder
        }, function(msg) {
          refresh_projects(cwd);
          status("");
        });
      }
    );
}

function project_add_dialog() {
    $("#project_add_dialog").dialog("open");
    var folder = $('#cwd_input').val();
    var spl = folder.split(/\//);
    var proj = spl.pop();
    $('#project_add_name').val(proj);
}

function new_folder_dialog() {
    $("#new_folder_dialog").dialog("open");
}

function new_model_dialog() {
    $("#new_model_dialog").dialog("open");
}

function select_row_action(id) {
    if (window.sel == 2) {
        reload_run_estimates(id);
    }
    $("#folder_nmtran_error").html("");
    $("#folder_psn_cmd").html("");
    main_scroll_pos = $("#main").closest(".ui-jqgrid-bdiv").scrollTop();
    $("#folder_nmtran_error").dialog("close");
    $("#folder_psn_cmd").dialog("close");
    $("#main").closest(".ui-jqgrid-bdiv").scrollTop(main_scroll_pos);
    if (id.match(/^.*?_dir/) || (id.match(/^\//) && id.match(/(vpc|bootstrap|scm)/i))) {
        info_psn_cmd = 0;
        info_nmtran_error = 0;
        $.post('/api/get_folder_info', {
            cmd: "get_folder_info",
            folder: $('#cwd_input').val(),
            subfolder: id
        }, function(msg) {
          if (msg.output !== undefined && msg.output.trim() !== "" ) {
            var cmd = msg.output.replace("/usr/bin/","");
            var info = "<code>"+cmd+"</code>"
            var height = Math.round(60 + (cmd.length / 50) * 19);
            var jq = "#folder_"+msg.input_obj.type;
            if (msg.input_obj.type == "nmtran_error") {
              info = "<div class='error'><b>/NM_run1:</b></div>"+info;
              info_nmtran_error = height;
              $(jq).dialog({ "height": height});
              $(jq).dialog({ "position": ["right-5", "bottom-"+(info_psn_cmd).toString()]});
            }
            if (msg.input_obj.type == "psn_cmd") {
              info = "<div class='focus'><b>PsN command:</b></div>"+info;
              info_psn_cmd = height;
              $(jq).dialog({ "position": ["right-5", "bottom-15"]});
            }
            $(jq).html(info);
            $(jq).dialog({ "height": height });
            $(jq).dialog("open");
            // resetTimer_folder_info();
          }
        });
    } else {
        $("#folder_info_dialog").dialog("close");
    }
}

function reload_run_estimates(id) {
    var run_info = [{
        "id": "---",
        "par": " [ loading... ] ",
        "est": "---",
        "se": "---",
    }];
    if (id.match('/') || id.match(/\.\./)) {
        run_info = [{
            "id": "---",
            "par": "---",
            "est": "---",
            "se": "---",
        }];
    }
    $("#list_estimates").jqGrid('clearGridData');
    $("#list_estimates").jqGrid('setGridParam', {
        data: run_info
    });
    $("#list_estimates").trigger("reloadGrid");
    if (!id.match('/') && !id.match(/\.\./)) {
        if (id !== '' && id !== undefined) {
            status("Getting run estimates...");
            $.post('/api/get_estimates', {
                cmd: "get_estimates",
                folder: document.getElementById('cwd_input').value,
                file: id + '.lst'
            }, function(msg) {
              current_est = msg;
              var run_info = parse_estimates_data(msg);
              curr_run_estimates = run_info;
              $("#list_estimates").jqGrid('clearGridData');
              $("#list_estimates").jqGrid('setGridParam', { data: run_info });
              $("#list_estimates").trigger("reloadGrid");
              status();
            });
        }
    }
}

function view_lst_command() {
    var ids = $("#main").getGridParam('selarrrow');
    var id = ids[0];
    if (!id.match(/^\//)) {
        id += '.lst';
    }
    if (id != '..') { // check if folder on serverside
        $.post('/api/view_lst', {
            cmd: 'view_lst',
            mode: 'nonmem',
            folder: $('#cwd_input').val(),
            file: id
        }, function(msg) {
            code_editor(msg);
        });
    }
}

function view_estimates_command() {
    var mods = $("#main").getGridParam('selarrrow');
    var cln = [];
    for (i in mods) {
        if (mods[i] != ".." && !mods[i].match(/$\//)) {
            cln.push(mods[i]+".mod");
        }
    }
    if (cln[0] != undefined) {
        status("Retrieving parameter estimates...");
        if(cln.length > 1) {
            $.post('/api/compare_estimates', {
              mods: cln,
              folder: $("#cwd_input").val()
            }, function(msg) {
              var tmp = csv2json_obj(msg.output);
              $('#spreadsheet').jqGrid('GridUnload');
              load_spreadsheet_grid(tmp.colnames, tmp.colmodel);
              show_in_spreadsheet(tmp.json, msg.file);
              $("#spreadsheet").jqGrid('setGridWidth', parseInt($("#spreadsheet_window").width() - 20) );
              $("#spreadsheet").jqGrid('setGridHeight', parseInt($("#spreadsheet_window").height() - 20) );
              status("");
            });
        } else {
          right_selector(2, true);
        }
    }
}

function resize_widgets(y_len) {
    // jqGrids
    $("#main").setGridWidth($(window).width() - right_grid_width);
    $("#main").setGridHeight($(window).height() - y_len);
    $("#list_files").setGridHeight($(window).height() - y_len - 23);
    $("#list_estimates").setGridHeight($(window).height() - y_len);
    $("#list_reports").setGridHeight($(window).height() - y_len);
    $("#list_r").setGridHeight($(window).height() - y_len);
    resize_pdf_viewer();
}

function resize_code_editor(ui) {
    var width = Math.round(ui.size.width);
    var height = Math.round(ui.size.height);
    $("#editor, #notes_editor").css({
        height: (height - 66),
    });
    $("#editor, #notes_editor").css({
        width: (width)
    });
}

function resize_pdf_viewer() {
    doc_height = $(window).height() - 93;
    $("#pdf_viewer").css({
        height: doc_height
    });
}

function right_selector(sel, force) {
    if ((sel !== window.sel) || (force == 1)) {
        $("#sel_files").removeClass('active');
        $("#sel_estimates").removeClass('active');
        $("#sel_r").removeClass('active');
        $("#sel_reports").removeClass('active');
        $("#sel_git").removeClass('active');
        // $("#sel_git").removeClass('active');
        if (window.sel == 1 && window.sel !== sel) {
            window.files_list = $("#files_wrapper").detach();
        }
        if (window.sel == 2 && window.sel !== sel) {
            window.estimates_list = $("#estimates_wrapper").detach();
        }
        if (window.sel == 3 && window.sel !== sel) {
            window.r_list = $("#r_wrapper").detach();
        }
        if (window.sel == 4 && window.sel !== sel) {
            window.reports_list = $("#reports_wrapper").detach();
        }
        if (window.sel == 5 && window.sel !== sel) {
            window.git_list = $("#git_wrapper").detach();
        }
        refresh_files(); // always refresh files
        if (sel == 1) {
            $("#sel_files").addClass('active');
            $("#right_wrapper").append(window.files_list);
            $("#list_files").setGridHeight($(window).height() - y_len - 23);
        }
        if (sel == 2) {
            $("#sel_estimates").addClass('active');
            $("#right_wrapper").append(window.estimates_list);
            $("#list_estimates").setGridHeight($(window).height() - y_len);
            var ids = $("#main").getGridParam('selarrrow');
            var mod = ids[0];
            if (mod != undefined) {
                reload_run_estimates(mod);
            }
        }
        if (sel == 3) {
            $("#sel_r").addClass('active');
            $("#right_wrapper").append(window.r_list);
            $("#list_r").setGridHeight($(window).height() - y_len);
            refresh_scripts();
        }
        if (sel == 4) {
            $("#sel_reports").addClass('active');
            $("#right_wrapper").append(window.reports_list);
            $("#list_reports").setGridHeight($(window).height() - y_len);
            refresh_reports();
        }
        if (sel == 5) {
            $("#sel_git").addClass('active');
            $("#right_wrapper").append(window.git_list);
            $("#list_git").setGridHeight($(window).height() - y_len);
            refresh_vc();
        }
        window.sel = sel;
    }
};
