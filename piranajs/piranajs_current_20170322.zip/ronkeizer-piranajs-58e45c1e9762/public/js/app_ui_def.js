// UI definitions
var line_colors = {
    red:'#efC9a4',
    green:'#c0dfc0',
    blue:'#aacaef',
    yellow:'#ffffc0',
    grey:'#dad7d3',
    white:'#ffffff'
}
// AJAX spinner
var opts = {
  lines: 13,
  length: 5,
  width: 2,
  radius: 4,
  corners: 1,
  rotate: 0,
  direction: 1,
  color: '#ff7516',
  speed: 1,
  trail: 60,
  shadow: false,
  hwaccel: false,
  className: 'spinner',
  zIndex: 2e9,
  top: '72%',
  left: '50%'
};

var proxy_redirect = window.location.pathname;
var flow_post_location = proxy_redirect + 'upload';
var r = new Flow({
  target: flow_post_location,
  chunkSize: 1024 * 1024,
  testChunks: false
});

$(function() {
    var target = document.getElementById('ajax_spinner');
    var spinner = new Spinner(opts).spin(target);
});

// error messages
function popup_msg(type, text) {
  if(type === "error") {
    $.growl.error({ message: text });
  }
  if(type === "success") {
    $.growl.success({ message: text });
  }
  if(type === "notice") {
    $.growl.notice({ message: text });
  }
  if(type === "warning") {
    $.growl.warning({ message: text });
  }
}

// main menu
function mainmenu(){
  $(" #nav ul ").css({display: "none"}); // Opera Fix
  $(" #nav li").hover(function(){
    $(this).find('ul:first').css({visibility: "visible",display: "none"}).show();
  },function(){
    $(this).find('ul:first').css({visibility: "hidden"});
  });
}
$(function() {
  mainmenu();
});

$(function() {
  $( "#menu" ).menu({
    position: {
      my:'left center',
      at:'right bottom'
    }
  })
});

$(function() {
  $( document ).tooltip({
    position: {
      my: "center bottom-10",
      at: "center top",
      using: function( position, feedback ) {
        $( this ).css( position );
        $( "<div>" )
        .addClass( "arrow" )
        .addClass( feedback.vertical )
        .addClass( feedback.horizontal )
        .appendTo( this );
      }
    }
  });
});

$(function() {
  $( "#progressbar" ).progressbar({ value: 0 });
});

$(function() {
  editor = ace.edit("editor");
  editor.setTheme("ace/theme/monokai");
  editor.getSession().setMode("ace/mode/nonmem"); //  default = NONMEM

  notes_editor = ace.edit("notes_editor");
  notes_editor.setTheme("ace/theme/twilight");
  notes_editor.getSession().setUseWrapMode(true);
  notes_editor.getSession().setMode("ace/mode/markdown"); //  default = NONMEM
});

$(function() {
  $("#project_selector").select2({ width: 150 })
  .on("change", function() {
    project_selected()
  }
);
$("#chat_user_selector").select2({ width: 100, minimumResultsForSearch: -1 });
$("#folder_filter").select2({ width: 130, minimumResultsForSearch: -1 })
  .on("change", function() {
});
$("#template_selector").select2({ width: "100%", minimumResultsForSearch: -1 })
  .on("change", function() {
});
$("#model_info_refmod").select2({
    width: 120, minimumResultsForSearch: -1 })
    .on("change", function() {
  }
);
$("#button_psn_other").select2({
  placeholder: "PsN tools",
  width: 150,
    //	minimumResultsForSearch: -1
}).on("select2-selecting", function(e) {
  open_psn_dialog( e.val );
});
// $("#video_select").select2({ width: 250, minimumResultsForSearch: -1 }).on("select2-selecting", function(e) {
//   show_selected_video(e.val);
// });
$("#set_color").select2({
  width: 75,
  placeholder: "color",
  formatResult: format_col,
  formatSelection: format_col,
  escapeMarkup: function(m) { return m; },
  minimumResultsForSearch: -1 })
  .on("select2-selecting", function(e) {
    set_color(line_colors[e.val]);
  }
);
$("#set_flag").select2({
  width: 75,
  placeholder: "flag",
  formatResult: format_flag,
  formatSelection: format_flag,
  escapeMarkup: function(m) { return m; },
  minimumResultsForSearch: -1 }
)
.on("select2-selecting", function(e) {
  if (e.val == "key") {set_flag("key");}
  if (e.val == "green") {set_flag("green");}
  if (e.val == "red") {set_flag("red");}
  if (e.val == "remove") {remove_flags();}
}
);
function format_col(col) {
  if (!col.id) return col.text; // optgroup
  return "<img class='flag' src='../images/color_" + col.id + ".gif'/>&nbsp;&nbsp;" + col.text;
}
function format_flag(fl) {
  if (!fl.id) return fl.text; // optgroup
  var flag;
  if (fl.id == "key") {flag = "key_just" }
  if (fl.id == "green") {flag = "flag_green_just" }
  if (fl.id == "red") {flag = "flag_red_just" }
  if (fl.id == "remove") {flag = "flag_remove" }
  return "<img class='flag' src='../images/" + flag + ".gif'/>&nbsp;&nbsp;" + fl.text;
}
});

function populate_list (widget, options, options_text) {
    var option_string;
    if (options_text === undefined) { options_text = options };
    for(var i = 0; i < options.length; i++) {
	option_string += "<option value='" + options[i] + "'>" + options_text[i] + "</option>";
    };
    $(widget).find('option').remove().end().append(option_string);
}
// populate psn list
// populate color/flag list
$(function() {
    var psn_options = ["vpc", "npc", "linearize", "llp", "bootstrap", "cdd", "scm", "xv_scm", "boot_scm", "lasso", "sse", "mcmp",
      "data_stats", "randtest", "mimp", "sir", "frem", "parallel_retries", "update_inits", "benchmark", "ebe_npde", "nca", "pvar", "gls",
      "extended_grid", "pind", "se_of_eta", "nmoutput2so" ];
    psn_options = psn_options.sort();
    var colors = ["red","green","blue","yellow","grey","white"];
    var colors_text = ["","","","","","",""];
    var flags = ["key","green","red","remove"];
    var flags_text = ["","","",""];
    populate_list("#button_psn_other", psn_options);
    populate_list("#set_color", colors, colors_text);
    populate_list("#set_flag", flags, flags_text);
});

// function build_psn_nm_selector () {
$(function() {
  $("#psn_nm_selector").select2({
    width: 150,
    minimumResultsForSearch: -1
  });
  $("#psn_nm_selector").on("change", function() {
    var s = $('#psn_nm_selector');
    if(s) {
      update_psn_nm_version(s.val());
    } else {
      console.log(s);
    }
  });
});

$(function() {
  $("#run_on_grid").button();
});

$(function() {
  $("#mpi_selector").select2({
    width: 150,
    minimumResultsForSearch: -1
  });
  $("#mpi_selector").on("change", function() {
    var s = $('#mpi_selector');
    if(s) {
      update_mpi_arguments(s.val());
    } else {
      console.log(s);
    }
  });
});

function objCopy(obj) {
  return(JSON.parse(JSON.stringify(obj)));
}

function update_mpi_arguments(arg) {
  // if(!mpi_prv) {
  //   mpi_prv = arg;
  // }
  var rmv = ["-run_on_sge", "-sge_prepend_flags", "-parafile", "-nodes"];
  if(mpi_prv && mpi.presets[mpi_prv] && typeof(mpi.presets[mpi_prv] && mpi.presets[mpi_prv].psn_args)) {
    rmv = rmv.concat(arg);
  }
  for(var i = 0; i < rmv.length; i++ ) {
    var arg_arr = rmv[i].replace(/^\-+?/,"").split(/=/);
    remove_psn_argument(arg_arr[0]);
  }
  if (mpi.presets[arg]) {
    var args = objCopy(mpi.presets[arg].psn_args);
    // if(mpi.presets[arg].sge_prepend_flags) {
    //   args.push("-sge_prepend_flags='"+mpi.presets[arg].sge_prepend_flags+"'");
    // }
  //  if(arg !== "no") {
      $("#run_on_grid").attr('checked', true);
      if(args) {
        for(var i = 0; i < args.length; i++ ) {
          if(args[i].match(/run_on_sge/)) {
            $("#run_on_grid").attr('checked', true);
          }
          add_psn_argument(args[i]);
        }
      }
    }
//  }
    update_parafile(arg);
    if($("#run_on_grid").attr('checked')) {
      add_psn_argument("-run_on_sge");
      if(mpi.presets[arg] && mpi.presets[arg].sge_prepend_flags) {
        add_psn_argument("-sge_prepend_flags='"+mpi.presets[arg].sge_prepend_flags+"'");
      } else {
        if(sge && sge.prepend_flags) {
          add_psn_argument("-sge_prepend_flags='"+sge.prepend_flags+"'");
        }
      }
    }
    mpi_prv = arg;
  }

function update_parafile(arg) {
  var n = arg.replace(/[ a-zA-Z\-\(\)]/g,"");
  var cmd = $("#psn_execute_dialog_command").val();
  var mods = $("#main").getGridParam('selarrrow');
  var modname = "generic";
  if(mods[0]) {
    modname = mods[0];
  }
  var n_cores = "";
  if(n) {
    n_cores = "_"+n;
  }
  var tmp = cmd.match(/-parafile=\<(.*?)\>/);
  if(tmp) {
    cmd = cmd.replace(/-parafile=\<.*?\>/, "-parafile=" + mods[0] + n_cores + ".pnm");
    $.post('/api/create_pnm_file', {
      cmd: 'create_pnm_file',
      folder: $('#cwd_input').val(),
      n: n,
      file: mods[0]+n_cores+".pnm",
      preset: arg
    }, function(msg) {
      // do nothing?
    });
  }
  $("#psn_execute_dialog_command").val(cmd);
}

function psn_format_result(psn) {
    var markup = "<table class='psn-result'><tr>";
    markup += "<td class='psn-info'><div class='psn-title'>" + psn.syntax_full + "</div>";
    if (psn.help !== undefined) {
        markup += "<div class='movie-synopsis'>" + psn.help + "</div>";
    }
    markup += "</td></tr></table>"
    return markup;
}

function psn_format_selection(psn) {
    return psn.id;
}

$(function() {
    doc_height = $(window).height() * 0.8 + 8;
    $("#code_editor").dialog({
        autoOpen: false,
        modal: false,
        width: 720,
        minWidth: 720,
        height: doc_height,
        minHeight: 400,
        open: function(e, ui) {
            doc_height = $(window).height() * 0.8 + 8;
            if (ui.size === undefined) {
                ui.size = {
                    width: 700,
                    height: doc_height
                };
            }
            resize_code_editor(ui); // need to fix
        },
        close: function() {
            editor_active = 0;
        },
        resize: function(e, ui) {
            resize_code_editor(ui); // need to fix
        }
    });
    $('#code_editor').dialog('option', 'width', $('#editor').width() + 4);
    $('#code_editor').dialog('option', 'height', doc_height);

    $("#notes_editor_dialog").dialog({
        autoOpen: false,
        modal: false,
        width: 720,
        minWidth: 720,
        height: doc_height,
        minHeight: 700,
        open: function(e, ui) {
            doc_height = $(window).height() * 0.8 + 8;
            if (ui.size === undefined) {
                ui.size = {
                    width: 700,
                    height: doc_height
                };
            }
            resize_code_editor(ui); // need to fix
        },
        close: function() {
            editor_active = 0;
        },
        resize: function(e, ui) {
            resize_code_editor(ui); // need to fix
        }
    });
    $('#notes_editor_dialog').dialog('option', 'width', $('#notes_editor').width() + 4);
    $('#notes_editor_dialog').dialog('option', 'height', doc_height);
});

$(function() {
    $("#video_player" ).dialog({
  	  title: "PiranaJS video tutorials",
  	  autoOpen: false,
  	  modal: true,
  	  width: 760,
	    height: 532
    });
});

$(function() {
    $( "#cluster_mon_div" ).tabs({'autoOpen': false });
    $( "#cluster_mon_div" ).dialog({
    	'autoOpen': false,
    	'modal': false,
    	'draggable':true,
    	'minWidth': 572,
    	'minHeight': 300,
    	open: function () {
    	    refresh_timer_started = 1;
    	    cluster_monitor_active = 1;
    	},
    	close: function () {
    	    cluster_monitor_active = 0;
   	}
    });
    $( "#cluster_mon_div" ).find('.ui-tab-dialog-close').css({'position':'absolute','right':'100', 'top':'0px'});
    $( "#cluster_mon_div" ).find('.ui-tab-dialog-close > a').css({'float':'none','padding':'0'});
    var tabul = $( "#cluster_mon_div" ).find('ul:first');
    $( "#cluster_mon_div" ).parent().addClass('ui-tabs').prepend(tabul).draggable('option', 'handle', '.ui-tabs-nav');
    $( "#cluster_mon_div" ).siblings('.ui-dialog-titlebar').remove();
    tabul.addClass('ui-dialog-titlebar');
    $('#cluster_mon_div').tabs({ selected: 0, active: 0 });
    $('#close_button').button( {icons: {primary: "ui-icon-closethick" }});
});

$(function() {
    $( "#intermed_est_div" ).tabs({'autoOpen': false });
    $( "#intermed_est_div" ).dialog({
    	'autoOpen': false,
    	'modal': false,
    	'draggable':true,
    	'minWidth': 600,
    	'minHeight': 300,
    	open: function () {
    	},
    	close: function () {
   	}
    });
    // $( "#intermed_est_div" ).find('.ui-tab-dialog-close').css({'position':'absolute','right':'100', 'top':'0px'});
    // $( "#intermed_est_div" ).find('.ui-tab-dialog-close > a').css({'float':'none','padding':'0'});
    // var tabul = $( "#cluster_mon_div" ).find('ul:first');
    // $( "#cluster_mon_div" ).parent().addClass('ui-tabs').prepend(tabul).draggable('option', 'handle', '.ui-tabs-nav');
    // $( "#cluster_mon_div" ).siblings('.ui-dialog-titlebar').remove();
    // tabul.addClass('ui-dialog-titlebar');
    // $('#cluster_mon_div').tabs({ selected: 0, active: 0 });
    // $('#close_button').button( {icons: {primary: "ui-icon-closethick" }});
});

$(function() {
    $("#intermediate_res_table").jqGrid({
	colNames:['Run #','Folder','Iter #','OFV','Description'],
	colModel:[
	    {name:'runno', index:'folder', width:'70', align: "left"},
	    {name:'dir',  width:'150', align: "left"},
	    {name:'iter', width:'50', align: "right"},
	    {name:'ofv', width:'60', align: "right"},
	    {name:'descr', width:'220', align: "left"}
	],
	cmTemplate: {sortable:false},
	rowNum:1000,
	width: '100%',
	datatype: 'local',
	viewrecords: true,
	sortorder: "asc",
	gridview : true,
	height : 100,
	hoverrows : false,
	sortable : true,
	multiselect: false,
	hidegrid : false,
	onSelectRow: function(rowid){
	    show_intermed_est(rowid);
	},
	ondblClickRow: function(rowid) {
	},
	localReader : {
	    repeatitems: false,
	    id:"run"
	},
	gridComplete: function() {
	    $(this).jqGrid('hideCol', 'cb');
	}
    });
});

$(function() {
    $("#intermediate_est_table").jqGrid({
	colNames:['#','Theta','Omega','Sigma'],
	colModel:[
	    {name:'parno', index:'parno', width:'25', align: "right"},
	    {name:'theta',  width:'50', align: "right"},
	    {name:'omega', width:'50', align: "right"},
	    {name:'sigma', width:'50', align: "right"}
	],
	cmTemplate: {sortable:false},
	rowNum:1000,
	width: '100%',
	datatype: 'local',
	viewrecords: true,
	sortorder: "asc",
	gridview : true,
	height : 200,
	hoverrows : false,
	sortable : true,
	multiselect: false,
	hidegrid : false,
	onSelectRow: function(rowid){
	},
	ondblClickRow: function(rowid) {
	},
	localReader : {
	    repeatitems: false,
	    id:"run"
	},
	gridComplete: function() {
	    $(this).jqGrid('hideCol', 'cb');
	}
    });
});

$(function() {
  $( "#pdf_viewer").dialog({
      autoOpen: false,modal: true,
      width: 700,
//      position: [$(window).width()/2,20],
      height: 720
//      height: $(window).height() * 50
  });
});
$(function() {
    $( "#data_inspector" ).dialog({ autoOpen: false, modal: true, width: 950, height: 550 }).css("overflow", "hidden");
    $( "#data_x_sel" ).selectable();
    $( "#data_y_sel" ).selectable();
    $("#data_inspector_y_slider").slider({
      orientation: "vertical",
      range: true,
      values: [ 0, 100 ],
      min: 0,
      max: 100,
      change: function( event, ui ) {
        update_data_inspector_plot();
      }
    });
    $("#data_inspector_x_slider").slider({
      range: true,
      values: [ 0, 100],
      min: 0,
      max: 100,
      change: function( event, ui ) {
        update_data_inspector_plot();
      }
    });
});
$(function() {
  $( "#vrr" ).dialog({ autoOpen: false, modal: true, width: 900, height: 550 });
});

$(function() {
  $( "#node_output_dialog" ).dialog({
    autoOpen: false, width: 680, height: 432,
    open: function (event, ui) {
      $('#node_output_dialog').css('overflow', 'hidden'); //this line does the actual hiding
    },
    close: function (event, ui) {
      show_console = 0;
    }
  }).resizable();
});

$(function() {
  $( "#upload_window" ).dialog({
    autoOpen: false, width: 600, height: 250
  }).resizable();
});

var bht = 25; // button height
var bwd = 36; // button width
$(function() {
    $( "#button_add_project" )
      .button().css("height", bht).css("width", bwd).html("<i class='fa fa-floppy-o fa-lg grey'></i>").click(function() {  })
      .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-info-circle fa-lg grey'></i>").click(function() { })
      // .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-pencil fa-lg grey'></i>").click(function() { })
      .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-trash fa-lg grey'></i>").click(function() {  })
      .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-download fa-lg grey'></i>").click(function() { })
      .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-refresh fa-lg green'></i>").click(function() {  })
        .parent()
          .buttonset();
    $( "#button_file_edit" )
      .button({icons: {primary: "ui-icon-txt"}}).css("height", bht).click(function() {  })
      .next().button({ icons: {primary: "ui-icon-edit_info"} }).css("height", bht).click(function() { })
      .next().button({ icons: {primary: "ui-icon-delete_project"} }).css("height", bht).click(function() { })
      .parent().buttonset();
    $( "#button_r_pdf" )
      .button({icons: {primary: "ui-icon-r_pdf"}}).css("height", bht).click(function() {  })
      .next().button({ icons: {primary: "ui-icon-r_edit"} }).css("height", bht).click(function() { })
      .parent().buttonset();
    $( "#button_report_open" )
      .button({icons: {primary: "ui-icon-document"}}).css("height", bht).click(function() {  })
      .parent().buttonset();
    $( "#button_git_commit" )
      .button({icons: {primary: "ui-icon-r_pdf"}}).css("height", bht).click(function() {  })
      .next().button({ icons: {primary: "ui-icon-r_gui"} }).css("height", bht).click(function() { })
      .next().button({ icons: {primary: "ui-icon-r_edit"} }).css("height", bht).click(function() { })
      .parent().buttonset();
    $( "#button_edit_info" )
      .button().css("height", bht).css("width", bwd).html("<i class='fa fa-info-circle fa-lg grey'></i>").click(function() { })
      .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-globe fa-lg grey'></i>").click(function() { });
    $( "#button_psn_execute" ).button().addClass("red").css("height", bht);
    $( "#button_psn_repeat" ).button().addClass("red").css("height", bht).css("width", bwd).html("<i class='fa fa-repeat fa-lg red'></i>");
    $( "#button_psn_log").button().css("height", bht).css("width", bwd).html("<i class='fa fa-book fa-lg red'></i>");
    $( "#button_psn_log2").button().css("height", bht).css("width", bwd).html("<i class='fa fa-book fa-lg red'></i>");
    $("#duplicate_dialog_upd_est").button();
    $("#duplicate_dialog_upd_num").button();
    $("#point_selector").button().css("height", bht).css("width", "100%");
    $("#line_selector").button().css("height", bht).css("width", "100%");
    $("#unity_selector").button().css("height", bht).css("width", "100%");;
     $("#button_flag_remove").button({ icons: {primary: "ui-icon-flag_remove"} }).css("height", bht).click(function() { });
    $( "#button_unhide" )
      .button().css("height", bht).css("width", bwd).html("<i class='fa fa-eye fa-lg grey'></i>").click(function() {  })
      .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-eye-slash fa-lg grey'></i>").click(function() { })
      .parent().buttonset();
    $( "#button_send_message_private").button().css("height", bht);
    $( "#button_send_message_all").button().css("height", bht);
    $( "#button_clear_chat").button().css("height", bht);
    $( "#button_vrr").button().css("height", bht).css("width", bwd).html("<i class='fa fa-code-fork fa-lg blue'></i>");
    $( "#button_plots").button().css("height", bht).css("width", bwd).html("<i class='fa fa-line-chart fa-lg blue'></i>").click(function() { })
    $( "#button_console").button().css("height", bht).css("width", bwd).html("<i class='fa fa-terminal fa-lg'></i>");
    $( "#button_monitor").button().css("height", bht).css("width", bwd).html("<i class='fa fa-tachometer fa-lg blue'></i>").css("height", bht)
	    .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-binoculars fa-lg blue'></i>")
      .next().button().css("height", bht).css("width", bwd).html("<i class='fa fa-list-ol fa-lg blue'></i>")
      .parent().buttonset();
    $("#button_cancel_modal").button().css("background", "#efefef").css("color", "black")
      .next().button().css("background", "#efefef").css("color", "black")
      .parent()
        .buttonset();
    $( "#cluster_refresh_button" ).button({ icons: {primary: "ui-icon-arrowrefresh-1-e"} })
      .parent().buttonset();
    $( "#button_psn_tool_h")
      .button().css("height", bht)
      .next().button().css("height", bht)
      .next().button().css("height", bht)
      .next().button().css("height", bht)
      .parent().buttonset();
      $("#data_insp_x_label_btn").button().css("height", 20).css("width", "100%");
      $("#data_insp_y_label_btn").button().css("height", 20).css("width", "100%");
    $("#r_code_button").button().css("height", bht).css("width", "100%");
    $("#download_png_button").button().css("height", bht).css("width", "100%");
    $("#download_svg_button").button().css("height", bht).css("width", "100%");
    $("#refresh_inter_button").button().css("height", bht);
    $("#console_tabs_close_all").button()
	.css("height", 20).css("width", 108)
	.css("background", "#cc3333")
	.css("color", "#ffffff");
  });

$(function() {
    var bht = 30;
    $( "#button_save" ).button().addClass("hspace").html("<i class='fa fa-floppy-o fa-lg grey'></i>&nbsp;<span class='small'>Save</span>&nbsp;")
    .next().button().addClass("hspace").html("<i class='fa fa-floppy-o fa-lg grey'></i>&nbsp;<span class='small'>Save as...</span>")
    .next().button().addClass("hspace").html("<i class='fa fa-copy fa-lg grey'></i>&nbsp;<span class='small'>duplicate</span>")
    .next().button().addClass("hspace").html("<i class='fa fa-info-circle fa-lg grey'></i>&nbsp;<span class='small'>info</span>")
    .next().button().addClass("hspace").html("<i class='fa fa-arrows-h fa-lg grey'></i>&nbsp;<span class='small'>diff</span>")
    .next().button().addClass("hspace").html("<i class='fa fa-play fa-lg grey'></i>&nbsp;<span class='small'>execute</span>")
	.parent().buttonset();
	$( "#button_save_notes" ).button({ icons: { primary: "ui-icon-disk" } });
    $("#button_build" ).button({ icons: { primary: "ui-icon-document" } });

});

$(function() {
    $( "#button_run" ).button({ icons: { primary: "ui-icon-circle-triangle-e" } }); });
$(function() {
    $( "#sel_files" )
      .button().css("height", bht).click(function() { right_selector(1); })
      .next()
        .button().css("height", bht).click(function() { right_selector(2); })
      .next()
        .button().css("height", bht).click(function() { right_selector(3); })
      .next()
        .button().css("height", bht).click(function() { right_selector(4); })
      .next()
        .button().css("height", bht).click(function() { right_selector(5); })
//        .button({ icons: { primary: "ui-icon-person" }}).css("height", bht).click(function() { right_selector(5); })
      .parent()
       .buttonset();
  });

$(function() {
    $("#list_files").jqGrid({
        colNames: ['File'],
        colModel: [{
            name: 'file',
            index: 'file',
            width: 272
        }, ],
        rowNum: 1000,
        height: doc_height,
        datatype: 'local',
        width: '100%',
        viewrecords: true,
        cmTemplate: {
            sortable: false
        },
        sortorder: "asc",
        gridview: true,
        hoverrows: false,
        sortable: true,
        multiselect: true,
        hidegrid: false,
        localReader: {
            repeatitems: false,
            id: "file"
        },
        ondblClickRow: function(rowid) {
            dbl_click_file(rowid);
        },
        rowattr: function(rd) {
            file_id = rd.file;
            if (file_id !== undefined) {
                if (file_id.match(/\.R$/i)) {
                    return {
                        "class": "r_row"
                    };
                }
                // if (file_id.match('.mod')) {
                //   return {"class": "mod_row"};
                // }
                // if (file_id.match('.lst')) {
                //   return {"class": "lst_row"};
                // }
                if (file_id.match('\.csv')) {
                    return {
                        "class": "csv_row"
                    };
                }
                if (file_id.match(/^(sdtab|patab|cotab|catab|mytab)/i)) {
                    return {
                        "class": "xp_row"
                    };
                }
		return {
		    "class": "lgrey2"
		}
            }
        },
        gridComplete: function() {
            $(this).jqGrid('hideCol', 'cb');
            $(this).find(">tbody>tr.jqgrow:odd").addClass("even_row");
            $(this).find(">tbody>tr.jqgrow:even").addClass("odd_row");
        },
        beforeSelectRow: function(rowid, e) { // needed for multiple selection with shift + ctrl
            if (!e.ctrlKey && !e.shiftKey) {
                $("#list_files").jqGrid('resetSelection');
            }
            // else if (e.shiftKey) {
            //     var initialRowSelect = $("#list_files").jqGrid('getGridParam', 'selrow');
            //     $("#list_files").jqGrid('resetSelection');
            //     var CurrentSelectIndex = $("#list_files").jqGrid('getInd', rowid);
            //     var InitialSelectIndex = $("#list_files").jqGrid('getInd', initialRowSelect);
            //     var startID = "";
            //     var endID = "";
            //     if (CurrentSelectIndex > InitialSelectIndex) {
            //         startID = initialRowSelect;
            //         endID = rowid;
            //     }
            //     else {
            //         startID = rowid;
            //         endID = initialRowSelect;
            //     }
            //     var shouldSelectRow = false;
            //     $.each($("#list_files").getDataIDs(), function(_, id){
            //         if ((shouldSelectRow = id == startID || shouldSelectRow)){
            //           $("#list_files").jqGrid('setSelection', id, false);
            //         }
            //         return id != endID;
            //     });
            // }
            return true;
        },
        loadComplete: function() {
            var rows = $("#list_files tr:gt(0)"); // remove titles for tooltips
            rows.each(function(index) {
                rows.children("td").each(function() {
                    $(this).removeAttr('title');
                })
            });
            $("tr.jqgrow", this).contextMenu('context_files', {
                bindings: {
                    'edit': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        var id = ids[0];
                        // if (id != '..' && !id.match(/^\//)) {
                        if (id !== undefined) {
                            status("Opening file in editor");
                            $.post('/api/code_editor', {
                                cmd: 'code_editor',
                                mode: 'txt',
                                folder: $('#cwd_input').val(),
                                file: id
                            }, function(msg) {
                              code_editor(msg);
                              status();
                            });
                        }
                        // }
                    },
                    'files_info': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        file_action(ids, "file_info");
                    },
                    'files_delete': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        file_action(ids, "file_delete");
                    },
                    'files_download': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        file_action(ids, "file_download");
                    },
                    'files_spreadsheet': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        var id = ids[0];
                        if (id !== undefined && id.match(/(tab|\.csv$)/i)) {
                            status("Opening table file");
                            $.post('/api/open_file_in_spreadsheet', {
                                "file": id,
                                "folder": $("#cwd_input").val()
                            }, function(msg) {
                              open_file_in_spreadsheet(msg);
                            });
                        } else {
                            alert("Sorry, only csv can be opened in spreadsheet!");
                        }
                    },
                    'files_data_inspector': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        var id = ids[0];
                        if (id !== undefined && id.match(/(tab|\.csv$)/i)) {
                            status("Opening table file in DataInspector");
                            $.post('/api/get_data_info', {
                                cmd: 'get_data_info',
                                folder: $("#cwd_input").val(),
                                file: id
                            }, function(msg) {
                                if (msg.output !== undefined) {
                                  var data_info = try_parse_json(msg.output);
                                  if (data_info) {
                                    update_data_inspector(data_info, 0);
                                  }
                                }
                            });
                            $('#data_inspector').dialog('open');
                            $('#data_inspector_plot').focus();
                        } else {
                            alert("Sorry, only csv can be opened in DataInspector!");
                        }
                    },
                    'files_copy': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        var id = ids[0];
                        $('#copy_old_filename_input').val(id);
                        $('#copy_new_filename_input').val(id);
                        $('#copy_file_dialog').dialog('open');
                        $('#copy_file_dialog').focus();
                    },
                    'files_rename': function(trigger) {
                        var ids = $("#list_files").getGridParam('selarrrow');
                        var id = ids[0];
                        $('#old_filename_input').val(id);
                        $('#new_filename_input').val(id);
                        $('#rename_file_dialog').dialog('open');
                        $('#rename_file_dialog').focus();
                    }
                },
                onContextMenu: function(event /*, menu*/ ) {
                    var rowId = $(event.target).closest("tr.jqgrow").attr("file");
                    return true;
                }
            });
        }
    });
    $("#list_files").jqGrid('filterToolbar', {
        stringResult: true,
        searchOnEnter: false,
        defaultSearch: 'cn'
    });
    $("#list_files").setGridHeight($(window).height() - y_len);
});

$(function() {
  $("#nm_help_dialog").dialog({
      autoOpen: false,
      height: 540,
      width: 800,
      modal: true,
//      buttons: { Close: function() { $( this ).dialog( "close" ); } },
      open: function (event, ui) {
    	  console.log("Retrieving NONMEM help file index...");
    	  status("Retrieving NONMEM help file index...");
    	  $.post('/api/nm_help_index', {
    	      cmd: "nm_help_index"
    	  }, function(msg) {
          var tmp = try_parse_json(msg.output);
          if (tmp) {
            nm_help_index = [];
            var help = tmp.help_files;
            for (var key in help) {
              nm_help_index.push({
                key: key,
                file: help[key]
              })
            }
            nm_help_index = _.sortBy(nm_help_index, function(row) { return(row.key) });
          }
          populate_list_with_data("#list_nm_help", nm_help_index);
          status("");
        });
      }
    }).css("overflow", "hidden");
});

$(function() {
  $("#list_nm_help").jqGrid({
    colNames:['keyword'],
    colModel:[
      {name: 'key', index:'key', width: 120},
    ],
    height : doc_height,
    datatype: 'local',
    width : '100%',
    height: '100%',
    viewrecords: true,
    cmTemplate: {sortable:false},
    sortorder: "asc",
    gridview : true,
    hoverrows : false,
    sortable : true,
    multiselect: false,
    hidegrid : false,
    localReader : {
    repeatitems: false,
    id:"file"
    },
    onSelectRow: function(rowid){
      nm_help(rowid);
    },
    gridComplete: function() {
      $(this).jqGrid('hideCol', 'cb');
    },
    loadComplete: function() {
      var rows = $("#list_files tr:gt(0)"); // remove titles for tooltips
      rows.each(function(index) {
        rows.children("td").each(function() {
         $(this).removeAttr('title');
        })
      });
    }
  });
  $("#list_nm_help").jqGrid('filterToolbar', { stringResult: true, searchOnEnter: false, defaultSearch: 'cn' });
});

$(function() {
  $("#psn_log_list").jqGrid({
    colNames:['Command'],
    colModel:[
      {name: 'command', index:'command', width: 200}
    ],
    data: [ {par: " - "} ],
    rowNum: 200,
    width : '435',
    height : '280',
    cmTemplate: {sortable:false},
    datatype: 'local',
    gridview : false,
    viewrecords: true,
    sortorder: "asc",
    localReader : {
     repeatitems: false,
     id: "id"
    }
  });
  $("#psn_log_list").jqGrid('filterToolbar', {
      stringResult: true,
      searchOnEnter: false,
      defaultSearch: 'cn'
  });
});

$(function() {
  $("#delete_dialog_list").jqGrid({
    colNames:['Model / folder'],
    colModel:[
      {name: 'file', index:'file', width: 200}
    ],
    data: [ {par: " - "} ],
    rowNum: 200,
    width : '200',
    height : '200',
    cmTemplate: {sortable:false},
    datatype: 'local',
    gridview : false,
    viewrecords: true,
    sortorder: "asc",
    localReader : {
     repeatitems: false,
     id:"file"
    }
  });
});

$(function() {
  $("#list_estimates").jqGrid({
    colNames:['#', 'Param.','Estim.',"RSE", "95% CI"],
    colModel:[
      {name: 'id', index:'id', width: 33},
      {name: 'par', index:'par', width: 50},
      {name: 'est', index: 'est', width: 45, align: 'right'},
      {name: 'rse', index: 'rse', width: 45, align: 'right'},
      {name: 'ci', index: 'ci', width: 80, align: 'center'}
    ],
    data: [ {par: "No estimates"} ],
    rowNum: 1000,
    // width : '100%',
    height : '720',
    cmTemplate: { ortable:false },
    datatype: 'local',
    gridview : true,
    viewrecords: true,
    sortorder: "asc",
    localReader : {
      repeatitems: false,
      id:"file"
    },
    rowattr: function (rd) {
      par_id = rd.id;
      if (par_id !== undefined) {
        if (par_id.match('TH')) {
          return {"class": "th_row"};
        }
        if (par_id.match('OM')) {
          return {"class": "om_row"};
        }
        if (par_id.match('SI')) {
          return {"class": "si_row"};
        }
      }
    },
    loadComplete: function() {
      var rows = $("#list_estimates tr:gt(0)"); // remove titles for tooltips
      rows.each(function(index) {
        rows.children("td").each(function() {
          $(this).removeAttr('title');
        })
      });
      $("tr.jqgrow", this).contextMenu('context_est', {
        width: 400,
        bindings: {
          'relative_var': function() {
            relative_var = 1-relative_var;
            if(relative_var == 1) {
              $("#rel_err_span").html("Untransform variab.");
            } else {
              $("#rel_err_span").html("Variability as SE");
            }
            var run_info = parse_estimates_data(current_est);
            console.log(run_info);
            $("#list_estimates").jqGrid('clearGridData');
            $("#list_estimates").jqGrid('setGridParam', { data: run_info });
            $("#list_estimates").trigger("reloadGrid");
          },
          'r': function() {
            run_report('r_obj');
          },
          'html': function() {
            run_report('html');
          },
          'docx': function() {
            run_report('docx');
          },
          'txt': function() {
            run_report('txt');
          },
          'tex': function() {
            run_report('tex');
          },
          'pdflatex': function() {
            run_report('pdflatex');
          }
        },
        onContextMenu: function(event/*, menu*/) {
          var rowId = $(event.target).closest("tr.jqgrow").attr("file");
          return true;
        }
      });
    }
  });
  $("#list_estimates").setGridHeight($(window).height() - y_len);
  window.estimates_list = $("#estimates_wrapper").detach();
});

$(function() {
  $("#list_r").jqGrid({
    datatype: "jsonstring",
    colNames:['R script'],
    colModel:[
      {name: 'name', index:'id', width: 272, align:'left'}
    ],
    viewrecords: true,
    height: '720',
    gridview: true,
    hoverrows : true,
    sortable : false,
    multiselect: false,
    hidegrid : true,
    rowNum: 10000,
    width : '100%',
    cmTemplate: {sortable:false},
    sortname: null,
   treeGrid: true,
   treeGridModel: 'adjacency',
    treedatatype: "local",
    treeIcons: {leaf:'ui-icon-document-b'},
    ExpandColumn: 'name',
    rowattr: function (rd) {
      return {"class": "grid_row_white"};
    },
    jsonReader: {
        repeatitems: false,
        root: function (obj) { return obj; },
        page: function (obj) { return 1; },
        total: function (obj) { return 1; },
        records: function (obj) { return obj.length; }
    },
    ondblClickRow: function(rowid) {
	run_r_script(rowid);
    },
    gridComplete: function() {
	var rows = $("#list_r tr:gt(0)"); // remove titles for tooltips
	rows.each(function(index) {
            rows.children("td").each(function() {
		$(this).removeAttr('title');
            })
	});
        $("tr.jqgrow", this).contextMenu('context_menu_r', {
	    bindings: {
		'run': function() {
		    run_r_script();
		},
		'edit': function() {
		    edit_script();
		},
		'copy': function() {
		    copy_script();
		}
	    },
            onContextMenu: function(event/*, menu*/) {
		var rowId = $(event.target).closest("tr.jqgrow").attr("name");
		return true;
            }
	});
    }
  });
  $("#list_r").setGridHeight($(window).height() - y_len);
  window.r_list = $("#r_wrapper").detach();
});

$(function() {
  $("#list_reports").jqGrid({
    datatype: "jsonstring",
    // datastr: scripts,
    colNames:['Report'],
    colModel:[
      {name: 'name', index:'id', width: 272, align:'left'}
    ],
    height: '720',
    gridview: false,
    hoverrows : false,
    sortable : false,
    multiselect: false,
    hidegrid : false,
    rowNum: 10000,
    width : '100%',
    viewrecords: true,
    cmTemplate: {sortable:false},
    sortname: null,
    treeGrid: true,
    treeGridModel: 'adjacency',
    treedatatype: "local",
    treeIcons: {leaf:'ui-icon-document-b'},
    ExpandColumn: 'name',
    rowattr: function (rd) {
      return {"class": "grid_row_white"};
    },
    jsonReader: {
      repeatitems: false,
      root: function (obj) { return obj; },
      page: function (obj) { return 1; },
      total: function (obj) { return 1; },
      records: function (obj) { return obj.length; }
    },
    ondblClickRow: function(rowid) {
      open_report(rowid);
    },
    gridComplete: function() {
      var rows = $("#list_reports tr:gt(0)"); // remove titles for tooltips
      rows.each(function(index) {
        rows.children("td").each(function() {
          $(this).removeAttr('title');
        })
      });
      $("tr.jqgrow", this).contextMenu('context_reports', {
        bindings: {
          'open': function(trigger) {
            open_report();
          }
        },
        onContextMenu: function(event/*, menu*/) {
          var rowId = $(event.target).closest("tr.jqgrow").attr("file");
          return true;
        }
      });
    }
  });
  $("#list_reports").setGridHeight($(window).height() - y_len);
  window.reports_list = $("#reports_wrapper").detach();
});

$(function() {
    $("#list_git").jqGrid({
  	colNames:['When', 'Message'],
  	colModel:[
        {name: 'date', width: 70},
  	    {name: 'message', index:'commit', width: 200}
  	],
  	rowNum: 1000,
  	height : '250',
  	datatype: 'local',
  	width : '100%',
  	viewrecords: true,
  	cmTemplate: {sortable:false},
  	sortname: null,
  	// treeGrid: true,
  	gridview : true,
  	hoverrows : false,
  	sortable : true,
  	multiselect: false,
  	hidegrid : false,
  	localReader : {
  	    repeatitems: false,
  	    id:"commit"
  	},
  	ondblClickRow: function(rowid) {
  	},
  	gridComplete: function() {
  	    $(this).jqGrid('hideCol', 'cb');
  	},
  	loadComplete: function() {
  	    var rows = $("#list_git tr:gt(0)"); // remove titles for tooltips
  	    rows.each(function(index) {
      		rows.children("td").each(function() {
      		    $(this).removeAttr('title');
      		})
        });
  	    $("tr.jqgrow", this).contextMenu('context_git', {
    		  bindings: {
    		    'Show': function(trigger) {
    		  }
    		},
  		onContextMenu: function(event/*, menu*/) {
  		    var rowId = $(event.target).closest("tr.jqgrow").attr("file");
  		    return true;
  		}
  	    });
  	}
      });
    $("#list_git").setGridHeight($(window).height() - y_len);
    window.git_list = $("#git_wrapper").detach();
});

var rowsToColor = [];
$(function() {
    $("#main").jqGrid({
    colNames:['','Run', 'Ref', 'Description', 'Color','Method', 'OFV', 'dOFV', 'S', 'B', 'C', 'Sig', 'Notes', 'Dataset', 'AIC','BIC'],
    colModel:[
      {name:'key_run', index:'key_run', width:'24', formatter: function (cellvalue, options, rowObject) {
        var markup = "";
        if (rowObject.key_run == 1) {
          markup = "<img src='../images/key_just.gif'></img>";
        };
        if (rowObject.key_run == 2) {
          markup = "<img src='../images/flag_green_just.gif'></img>";
        };
        if (rowObject.key_run == 3) {
          markup = "<img src='../images/flag_red_just.gif'></img>";
        };
      // 	if (rowObject.key_run == 0) {
      	if (rowObject.descr === ' [ up one level ] ') {
          markup = "<i class='fa fa-folder fa-lg'></i>";
      	}
      	if (rowObject.descr === ' [ DIR ] ' | rowObject.descr == '..') {
          markup = "<i class='fa fa-folder-o fa-lg'></i>";
      	 // markup = "<img src='../images/folder_narrow.gif'></img>";
      	}
        return markup;
       }},
      {name:'run', index:'id', width:'120', formatter: function(cellvalue, options, rowObject) {
        if(rowObject.run) {
          if(rowObject.run.match(/^\//)) {
            return('<span class="grey">'+ rowObject.run + '</span>');
          } else {
            return(rowObject.run);
          }
        } else {
          return("");
        }
      }},
      {name:'refmod', index:'refmod', width:'60', formatter: function(cellvalue, options, rowObject) {
        if(rowObject.refmod) {
          return('<span class="lgrey">'+ rowObject.refmod + '</span>');
        } else {
          return("");
        }
      }},
	   {name:'descr', index:'descr', width:'200',
       formatter: function(cellvalue, options, rowObject) {
        if(rowObject.descr === ' [ DIR ] ') {
            return("");
         } else {
      	     if(rowObject.descr) {
               if (rowObject.descr === ' [ up one level ] ') {
                 return("<span class='grey'>" + rowObject.descr + "</span>");
               } else {
                 return(rowObject.descr);
               }
      	     } else {
      		 return("<span class='lgrey'>N/A</span>");
      	     }
      	}
        }
      },
      {name:'colors', index: 'colors', hidden:true},
      {name:'method', index:'method', width:'72', formatter: function(cellvalue, options, rowObject) {
        if(rowObject.method) {
          return('<span class="lgrey">'+ rowObject.method + '</span>');
        } else {
          return("");
        }
      }},
      {name:'ofv', index:'ofv', width:'60', align: "right"},
      {name:'dofv', index:'dofv', width:'60', align: "right", formatter: function (cellvalue, options, rowObject) {
        var markup = "";
        if (rowObject.dofv !== undefined && rowObject.dofv !== "NA") {
          markup = "<span class='grey'>"+rowObject.dofv+"</span>";
          if (rowObject.dofv < -3.84) {
            markup = "<span class='green'>"+rowObject.dofv+"</span>";
          }
          if (rowObject.dofv > 3.84) {
            markup = "<span class='red'>"+rowObject.dofv+"</span>";
          }
        }
        return markup
      }},
      {name:'suc', index:'suc', width:'15', align: "center", formatter: function (cellvalue, options, rowObject) {
        var markup = "";
        if (rowObject.suc !== undefined) {
          markup = "<span class='lgrey'>"+rowObject.suc+"</span>";
          if (rowObject.suc === "T" | rowObject.suc === "R") {
            markup = "<span class='red'>"+rowObject.suc+"</span>";
          }
        }
        return(markup);
      }},
      {name:'bnd', index:'bnd', width:'15', align: "center", formatter: function (cellvalue, options, rowObject) {
        if (rowObject.bnd !== undefined) {
          return ("span class='lgrey'>"+rowObject.bnd+"</span>");
        } else {
          return ("");
        }
      }},
      {name:'cov', index:'cov', width:'15', align: "center", formatter: function (cellvalue, options, rowObject) {
        if (rowObject.cov !== undefined) {
          return ("<span class='lgrey'>"+rowObject.cov+"</span>");
        } else {
          return ("");
        }
      }},
      {name:'sig', index:'sig', width:'25', align: "right", formatter: function (cellvalue, options, rowObject) {
        if (rowObject.sig !== undefined) {
          return ("<span class='lgrey'>"+rowObject.sig+"</span>");
        } else {
          return ("");
        }
      }},
      {name:'notes', index:'notes', width:'200'},
      {name:'dataset', index:'dataset', width:'120', formatter: function(cellvalue, options, rowObject) {
        if(rowObject.dataset) {
          return("<span class='lgrey'>"+rowObject.dataset+"</span>")
        } else {
          return("");
        }
      }},
      {name:'aic', index:'aic', width:'100'},
      {name:'bic', index:'bic', width:'100'}
    ],
    rowNum:1000,
    autowidth:true,
    width: '100%',
    datatype: 'local',
    viewrecords: true,
    sortorder: "asc",
    gridview : true,
    height : '720',
    hoverrows : false,
    sortable : true,
    multiselect: true,
    hidegrid : true,
    scrollrows : true,
    rowattr: function (rd) {
      if (rd.descr == ' [ DIR ] ') {
        return {"class": "folder_row"};
      }
      if (rd.descr == ' [ up one level ] ') {
        return {"class": "up_folder_row"};
      }
      if (rd.colors !== undefined) {
        if (rd.colors == "#efC9a4") { return {"class": "grid_row_lred"}; }
        if (rd.colors == "#c0dfc0") { return {"class": "grid_row_lgreen"}; }
        if (rd.colors == "#aacaef") { return {"class": "grid_row_lblue"}; }
        if (rd.colors == "#ffffc0") { return {"class": "grid_row_lyellow"}; }
        if (rd.colors == "#dad7d3") { return {"class": "grid_row_grey"}; }
        if (rd.colors == "#ffffff") { return {"class": "grid_row_white"}; }
      }
    },
    onSelectRow: function(rowid){
      select_row_action(rowid);
    },
    ondblClickRow: function(rowid) {
      dbl_click(rowid);
    },
    localReader : {
      repeatitems: false,
      id:"run"
    },
   gridComplete: function() {
    	$(this).jqGrid('hideCol', 'cb');
    	$(this).find(">tbody>tr.jqgrow:odd").addClass("even_row");
	    $(this).find(">tbody>tr.jqgrow:even").addClass("odd_row");
    },
    beforeSelectRow: function (rowid, e) { // needed for multiple selection with shift + ctrl
            if (!e.ctrlKey && !e.shiftKey) {
                $("#main").jqGrid('resetSelection');
            }
        //     if (e.shiftKey) {
        //         var initialRowSelect = $("#main").jqGrid('getGridParam', 'selrow');
        //         $("#main").jqGrid('resetSelection');
        //         var CurrentSelectIndex = $("#main").jqGrid('getInd', rowid);
        //         var InitialSelectIndex = $("#main").jqGrid('getInd', initialRowSelect);
        //         var startID = "";
        //         var endID = "";
        //         if (CurrentSelectIndex > InitialSelectIndex) {
        //             startID = initialRowSelect;
        //             endID = rowid;
        //         } else {
        //             startID = rowid;
        //             endID = initialRowSelect;
        //         }
        //         var shouldSelectRow = false;
        //         $.each($("#main").getDataIDs(), function(_, id){
        //             if ((shouldSelectRow = id == startID || shouldSelectRow)){
        //               $("#main").jqGrid('setSelection', id, false);
        //             }
        //             return id != endID;
        //         });
        //     }
            return true;
        },
        loadComplete: function() {
            var rows = $("#main tr:gt(0)"); // remove titles for tooltips
            rows.each(function(index) {
		    rows.children("td").each(function() {
		        $(this).removeAttr('title');
		    })
        });
        $("tr.jqgrow", this).contextMenu('context_menu_main', {
            bindings: {
            'edit': function(trigger) {
                var ids = $("#main").getGridParam('selarrrow');
                var id = ids[0];
                if (id != '..' && !id.match(/^\//)) {
                  $.post('/api/code_editor', {
                    mode: 'nonmem',
                    folder: $("#cwd_input").val(),
                    file: id+'.mod'
                  }, function(msg) {
                    code_editor(msg);
                    status();
                  });
                }
            },
            'output': function(/*trigger*/) {
		           view_lst_command()
            },
            'estimates': function(/*trigger*/) {
                view_estimates_command()
            },
            'execute': function(trigger) {
                open_psn_dialog('execute');
            },
            'sumo': function(trigger) {
                sumo_command();
            },
            'duplicate': function(/*trigger*/) {
                duplicate_command();
            },
            'delete': function(/*trigger*/) {
		        open_delete_dialog();
            },
            'edit_info': function(/*trigger*/) {
                open_model_info_dialog();
            }
        },
        onContextMenu: function(event/*, menu*/) {
            var rowId = $(event.target).closest("tr.jqgrow").attr("id");
            return true;
        }
    });
   }
  });
  $("#main").jqGrid('bindKeys');
  $("#main").jqGrid('filterToolbar', { stringResult: true, searchOnEnter: false, defaultSearch: 'cn' });
  $("#main")[0].toggleToolbar();
  $("#main").setGridWidth($(window).width() - right_grid_width);
  $("#main").setGridHeight($(window).height() - y_len);
});

$(function() {
    $("#ps_monitor").jqGrid({
	colNames:['pid', 'cpu','mem','time', 'user','command', 'args'],
	colModel:[
	    {name:'pid',  index:'pid',key: true, width:'50'},
	    {name:'cpu', width:'40'},
	    {name:'mem',  width:'40'},
	    {name:'time', width:'60'},
	    {name:'user', width:'80'},
	    {name:'command', width:'80'},
	    {name:'args', width:'190'}
	],
	cmTemplate: {sortable:false},
	rowNum:1000,
	autowidth:true,
	width: '380',
	datatype: 'local',
	viewrecords: true,
	sortorder: "asc",
	gridview : true,
	height : '280',
	hoverrows : false,
	sortable : true,
	multiselect: true, // needs to be multiple, otherwise kill doesn't work
	hidegrid : false,
	gridComplete: function() {
	    $(this).jqGrid('hideCol', 'cb');
	},
	loadComplete: function() {
            var rows = $("#ps_monitor tr:gt(0)"); // remove titles for tooltips
            rows.each(function(index) {
		rows.children("td").each(function() {
		    $(this).removeAttr('title');
		})
		    });
            $("tr.jqgrow", this).contextMenu('context_menu_ps_monitor', {
		bindings: {
		    'kill': function(trigger) {
			var ids = $("#ps_monitor").getGridParam('selarrrow');
		        if (ids !== undefined) {
			    $.post('/api/kill_process', {
    				cmd: "kill_process",
    				pid: ids[0]
			    }, function(msg) {
            refresh_process_info_monitor();
          });
			};
		    }
		},
		onContextMenu: function(event/*, menu*/) {
		    var rowId = $(event.target).closest("tr.jqgrow").attr("pid");
		    return true;
		}
	    });
	}
    });
});

$(function() {
    var jobs_list_specification = {
    	colNames:['job','user','id', 'start', 'time', 'state','queue'],
    	colModel:[
    	    {name:'job-id', index:'job-id', width:'40'},
    	    {name:'user',  width:'80'},
    	    {name:'name', width:'110'},
    	    {name:'submit/start', width:'70'},
          {name:'at', width:'70'},
    	    {name:'state', width:'30'},
    	    {name:'queue', width:'110'},
    	],
    	cmTemplate: {sortable:false},
    	rowNum:1000,
    //	autowidth:true,
    	width: '100%',
    	datatype: 'local',
    	viewrecords: true,
    	sortorder: "asc",
    	gridview : true,
    	height : '280',
    	hoverrows : false,
    	sortable : true,
    	multiselect: true,
    	hidegrid : false,
    	onSelectRow: function(rowid){
    	},
    	ondblClickRow: function(rowid) {
    	},
    	localReader : {
    	    repeatitems: false,
    	    id:"job-id"
    	},
    	gridComplete: function() {
    	    $(this).jqGrid('hideCol', 'cb');
    	}
    };
    var nodes_list_specification = _.clone(jobs_list_specification);
    var jobs_a_specification = _.clone(jobs_list_specification)
    jobs_a_specification.loadComplete = function () {
        var rows = $("#jobs_a_monitor tr:gt(0)"); // remove titles for tooltips
        rows.each(function(index) {
	    rows.children("td").each(function() {
		$(this).removeAttr('title');
	    })
		});
        $("tr.jqgrow", this).contextMenu('context_menu_jobs_monitor', {
	    bindings: {
		'qdel': function(trigger) {
		    var ids = $("#jobs_a_monitor").getGridParam('selarrrow');
		    if (ids !== undefined) {
    			$.post('/api/qdel', {
    			    cmd: "qdel",
    			    pid: ids[0]
    			}, function() {
             // do nothing?
          });
		    };
		}
	    },
	    onContextMenu: function(event/*, menu*/) {
		var rowId = $(event.target).closest("tr.jqgrow").attr("pid");
		return true;
	    }
	});
    }
    var jobs_s_specification = _.clone(jobs_list_specification);
    jobs_s_specification.loadComplete = function () {
        var rows = $("#jobs_a_monitor tr:gt(0)"); // remove titles for tooltips
        rows.each(function(index) {
	    rows.children("td").each(function() {
		$(this).removeAttr('title');
	    })
		});
        $("tr.jqgrow", this).contextMenu('context_menu_jobs_monitor', {
	    bindings: {
		'qdel': function(trigger) {
		    var ids = $("#jobs_s_monitor").getGridParam('selarrrow');
		    if (ids !== undefined) {
          $.post('/api/qdel', {
    			    cmd: "qdel",
    			    pid: ids[0]
    			}, function() {
             // do nothing?
          });
		    };
		}
	    },
	    onContextMenu: function(event/*, menu*/) {
		var rowId = $(event.target).closest("tr.jqgrow").attr("pid");
		return true;
	    }
	});
    }
    nodes_list_specification.loadComplete = function () {
        var rows = $("#jobs_a_monitor tr:gt(0)"); // remove titles for tooltips
        rows.each(function(index) {
	    rows.children("td").each(function() {
		$(this).removeAttr('title');
	    })
		});
        $("tr.jqgrow", this).contextMenu('context_menu_nodes_monitor', {
	    onContextMenu: function(event/*, menu*/) {
		var rowId = $(event.target).closest("tr.jqgrow").attr("pid");
		return true;
	    }
	});
    }
    $("#jobs_a_monitor").jqGrid(jobs_a_specification);
    $("#jobs_s_monitor").jqGrid(jobs_s_specification);
    nodes_list_specification.multiselect = false;
    nodes_list_specification.colNames = ["node", "# jobs", "# cpu avail.", "load", "Men tot.", "Mem use"];
    nodes_list_specification.colModel = [
    	// {name:'arch', index:'cluster', width:'60'},
    	{name:'hostname',  width:'190'},
      {name:'running_jobs', width:'65'},
      {name:'ncpu', width:'65'},
    	{name:'load', width:'65'},
    	{name:'memtot', width:'65'},
    	{name:'memuse', width:'65'}
    	// {name:'swapto', width:'40'},
    	// {name:'swapus', width:'40'}
    ];
    nodes_list_specification.height = 115;
    var jobs_on_node_spec = jobs_a_specification;
    jobs_on_node_spec.height = 116;
    nodes_list_specification.onSelectRow = function(rowid) {
      monitor_active_node = rowid-1;
      var tmp = nodes_use[monitor_active_node];
      if(tmp) {
        jobs_on_node = tmp.hostname;
        $("#jobs_on_node").html(jobs_on_node.toString());
      }
      if(tmp && tmp.jobs) {
        populate_list_with_data("#nodes_jobs_monitor", tmp.jobs);
      } else {
        populate_list_with_data("#nodes_jobs_monitor", [{ "job-id": "" }]);
      }
    };
    $("#nodes_monitor").jqGrid(nodes_list_specification);
    $("#nodes_jobs_monitor").jqGrid(jobs_on_node_spec);
});

function load_spreadsheet_grid(colnames, colmodel) {
    // var all_width = colmodel[0].width * colnames.length;
    $("#spreadsheet").jqGrid({
        colNames: colnames,
        colModel: colmodel,
        rowNum: 25,
        autowidth : true,
        width: '100%',
        height: 400,
        datatype: 'local',
        sortable: true,
        rowattr: function(rd) {
            var evid = "0";
            if (rd.EVID !== undefined) {
                evid = rd.EVID;
            }
            if (rd.evid !== undefined) {
                evid = rd.evid;
            }
            if (evid == "1") {
                return {
                    "class": "evid1"
                };
            }
            if (evid == "0") {
                return {
                    "class": "evid0"
                };
            }
        },
        pager: '#spreadsheet_pager',
        multiselect: false,
        hidegrid: false,
        onSelectRow: function(rowid) {},
        ondblClickRow: function(rowid) {},
        gridComplete: function() {
            $(this).jqGrid('hideCol', 'cb');
        }
    });
    $("#spreadsheet").jqGrid('filterToolbar', {
        stringResult: true,
        searchOnEnter: false,
        defaultSearch: 'cn'
    });
    $("#spreadsheet").addClass("ui-jqgrid2"); // cell-borders
}
$(function() {
    var colnames = [];
    var colmodel = [];
    for (var i = 1; i < 20; i++) {
	     colnames.push("col"+i);
	      colmodel.push({ name: "col"+i, index: "col"+i, align:'right' });
    };
    // dummy
    setTimeout(function() {
      load_spreadsheet_grid(colnames, colmodel);
    });
});

$(function() {
  $( "#data_x_sel" ).selectable({
    stop: function() {
      $( ".ui-selected", this ).each(function() {
        datainspector_x_selected = $( "#data_x_sel li" ).index( this );
      });
      update_data_inspector_plot(true);
    }
  });
  $( "#data_y_sel" ).selectable({
    stop: function() {
      $( ".ui-selected", this ).each(function() {
        datainspector_y_selected = $( "#data_y_sel li" ).index( this );
      });
      update_data_inspector_plot(true);
    }
  });
});

$(function() {
    var name = $( "#name" ),
      email = $( "#email" ),
      password = $( "#password" ),
      allFields = $( [] ).add( name ).add( email ).add( password ),
      tips = $( ".validateTips" );

    function updateTips( t ) {
      tips
        .text( t )
        .addClass( "ui-state-highlight" );
      setTimeout(function() {
        tips.removeClass( "ui-state-highlight", 1500 );
      }, 500 );
    }

    function checkLength( o, n, min, max ) {
      if ( o.val().length > max || o.val().length < min ) {
        o.addClass( "ui-state-error" );
        updateTips( "Length of " + n + " must be between " +
          min + " and " + max + "." );
        return false;
      } else {
        return true;
      }
    }

    function checkRegexp( o, regexp, n ) {
      if ( !( regexp.test( o.val() ) ) ) {
        o.addClass( "ui-state-error" );
        updateTips( n );
        return false;
      } else {
        return true;
      }
    }

$("#chat_window" ).dialog({
      autoOpen: false,
      height: 400,
      width: 350,
      modal: false
});

$("#diff_window" ).dialog({
      autoOpen: false,
      height: 500,
      width: 700
      // modal: true,
});

$("#tty_dialog" ).dialog({
    autoOpen: false,
    title: 'Shell',
    height: 500,
    width: 700,
    position: [100,100],
    close: function () {
    	tty_open = 0;
    }
});


$("#psn_arg_details_dialog" ).dialog({
      autoOpen: false,
      height: 140,
      width: 300,
      position: [500,10],
      // modal: true,
      // buttons: {
      //   "Update": function() {
      //       $("#psn_arg_details_dialog").dialog('close');

      //   }
      // },
      close: function() {
        allFields.val( "" ).removeClass( "ui-state-error" );
      }
});

$("#rename_file_dialog" ).dialog({
      autoOpen: false,
      height: 150,
      width: 280,
      modal: true,
      buttons: {
        "Rename": function() {
    	    $.post('/api/rename_file', {
        		folder: $('#cwd_input').val(),
        		oldfile: $("#old_filename_input").val(),
        		newfile: $("#new_filename_input").val()
    	    }, function(msg) {
            // do nothing?
          });
        $("#rename_file_dialog").dialog('close');
        }
      },
      close: function() {
        allFields.val( "" ).removeClass( "ui-state-error" );
      }
});
$("#copy_file_dialog" ).dialog({
      autoOpen: false,
      height: 200,
      width: 320,
      modal: true,
      buttons: {
        "Copy": function() {
    	    $.post('/api/copy_file', {
        		cmd: "copy_file",
        		folder: $('#cwd_input').val(),
        		oldfile: $("#copy_old_filename_input").val(),
        		newfile: $("#copy_new_filename_input").val()
    	    }, function(msg) {
            // do something...
          });
          $("#copy_file_dialog").dialog('close');
        }
      },
      close: function() {
        allFields.val( "" ).removeClass( "ui-state-error" );
      }
});


$("#spreadsheet_window" ).dialog({
      autoOpen: false,
      height: 505,
      width: 740,
      modal: false,
      open: function() {
      },
      close: function() {
        allFields.val( "" ).removeClass( "ui-state-error" );
      },
      resize: function() {
          $("#spreadsheet").jqGrid('setGridWidth', parseInt($(this).width() - 20) );
          $("#spreadsheet").jqGrid('setGridHeight', parseInt($(this).height() - 20) );
      }
});

$("#login_progress_dialog" ).dialog({
  autoOpen: false,
  height: 240,
  width: 260,
  modal: true,
  dialogClass: "no-title"
});

$("#user_login_form" ).dialog({
	autoOpen: false,
	height: 375,
	width: 350,
	modal: true,
	buttons: [
            { text: "Cancel",
    	      click: function() {
    		  $( this ).dialog( "close" );
              }
    	    },
    	    { text: "Login",
            name: "login_btn",
    	      click: function() {
    		  var bValid = true;
    		  allFields.removeClass( "ui-state-error" );
    		  bValid = bValid && checkLength( name, "Username", 1, 20 );
    		  bValid = bValid && checkLength( password, "Password", 1, 20 );
    		  bValid = bValid && checkRegexp( name, /^[a-z]([0-9a-z_])+$/i, "Username may consist of a-z, 0-9, underscores, begin with a letter." );
//    		  bValid = bValid && checkRegexp( password, /^([\!-\~])+$/, "Password field only allow : a-z 0-9" );
    		  if ( bValid ) {
    		      // $.get( "/parse_login", { name: name.val(), password: password.val() } );
    		      $.cookie('username', name.val(), { expires: 10 });
    		      window.user_id = name.val();
    		      login (name.val(), password.val());
    		      $( this ).dialog( "close" );
    		      $("#login_progress_dialog").dialog( "open" );
    		      $("#login_progress_dialog").removeClass( "hidden" );
    		  }
                  },
    	      type: "submit"
    	    }
    	],
    	close: function() {
                allFields.val( "" ).removeClass( "ui-state-error" );
    	}
    });
    if ($.cookie('username') !== '') {
	    $("#name").val($.cookie('username'));
	    $('#password').focus();
    } else {
	    $('#name').focus();
    }
});

$(function() {
  $("#translate_model_dialog").dialog({
      autoOpen: false,
      height: 200,
      width: 360,
      modal: true,
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Translate": function() {
          $.post('/api/translate', {
            cmd: 'translate',
            run: $("#translate_model").val(),
            translate_to: $("#translate_to").find(":selected").text(),
            folder: $('#cwd_input').val()
          }, function(msg) {
            if (msg.output.match(/\*\* Translated code: \*\*/)) {
              var tmp = msg.output.split(/\*\* Translated code: \*\*/);
              msg.output = tmp[1];
            }
            msg.mode = msg.input_obj.translate_to.toLowerCase();
            if(msg.mode.match(/R::/)) {
              msg.mode = "R";
            }
            code_editor(msg);
          });
          $( this ).dialog( "close" );
        }
      },
      close: function() {
      }
    });
});

$(function() {
  $("#colors_dialog").dialog({
      autoOpen: false,
      height: 160,
      width: 200,
      modal: true,
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        }
      },
      close: function() {
      }
    });
});

$(function() {
  $("#psn_dialog").dialog({
      autoOpen: false,
      height: 330,
      width: 560,
      modal: true,
      position: [200,200],
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Run": function() {
            show_console = 1;
	          console_number++;
            var spl = $('#psn_execute_dialog_command').val().trim().split(/\s/);
 	          add_console_tab(spl[0], console_number);
            sock({ // keep this as socket implementation.
	        	  cmd: 'cmd',
	        	  folder: $('#cwd_input').val(),
	        	  cmdline: $('#psn_execute_dialog_command').val().trim()
            });
            $.post('/api/psn_log_add', {
	        	  cmd: 'psn_log_add',
	        	  folder: $('#cwd_input').val(),
	        	  psn_cmd: $('#psn_execute_dialog_command').val().trim()
            }, function(msg) {
              // do nothing
            });
	    // setTimeout(function() {
	    // 	refresh_pirana($("#cwd_input").val());
	    // }, 5000);
	        if ($("#open_console_checkbox").prop('checked')) {
    		    $('#node_output_dialog').dialog('open');
    	    	show_console = 1;
    	    } else {
    	    	$('#node_output_dialog').dialog('close');
    	    	show_console = 0;
    	    }
            $( this ).dialog( "close" );
        }
      },
      close: function() {
      }
    });
});

$(function() {
  $("#psn_log_dialog").dialog({
      autoOpen: false,
      height: 400,
      width: 462,
      modal: true,
//      position: [1000,10],
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Clear log": function() {
	    $.post('/api/psn_log_clear', {
		      cmd: "psn_log_clear"
	    }, function(msg) {
        // do nothings
      });
	    populate_list_with_data("#psn_log_list", []);
        },
        "Choose": function() {
     	    var id = $("#psn_log_list").jqGrid ('getGridParam', 'selrow');
    	    if (psn_history_log[id] !== undefined) {
        		var cmd = psn_history_log[id].command;
        		var spl = cmd.split(/ /);
        		var tool = spl[0];
            $('#psn_execute_dialog_command').val(cmd);
        		// open_psn_dialog(tool, "", cmd, false);
        		$( this ).dialog( "close" );
    	    }
       }
      }
    });
});

$(function() {
  $("#project_add_dialog").dialog({
      autoOpen: false,
      height: 140,
      width: 300,
      modal: true,
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Add project": function() {
          $.post('/api/project_add', {
            cmd: 'project_add',
            folder: document.getElementById('cwd_input').value,
            project: $('#project_add_name').val(),
	          home: home_folder
          }, function(msg) {
            var proj = msg.input_obj.project;
            active_project = proj;
            active_folder = document.getElementById('cwd_input').value;
            project_folders[proj] = active_folder;
            populate_projects(active_project);
            status("");
          });
          $( this ).dialog( "close" );
        }
      },
      close: function() {
      }
    });
});
$(function() {
  $("#plot_label_dialog").dialog({
      autoOpen: false,
      height: 140,
      width: 300,
      modal: true,
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Save": function() {
          console.log($("#plot_label_input").val());
          if($("#plot_label_type").html().match("X")) {
            $("#data_insp_x_label_btn").html($("#plot_label_input").val());
          } else {
            $("#data_insp_y_label_btn").html($("#plot_label_input").val());
          }
          update_data_inspector_plot();
          $( this ).dialog( "close" );
        }
      },
      close: function() {
      }
    });
});
$(function() {
  $("#new_folder_dialog").dialog({
      autoOpen: false,
      height: 140,
      width: 300,
      modal: true,
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Create folder": function() {
          $.post('/api/new_folder', {
            cmd: 'new_folder',
            folder: document.getElementById('cwd_input').value,
            new_folder: $('#new_folder_name').val()
          }, function(msg) {
            var cwd = chomp(msg.input_obj.folder);
            refresh_pirana(cwd);
            status("");
          });
          $( this ).dialog( "close" );
        }
      },
      close: function() {
      }
    });
});
$(function() {
  $("#new_model_dialog").dialog({
      autoOpen: false,
      height: 260,
      width: 360,
      modal: true,
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Create model": function() {
          if($('#template_selector').val() && $('#new_model_name').val() && $('#new_model_description').val()) {
            $.post('/api/new_model_from_template', {
          		cmd: 'new_model_from_template',
          		folder: document.getElementById('cwd_input').value,
          		template_model: $('#template_selector').val(),
          		new_model_name: $('#new_model_name').val(),
          		description: $('#new_model_description').val()
            }, function(msg) {
              refresh_pirana($('#cwd_input').val() );
            });
            $( this ).dialog( "close" );
          } else {
            $("#message_dialog").html("<p>Please select a template model, provide a model name and a description!</p>").dialog("open");
          }
        }
      },
      close: function() {
      }
    });
});

$(function() {
    $("#copy_script_dialog").dialog({
	autoOpen: false,
	height: 180,
	width: 370,
	modal: true,
	buttons: {
            Cancel: function() {
		$( this ).dialog( "close" );
            },
            "Copy": function() {
		if (script_sel !== undefined && script_sel !== "") {
		    $.post('/api/copy_script', {
    			cmd: "copy_script",
    			folder: $("#cwd_input").val(),
    			script: script_sel,
    			new_script: $("#script_copy_new_name").val(),
    			folder_type: $("#script_copy_folder").val()
		    }, function(msg) {
          refresh_scripts();
        });
		};
		$( this ).dialog( "close" );
            }
	},
	close: function() {
	}
    });
});

$(function() {
    $("#duplicate_dialog").dialog({
	autoOpen: false,
	height: 240,
	width: 280,
	modal: true,
	buttons: {
        Cancel: function() {
    		$( this ).dialog( "close" );
    	},
        "Duplicate": function() {
		    var new_mod = $('#duplicate_dialog_new_mod').val() ;
		    var descr = $('#duplicate_dialog_description').val();
    		$.post('/api/duplicate', {
    		    cmd: 'duplicate',
    		    ue: document.getElementById('duplicate_dialog_upd_est').checked,
    		    un: document.getElementById('duplicate_dialog_upd_num').checked,
    		    model: document.getElementById('duplicate_dialog_orig_mod').value,
    		    description: descr,
    		    folder: document.getElementById('cwd_input').value,
    		    new_mod: new_mod
    		}, function(msg) {
          refresh_pirana( $('#cwd_input').val() );
          $.post('/api/code_editor', {
            cmd: 'code_editor',
            mode: 'nonmem',
            folder: $('#cwd_input').val(),
            file: msg.input_obj.new_mod + '.mod'
          }, function(msg) {
              code_editor(msg);
              status("");
          });
          status("");
        });
    		$( this ).dialog( "close" );
        }
	},
	close: function() {
	}
    });
});

$(function() {
  $("#model_info_dialog").dialog({
      autoOpen: false,
      height: 260,
      width: 450,
      modal: true,
      buttons: {
	  "Close": function() {
              $( this ).dialog( "close" );
	  },
	  "Save": function() {
	      status("Saving model info...");
	      $.post('/api/set_info', {
    		  "cmd": "set_info",
    		  "folder": $("#cwd_input").val(),
    		  "runs": [ $("#model_info_model").val() ],
    		  "description": $("#model_info_description").val(),
    		  "author": $("#model_info_author").val(),
    		  "refmod": $("#model_info_refmod").val(),
    		  "note": $("#model_info_note").val()
	      }, function(msg) {
          status('');
          var cwd = chomp(msg.folder);
          refresh_pirana(cwd);
        });
	      $( this ).dialog( "close" );
	  }
      }
  });
});

$(function() {
  $("#delete_dialog").dialog({
      autoOpen: false,
      height: 380,
      width: 350,
      modal: true,
      buttons: {
        Cancel: function() {
          $( this ).dialog( "close" );
        },
        "Delete": function() {
    	    delete_files($("#main").getGridParam('selarrrow'));
          $( this ).dialog( "close" );
        }
      },
      close: function() {
      }
    });
});

$(function() {
  $("#about_dialog").dialog({
      autoOpen: false, height: 150, width: 260, modal: true,
      buttons: { Close: function() { $( this ).dialog( "close" ); } }
    });
});
$(function() {
  $("#keybindings_dialog").dialog({
      autoOpen: false, height: 250, width: 350, modal: true,
      buttons: { Close: function() { $( this ).dialog( "close" ); } }
    });
});
$(function() {
  $("#message_dialog_large").dialog({
    autoOpen: false, height: 200, width: 450, modal: true,
    buttons: {
      Close: function() { $( this ).dialog( "close" ); }
    }
  });
  $("#message_dialog").dialog({
    autoOpen: false, height: 200, width: 300, modal: true,
    buttons: { Close: function() { $( this ).dialog( "close" ); } }
  });
  $("#confirm_dialog").dialog({
      autoOpen: false, height: 200, width: 300, modal: true,
      dialogClass: "no-title",
      buttons: {
          No: function() { $( this ).dialog( "close" ); },
          Yes: function() { $( this ).dialog( "close" ); }
      }
  });
});
$(function() {
  $("#folder_psn_cmd").dialog({
      autoOpen: false,
      dialogClass: "no-title",
      height: 100, width: 400, position: ["right-15", "bottom-15"],
      modal: false
  });
});
$(function() {
  $("#folder_nmtran_error").dialog({
      autoOpen: false,
      dialogClass: "no-title",
      height: 50, width: 400, position: ["right-15", "bottom-50"],
      modal: false
  });
});
$(function() { // used e.g. for Run finished messages
  // $("#message_dialog_non_modal").dialog({
  //     autoOpen: false,
  //     dialogClass: "no-title-msg",
  //     height: 90,
  //     width: 400,
  //     position: ["left-5", "bottom-15"],
  //     modal: false,
  //     buttons: {
  //   	  "Close": function () {
  //   	      messages = 0;
  //   	      $( this ).html("");
  //   	      $( this ).dialog( "close" );
  //   	  },
  //   	  "Show console": function () {
  //   	      show_active_console(console_active);
  //   	      toggle_open_console();
  //   	  },
  //   	  "Intermediate estimates": function () {
  //   	      refresh_intermed_info();
  //   	      $('#intermed_est_div').dialog('open');
  //   	  },
  //   	  "Update run list": function() {
  //   	      messages = 0;
  //   	      refresh_pirana($('#cwd_input').val());
  //   	      $( this ).html("");
  //   	      $( this ).dialog( "close" );
  //   	  }
  //     }
  // });
  $("#message_dialog_no_title").dialog({
      autoOpen: false,
      dialogClass: "no-title",
      height: 160,
      width: 250,
      modal: true
  });
});

// keyboard bindings
//Mousetrap.bind('e', function() { open_psn_dialog('execute'); });
$(document).keypress(function(e){ // e
    if(main_grid_active == 1 || editor_active == 1) { //if the click event happened inside the grid
	var chk1=(e.which==5 ? 1 : 0); var chk2=(e.which==101 && e.ctrlKey ? 1 : 0);
	if (chk1 || chk2) { open_psn_dialog('execute'); };
    }
});
$(document).keypress(function(e){ // b
    if(main_grid_active == 1) {
	var chk1=(e.which==2 ? 1 : 0); var chk2=(e.which==98 && e.ctrlKey ? 1 : 0);
	if (chk1 || chk2) { open_psn_dialog('bootstrap'); };
    }
});
$(document).keypress(function(e){ //v
    if(main_grid_active == 1) {
	var chk1=(e.which==22 ? 1 : 0); var chk2=(e.which==118 && e.ctrlKey ? 1 : 0);
	if (chk1 || chk2) { open_psn_dialog('vpc'); };
    }
});
$(document).keypress(function(e){ // d
    if(main_grid_active == 1) {
	var chk1=(e.which==4 ? 1 : 0); var chk2=(e.which==100 && e.ctrlKey ? 1 : 0);
	if (chk1 || chk2) { duplicate_command(); };
    }
});
$(document).keypress(function(e){ // l
    if(main_grid_active == 1) {
	var chk1=(e.which==9 ? 1 : 0); var chk2=(e.which==105 && e.ctrlKey ? 1 : 0);
	if (chk1 || chk2) {
	    open_model_info_dialog();
	};
    }
});
$(document).keypress(function(e){ // l
    if(main_grid_active == 1) {
	var chk1=(e.which==12 ? 1 : 0); var chk2=(e.which==108 && e.ctrlKey ? 1 : 0);
	if (chk1 || chk2) {
	    view_lst_command();
	};
    }
});
$(document).keypress(function(e){ // s
    var chk1=(e.which==19 ? 1 : 0); var chk2=(e.which==115 && e.ctrlKey ? 1 : 0);
    if (chk1 || chk2) {
	if(main_grid_active) {
	    sumo_command('sumo');
	};
	if(editor_active) {
	    editor_save_action();
	}
    }
});

// Prevent the backspace key from navigating back and open delete dialog instead
$(document).unbind('keydown').bind('keydown', function (event) {
    var doPrevent = false;
    // if (event.which === 9) {
    //     event.preventDefault();
    // }
    if (event.keyCode === 8) {
        var d = event.srcElement || event.target;
        if ((d.tagName.toUpperCase() === 'INPUT' && (d.type.toUpperCase() === 'TEXT' || d.type.toUpperCase() === 'PASSWORD' || d.type.toUpperCase() === 'FILE'))
             || d.tagName.toUpperCase() === 'TEXTAREA') {
            doPrevent = d.readOnly || d.disabled;
        } else {
            doPrevent = true;
    	    open_delete_dialog();
        }
    }
    if (doPrevent) {
        event.preventDefault();
    }
});

var main_grid_active = 1;
$(document).keydown(function(e){
    if(main_grid_active == 1) { //if the click event happened inside the grid
	if (e.keyCode == 13) { // enter
	    var sel = jQuery('#main').jqGrid('getGridParam','selrow');
	    dbl_click(sel);
	}
	if (e.keyCode == 38 || e.keyCode == 40) { // up or down
	    var sel = jQuery('#main').jqGrid('getGridParam','selrow');
	    var runs = new Array();
	    for (var i = 0; i < main_model_data.length; i++) {
		runs.push(main_model_data[i].run);
	    }
	    var row = _.indexOf(runs, sel);
	    if (e.keyCode == 38) {
		$('#main').jqGrid('resetSelection');
		$('#main').jqGrid('setSelection', runs[row-1]);
	    } else {
		$('#main').jqGrid('resetSelection');
		$('#main').jqGrid('setSelection', runs[row+1]);
	    }
	    return false;
	}
    }
    if (files_grid_active == 1) {
	if (e.keyCode == 38 || e.keyCode == 40) { // up or down
	    var sel = jQuery('#list_files').jqGrid('getGridParam','selrow');
	    var files = new Array();
	    for (var i = 0; i < file_list_data.length; i++) {
		    files.push(file_list_data[i].file);
	    }
	    var row = _.indexOf(files, sel);
	    if (e.keyCode == 38) {
    		$('#list_files').jqGrid('resetSelection');
	    	$('#list_files').jqGrid('setSelection', files[row-1]);
	    } else {
		    $('#list_files').jqGrid('resetSelection');
	    	$('#list_files').jqGrid('setSelection', files[row+1]);
	    }
	    return false;
	}
    }
});

// $( ".selector" ).tabs({ collapsible: true });
